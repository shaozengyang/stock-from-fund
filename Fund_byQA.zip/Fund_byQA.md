本文共分为3个部分，具体如下

一、优选基金，该部分主要进行基金池的筛选

二、挑选优选基金的超配股，该部分主要进行基金重仓股的分析

三、构造优选基金的超配组合，该部分主要依据基金重仓股构建组合，分析其收益、风格、行业信息

# 优选基金

该部分内容包括:

1.1 基金池筛选

1.2 基金规模初选

1.3 选基指标

##  基金池筛选

本报告主要研究基金重仓股是否能带来超额收益，主要观察公募基金，不仅是因为A股市场上公募基金是最大的机构投资者，而且公募基金信息披露透明。按照规定，公募基金要及时发布季度报告、半年度报告以及年度报告，在季度报告中要披露前十大持仓股票和前五大持仓股票，在半年度报告以及年度报告中，要披露所有持仓情况。

根据基金类型选取股票型基金和混合型基金。混合型基金需要过滤非偏股型的基金。

提取2005~2020年的所有公募基金公开数据，进行以下筛选：
1. 保留主动型基金，去除被动型基金，同时剔除封闭式基金，剔除分级基金，FOF基金等
2. 保留连续4季度持股比例在70%仓位之上的基金

筛选完成后，符合要求的基金数量从5000余只下降到640只（2020年第三季度）


```python
import pymongo
import QUANTAXIS as QA
import sys
sys.path.append('/root/workspace/QUANTAXIS/src')
from utils import *
from stock_head import *
from jqdatasdk import *
from QUANTAXIS import *

start_date = QA.QA_util_get_next_trade_date('2009-01-01')
end_date = QA.QA_util_get_pre_trade_date(datetime.date.today().strftime("%Y-%m-%d"))
# raw_data_dir = '../data/raw_data/'
SELECT_RATE = [0.05, 0.1] ##重仓股的选择比例
print(start_date, end_date)
```

    you are using non-interactive mdoel quantaxis
    auth success 
    {'total': 1000000, 'spare': 903357}
    2009-01-05 2021-08-10


## 1.基金池筛选


```python
## 获取基金基本信息，去掉分级基金、FOF、QDII、指数基金、指数增强基金
fund_info = QA_fetch_fund_info()
fund_info = fund_info[~(fund_info.operate_mode.isin(['QDII', 'FOF', 'ETF']))]
types_list = ['lof', 'open_fund', 'stock_fund',  'mixture_fund']
securities_info = QA_fetch_securities_info(sec_type = types_list)
securities_info.index = securities_info.index.map(lambda x: x.split('.')[0])
securities_info = securities_info[~(securities_info.display_name.str.contains('QDII') | securities_info.display_name.str.contains('FOF')
                        | securities_info.display_name.str.contains('分级') | securities_info.display_name.str.contains('美元') 
                        | securities_info.display_name.str.contains('指数'))]
fund_info = pd.merge(fund_info['operate_mode'], securities_info,
                    left_index=True, right_index = True, how='inner')
print(fund_info.shape)
```

    (7059, 5)



```python
# 获取基金规模信息
fund_port = QA_fetch_fund_portfolio(code = fund_info.index.tolist())
fund_port = fund_port[~fund_port.report_type.isnull()][['name','report_type','pub_date','equity_rate','total_asset']]
fund_port['equity_rate'] = fund_port['equity_rate'].fillna(0)
##del some not standard report date
fund_port = fund_port[fund_port.index.get_level_values(0).map(lambda x: x[-5:] in ['03-31', '06-30', '09-30', '12-31'])]
fund_port.shape
```




    (96270, 5)




```python
## 获取过去四个季度持股比例均超过67%的基金
equity_ratio_df = pd.pivot_table(fund_port, index=fund_port.index.get_level_values(0),
                                 columns=fund_port.index.get_level_values(1), 
                                 values='equity_rate')
equity_ratio_df = (equity_ratio_df >= (0.67 * 100))  #### 2/3 ratio
equity_ratio_df = (equity_ratio_df.rolling(4).sum() == 4) ### 4 quarters
equity_ratio_df = equity_ratio_df.stack().rename('isStockFund')
fund_port = pd.merge(fund_port, equity_ratio_df, left_index=True, right_index=True, how='left')
```


```python
### filter the fund by isStock ratio
isStockSum = fund_port.groupby('code')['isStockFund'].sum()
isStockCnt = fund_port.groupby('code')['isStockFund'].count()
isStockPert = isStockSum * 1.0 / isStockCnt  ## isStockFund ratio

filter_list = list(set(isStockSum[isStockSum > 0].index.tolist()) & set(isStockPert[isStockPert >= 0.5].index.tolist()))
# filter_list = list(set(isStockSum[isStockSum > 0].index.tolist()) )
# print(filter_list)
```


```python
fund_port = fund_port[fund_port.index.get_level_values(1).isin(filter_list)]
# print(fund_port.query("period_end=='2021-06-30' & isStockFund == True").shape)
print(fund_port.groupby('period_end').count().head(1))
print(fund_port.groupby('period_end').count().tail(1))
print(fund_port.shape)
```

                name  report_type  pub_date  equity_rate  total_asset  isStockFund
    period_end                                                                    
    2008-12-31   190          190       190          190          190          190
                name  report_type  pub_date  equity_rate  total_asset  isStockFund
    period_end                                                                    
    2021-06-30  1818         1818      1818         1818         1818         1818
    (43155, 6)



```python
## 根据筛选出的基金code，获取连续净值
# fund_nav = QA_fetch_fund_NAV(code=fund_port.index.levels[1].unique().tolist())['refactor_net_value'].reset_index()
fund_nav = QA_fetch_fund_NAV(code=filter_list)['refactor_net_value'].reset_index()

fund_nav = fund_nav[((fund_nav.date >= start_date) & (fund_nav.date < end_date))]
fund_nav = pd.pivot_table(fund_nav, index=['date'], columns=['code'], values=['refactor_net_value'])
fund_nav = fund_nav.pct_change(fill_method='ffill').stack().rename(columns={'refactor_net_value': 'adjNavChgPct'}) * 100
print(fund_nav.shape)
# print(fund_nav.head(5))
```

    (2700205, 1)



```python
# 获取季度信息, return this quarter and next quarter
def get_current_quarter(x):
    year, month = x[:4], x[5:7]
    if month <= '03':
        return year + '-03-31'
    elif month <= '06':
        return year + '-06-30'
    elif month <= '09':
        return year + '-09-30'
    else:
        return year + '-12-31'
def get_last_quarter(x):
    year, month = x[:4], x[5:7]
    if month <= '03':
        return str(int(year)-1) + '-12-31'
    elif month <= '06':
        return year + '-03-31'
    elif month <= '09':
        return year + '-06-30'
    else:
        return year + '-09-30'
def get_next_quarter(x):
    year, month = x[:4], x[5:7]
    if month <= '03':
        return year + '-06-30'
    elif month <= '06':
        return year + '-09-30'
    elif month <= '09':
        return year + '-12-31'
    else:
        return str(int(year)+1) + '-03-31'
## calculate yearly sp based on dayily return
def cal_sp(x, rtn_col, riskfree_rate=0.03):
    year_days=240
    if len(x) <= year_days * 0.8:
        return np.nan
    
    x['cumRet'] = (1 + x[rtn_col]).cumprod()
#     if len(x['cumRet']) == 0:
#         return np.nan    
    
    annualized_return = (round(x['cumRet'].values[-1], 4) ** (year_days/len(x['cumRet']))) - 1.0
    volatility = np.std(x[rtn_col]) * np.sqrt(year_days)
    if volatility == 0:
        return None
    sp = (annualized_return - riskfree_rate) / volatility        
    return sp    
## calculate periodly rtn
def cal_ret(x, month_days=21):
    if len(x) < month_days * 0.5:
        return np.nan        
    if x.min() < -0.12 or x.max() > 0.12:
        return np.nan
    return (1 + x).prod() - 1
```


```python
# 最近一季度收益率，过去一年的夏普率 
def cal_fund_ret(all_fund_nav, begin_date, end_date):
    all_quarter_list = [str(year) + quarter \
                        for year in range(int(begin_date[:4]), int(end_date[:4]) + 1)\
                        for quarter in ['-03-31', '-06-30', '-09-30', '-12-31']]
    data_list = []
    for i, end_quarter in enumerate(all_quarter_list):
        if end_quarter > end_date:
            break
        begin_quarter = str(int(end_quarter[:4])-1) + end_quarter[4:] ## one years before

        ## only one year to cal sharp ratio
        df = all_fund_nav[(all_fund_nav["date"] >= begin_quarter) & (all_fund_nav["date"] <= end_quarter)].copy()
        ##one year's NAV daily!
        df['adjNavChgPct'] = df['adjNavChgPct'].fillna(0) / 100.0
        df['curQuarter'] = df['date'].apply(lambda x: get_current_quarter(x))
        df['nextQuarter'] = df['date'].apply(lambda x: get_next_quarter(x))
        
        ## df contain one year's data
        sp = df.groupby('code').apply(lambda x: cal_sp(x, 'adjNavChgPct')) ## year's sharp
        ## the newest quarter
        quarter_df = df[(df['curQuarter'] == end_quarter)]  
        ret = quarter_df.groupby('code')['adjNavChgPct'].apply(lambda x: cal_ret(x))
        
        ## concat to new df
        quarter_perf_df = pd.concat([sp, ret], axis=1).dropna(how='any').reset_index()
        quarter_perf_df.columns = ['code', 'SP', 'quarter ret']
        quarter_perf_df['reportDate'] = end_quarter

        data_list.append(quarter_perf_df)
        print(f'{begin_quarter}:{end_quarter} , df {df.shape}, code {len(df.code.unique())} ,perf_df.shape {quarter_perf_df.shape}')
    
    perf_df = pd.concat(data_list).drop_duplicates(subset=['code', 'reportDate']).dropna(
        subset=['SP', 'quarter ret'], how='all')
    perf_df['curQuarter'] = perf_df['reportDate'].apply(lambda x: get_current_quarter(x))
    perf_df['nextQuarter'] = perf_df['reportDate'].apply(lambda x: get_next_quarter(x))
    perf_df = pd.merge(
        perf_df[['code', 'reportDate', 'SP', 'quarter ret', 'nextQuarter']].rename(columns={'nextQuarter': 'nextReportDate', 'quarter ret':'lastQRet'}),
        perf_df[['code', 'curQuarter', 'quarter ret']].rename(columns={'quarter ret': 'nextQRet'}),
        how='left', left_on=['code', 'nextReportDate'], right_on=['code', 'curQuarter']).sort_values(
        ['code', 'reportDate']).drop(['curQuarter'], axis=1).dropna(subset=['SP']).fillna({'nextQRet': 0}).set_index(['reportDate', 'code'])
#     perf_df.to_csv('s_perf_df.csv')
    return perf_df
```


```python
perf_df = cal_fund_ret(fund_nav.reset_index(), start_date, end_date)
print(perf_df.shape)
```

    2008-03-31:2009-03-31 , df (11064, 5), code 204 ,perf_df.shape (0, 4)
    2008-06-30:2009-06-30 , df (23910, 5), code 219 ,perf_df.shape (0, 4)
    2008-09-30:2009-09-30 , df (38784, 5), code 232 ,perf_df.shape (0, 4)
    2008-12-31:2009-12-31 , df (53056, 5), code 250 ,perf_df.shape (202, 4)
    2009-03-31:2010-03-31 , df (57025, 5), code 263 ,perf_df.shape (215, 4)
    2009-06-30:2010-06-30 , df (60536, 5), code 284 ,perf_df.shape (229, 4)
    2009-09-30:2010-09-30 , df (63915, 5), code 296 ,perf_df.shape (242, 4)
    2009-12-31:2010-12-31 , df (68041, 5), code 312 ,perf_df.shape (260, 4)
    2010-03-31:2011-03-31 , df (71578, 5), code 322 ,perf_df.shape (277, 4)
    2010-06-30:2011-06-30 , df (75361, 5), code 338 ,perf_df.shape (293, 4)
    2010-09-30:2011-09-30 , df (79589, 5), code 355 ,perf_df.shape (308, 4)
    2010-12-31:2011-12-31 , df (82965, 5), code 369 ,perf_df.shape (321, 4)
    2011-03-31:2012-03-31 , df (86250, 5), code 382 ,perf_df.shape (337, 4)
    2011-06-30:2012-06-30 , df (89167, 5), code 400 ,perf_df.shape (350, 4)
    2011-09-30:2012-09-30 , df (93234, 5), code 418 ,perf_df.shape (366, 4)
    2011-12-31:2012-12-31 , df (96827, 5), code 426 ,perf_df.shape (378, 4)
    2012-03-31:2013-03-31 , df (99159, 5), code 433 ,perf_df.shape (396, 4)
    2012-06-30:2013-06-30 , df (101165, 5), code 446 ,perf_df.shape (412, 4)
    2012-09-30:2013-09-30 , df (103583, 5), code 460 ,perf_df.shape (422, 4)
    2012-12-31:2013-12-31 , df (106639, 5), code 472 ,perf_df.shape (428, 4)
    2013-03-31:2014-03-31 , df (110050, 5), code 488 ,perf_df.shape (439, 4)
    2013-06-30:2014-06-30 , df (115857, 5), code 521 ,perf_df.shape (453, 4)
    2013-09-30:2014-09-30 , df (121813, 5), code 546 ,perf_df.shape (465, 4)
    2013-12-31:2014-12-31 , df (127618, 5), code 578 ,perf_df.shape (484, 4)
    2014-03-31:2015-03-31 , df (133962, 5), code 628 ,perf_df.shape (510, 4)
    2014-06-30:2015-06-30 , df (145417, 5), code 754 ,perf_df.shape (527, 4)
    2014-09-30:2015-09-30 , df (161540, 5), code 815 ,perf_df.shape (560, 4)
    2014-12-31:2015-12-31 , df (178648, 5), code 864 ,perf_df.shape (614, 4)
    2015-03-31:2016-03-31 , df (197015, 5), code 914 ,perf_df.shape (717, 4)
    2015-06-30:2016-06-30 , df (211467, 5), code 941 ,perf_df.shape (803, 4)
    2015-09-30:2016-09-30 , df (222186, 5), code 983 ,perf_df.shape (853, 4)
    2015-12-31:2016-12-31 , df (231504, 5), code 1044 ,perf_df.shape (904, 4)
    2016-03-31:2017-03-31 , df (242093, 5), code 1098 ,perf_df.shape (931, 4)
    2016-06-30:2017-06-30 , df (252750, 5), code 1143 ,perf_df.shape (961, 4)
    2016-09-30:2017-09-30 , df (267843, 5), code 1206 ,perf_df.shape (1022, 4)
    2016-12-31:2017-12-31 , df (280534, 5), code 1278 ,perf_df.shape (1077, 4)
    2017-03-31:2018-03-31 , df (296285, 5), code 1361 ,perf_df.shape (1128, 4)
    2017-06-30:2018-06-30 , df (313313, 5), code 1436 ,perf_df.shape (1178, 4)
    2017-09-30:2018-09-30 , df (328950, 5), code 1479 ,perf_df.shape (1256, 4)
    2017-12-31:2018-12-31 , df (345098, 5), code 1536 ,perf_df.shape (1334, 4)
    2018-03-31:2019-03-31 , df (358137, 5), code 1610 ,perf_df.shape (1414, 4)
    2018-06-30:2019-06-30 , df (373247, 5), code 1709 ,perf_df.shape (1456, 4)
    2018-09-30:2019-09-30 , df (392705, 5), code 1763 ,perf_df.shape (1514, 4)
    2018-12-31:2019-12-31 , df (410996, 5), code 1828 ,perf_df.shape (1578, 4)
    2019-03-31:2020-03-31 , df (427499, 5), code 1855 ,perf_df.shape (1671, 4)
    2019-06-30:2020-06-30 , df (437655, 5), code 1855 ,perf_df.shape (1723, 4)
    2019-09-30:2020-09-30 , df (449383, 5), code 1855 ,perf_df.shape (1749, 4)
    2019-12-31:2020-12-31 , df (452179, 5), code 1855 ,perf_df.shape (1756, 4)
    2020-03-31:2021-03-31 , df (452620, 5), code 1855 ,perf_df.shape (1706, 4)
    2020-06-30:2021-06-30 , df (454475, 5), code 1855 ,perf_df.shape (1829, 4)
    (38048, 4)



```python
df = pd.merge(fund_port.rename_axis(index={'period_end':'reportDate'}), perf_df, left_index=True, right_index=True)
df = df[df['isStockFund']==True].drop('isStockFund', axis=1)
df.to_csv('fund_df.csv', encoding='gbk')
print(df.shape)
df.head(5)
```

    (32436, 9)





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>name</th>
      <th>report_type</th>
      <th>pub_date</th>
      <th>equity_rate</th>
      <th>total_asset</th>
      <th>SP</th>
      <th>lastQRet</th>
      <th>nextReportDate</th>
      <th>nextQRet</th>
    </tr>
    <tr>
      <th>reportDate</th>
      <th>code</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">2009-12-31</th>
      <th>000021</th>
      <td>华夏优势增长股票型证券投资基金</td>
      <td>第四季度</td>
      <td>2010-01-21</td>
      <td>91.87</td>
      <td>1.690606e+10</td>
      <td>1.819152</td>
      <td>0.161323</td>
      <td>2010-03-31</td>
      <td>-0.046889</td>
    </tr>
    <tr>
      <th>000031</th>
      <td>华夏复兴股票型证券投资基金</td>
      <td>第四季度</td>
      <td>2010-01-21</td>
      <td>90.24</td>
      <td>4.925003e+09</td>
      <td>3.365355</td>
      <td>0.208927</td>
      <td>2010-03-31</td>
      <td>0.017282</td>
    </tr>
    <tr>
      <th>002011</th>
      <td>华夏红利混合型证券投资基金</td>
      <td>第四季度</td>
      <td>2010-01-21</td>
      <td>90.48</td>
      <td>2.730181e+10</td>
      <td>2.724458</td>
      <td>0.187931</td>
      <td>2010-03-31</td>
      <td>-0.008355</td>
    </tr>
    <tr>
      <th>020001</th>
      <td>国泰金鹰增长证券投资基金</td>
      <td>第四季度</td>
      <td>2010-01-20</td>
      <td>88.04</td>
      <td>1.131284e+09</td>
      <td>3.155926</td>
      <td>0.218573</td>
      <td>2010-03-31</td>
      <td>-0.009036</td>
    </tr>
    <tr>
      <th>020005</th>
      <td>国泰金马稳健回报证券投资基金</td>
      <td>第四季度</td>
      <td>2010-01-20</td>
      <td>90.48</td>
      <td>8.960523e+09</td>
      <td>3.267469</td>
      <td>0.151707</td>
      <td>2010-03-31</td>
      <td>-0.029638</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.tail(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>name</th>
      <th>report_type</th>
      <th>pub_date</th>
      <th>equity_rate</th>
      <th>total_asset</th>
      <th>SP</th>
      <th>lastQRet</th>
      <th>nextReportDate</th>
      <th>nextQRet</th>
    </tr>
    <tr>
      <th>reportDate</th>
      <th>code</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">2021-06-30</th>
      <th>960016</th>
      <td>交银施罗德成长混合型证券投资基金H类</td>
      <td>第二季度</td>
      <td>2021-07-20</td>
      <td>76.02</td>
      <td>3.152940e+09</td>
      <td>0.498580</td>
      <td>0.062515</td>
      <td>2021-09-30</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>960018</th>
      <td>大成内需增长混合型证券投资基金H类</td>
      <td>第二季度</td>
      <td>2021-07-21</td>
      <td>85.68</td>
      <td>4.292123e+08</td>
      <td>1.482094</td>
      <td>0.113726</td>
      <td>2021-09-30</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>960020</th>
      <td>南方优选价值混合型证券投资基金H类</td>
      <td>第二季度</td>
      <td>2021-07-21</td>
      <td>79.61</td>
      <td>1.783989e+09</td>
      <td>0.500412</td>
      <td>0.160763</td>
      <td>2021-09-30</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>960021</th>
      <td>富兰克林国海潜力组合混合型证券投资基金H类-人民币</td>
      <td>第二季度</td>
      <td>2021-07-21</td>
      <td>92.71</td>
      <td>3.230355e+09</td>
      <td>1.021188</td>
      <td>0.093750</td>
      <td>2021-09-30</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>960024</th>
      <td>嘉实成长收益证券投资基金H类</td>
      <td>第二季度</td>
      <td>2021-07-20</td>
      <td>73.99</td>
      <td>3.627378e+09</td>
      <td>1.706074</td>
      <td>0.195769</td>
      <td>2021-09-30</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>



## 基金规模初选

基金规模是基金的重要考察因素。本节考察基金规模与收益的关系，具体来说，每季度根据基金规模分十组，考察每组下季度的收益，看基金规模与下季度收益是否有相关关系。


```python
# ---------------------------  计算规模与下期收益的关系
# 因子分组的超额收益作bar图
def plot_quantile_excess_return(perf, title, xlabel=u'分位组(1为值最小组)', ylabel=u'分组超额收益'):
    fig = plt.figure(figsize=(12, 6))
    ax1 = fig.add_subplot(111)
    
    perf.plot(kind='bar', ax=ax1, legend=False)
    plt.legend(perf.columns, prop=font, loc='best', handlelength=4,
               handletextpad=1, borderpad=0.5, ncol=2)
    ax1.set_ylabel(ylabel, fontproperties=font, fontsize=16)
    ax1.set_xlabel(xlabel, fontproperties=font, fontsize=16)
    ax1.set_xticks(perf.index)
    ax1.set_yticks(ax1.get_yticks())
#     ax1.set_yticks([str(round(x, 4) * 100) + '0%' for x in ax1.get_yticks()])
    ax1.set_yticklabels([str(round(x, 4) * 100) + '0%' for x in ax1.get_yticks()], 
                        fontproperties=font, fontsize=14)
    ax1.set_title(title, fontproperties=font, fontsize=16)
    ax1.grid()
    plt.show()
    
def plot_bar_lines(ax1_x, ax1_y, ax1_label, ax2_x, ax2_y, ax2_label, title):
    fig = plt.figure(figsize=(12, 6))
    ax1 = fig.add_subplot(111)
    ax2 = ax1.twinx()
    ind = np.arange(len(ax1_x))
    width = 0.5

    ax1.bar(ind + width / 2.0, ax1_y, width=width, label=ax1_label)
    ax1.legend(loc=2, prop=font)
    ax1.set_xticks(ind + width)
    ax1.set_xticklabels(ax1_x, rotation=90)
    ax1.set_title(title, fontsize=16, fontproperties=font)

    ax2.plot(ind + width, ax2_y, color='r', label=ax2_label)
    ax2.legend(loc=9, prop=font)
    ax2.grid(False)

    plt.show()    
    
# 按factor分组进行绘图, market return 为所有基金收益的mean
def cal_group_ret(data_info, factor_name='total_asset', group=10):
    data_info = data_info.dropna(subset=[factor_name, 'nextQRet'], how='all')
    data_info['group'] = (data_info.groupby('reportDate')[factor_name].apply(
        lambda x: (x.rank(method='first') - 1) / len(x) * group).astype(int)) + 1
    ## 按factor从小到大排序， 分为group组   
    
    group_pref = data_info.groupby(['reportDate', 'group']).apply(lambda x: x['nextQRet'].mean()).reset_index()  ## group return
    group_pref.columns = ['reportDate', 'group', 'nextQRet']    
    market_pref = data_info.groupby(['reportDate']).apply(lambda x: x['nextQRet'].mean()).reset_index()  ## market return
    market_pref.columns = ['reportDate', 'market_ret']    
    merge_pref = pd.merge(group_pref, market_pref, on='reportDate')    
    merge_pref['excessRet'] = merge_pref['nextQRet'] - merge_pref['market_ret']
    group_excess_ret = merge_pref.groupby('group')[['nextQRet', 'excessRet']].mean()
    
    return data_info, merge_pref, group_excess_ret
```


```python
asset_group, asset_perf_group, asset_exret = cal_group_ret(df, 'total_asset')
print("asset_group_info "+str(asset_group.shape))
print('asset_perf_group_info ' + str(asset_perf_group.shape))
# print(asset_perf_group.tail(5))  ## market return is mean of all the funds' return
print('----------total asset 的quantile分隔点-------------------')
print(asset_group['total_asset'].quantile([0.1, 0.25, 0.5, 0.75, 1]))
plot_quantile_excess_return(asset_exret[['excessRet']], u'全部基金当期规模与下季度收益的关系')
```

    asset_group_info (32436, 10)
    asset_perf_group_info (470, 5)
    ----------total asset 的quantile分隔点-------------------
    0.10    7.029876e+07
    0.25    2.034458e+08
    0.50    7.155830e+08
    0.75    2.058674e+09
    1.00    9.200973e+10
    Name: total_asset, dtype: float64


    QUANTAXIS>> findfont: Font family ['sans-serif'] not found. Falling back to DejaVu Sans.



    
![png](output_19_2.png)
    


* 上图规模分组超额收益显示，基金规模偏大的基金下期收益均不好，中小规模的基金表现要好些。但为了稳健性，后续选取规模10亿-100亿（1e09-1e10）规模的基金进行分析。


```python
# ---------------------------  展示中等基金数目及按规模筛选比例10亿~100亿
choose_1 = asset_group[(asset_group['total_asset'] > 1e9) & (asset_group['total_asset'] < 1e10)]  #按规模
print(f'after choose_1, the size is {len(choose_1.index.get_level_values(1).unique())}， the shape is {choose_1.shape}')
asset_cnt = asset_group.groupby('reportDate')['name'].count()
choose_1_cnt = choose_1.groupby('reportDate')['name'].count()
data = pd.concat([asset_cnt, (1 - choose_1_cnt * 1.0 / asset_cnt)], axis=1).dropna()
data.columns = ['cnt', 'ratio']

plot_bar_lines(asset_cnt.index, data['cnt'].values, u'原样本数', 
              asset_cnt.index, data['ratio'].values, u'按基金规模(10亿~100亿)进行剔除的比例',
              u'按基金规模进行筛选')
# print(data.tail(2))
```

    after choose_1, the size is 992， the shape is (12842, 10)



    
![png](output_21_1.png)
    



```python
# ####---------------------------  展示小规模基金数目及按规模筛选比例1亿到10亿
# choose_1 = asset_group[(asset_group['total_asset'] > 1e8) & (asset_group['total_asset'] < 1e9)]  #按规模
# print(f'after choose_1, the size is {len(choose_1.index.get_level_values(1).unique())}， the shape is {choose_1.shape}')
# asset_cnt = asset_group.groupby('reportDate')['name'].count()
# choose_1_cnt = choose_1.groupby('reportDate')['name'].count()
# data = pd.concat([asset_cnt, (1 - choose_1_cnt * 1.0 / asset_cnt)], axis=1).dropna()
# data.columns = ['cnt', 'ratio']

# plot_bar_lines(asset_cnt.index, data['cnt'].values, u'原样本数', 
#               asset_cnt.index, data['ratio'].values, u'按基金规模(1亿~10亿)进行剔除的比例',
#               u'按基金规模进行筛选')

```

上图展示了每季度的基金池数目与按规模剔除的比例，可以看到基金池个数近些年稳步提升，剔除的比例也越来越低，主要是因为小规模的基金占比越来越高。

## 选基指标

上节按照规模初筛基金池，本小节依据研报按照基金过去一年的夏普率作为分组依据，考察每组的下期收益情况。

下图可以看出夏普率高的基金，分组超额收益（本组收益-平均收益）也较高，有着不错的单调线性关系。因此后续按照夏普率分组TOP10%作为筛选后的优选基金池。


```python
# ---------------------------  展示基金(资金规模筛选后的)当期夏普比率与下季度收益的分组回测结果
choose_1, sp_asset_perf, sp_asset_ret = cal_group_ret(choose_1, 'SP')
plot_quantile_excess_return(sp_asset_ret[['excessRet']], u'基金当期夏普比率与下季度收益的分组回测结果')

# ---------------------------  展示优选基金的数量和平均规模
# choose_2 = choose_1.query("group==10").copy()  ## sharp ratio最高的10%
choose_2 = choose_1[choose_1['group'] == 10]
print(f'after choose 2, the Number of chosen fund is {len(choose_2.index.get_level_values(1).unique())}， the SP&rtn shape is {choose_2.shape}')
fund_cnt = choose_2.groupby('reportDate')['name'].count()
avg_asset = choose_2.groupby('reportDate')['total_asset'].mean() / 1e8

plot_bar_lines(fund_cnt.index, fund_cnt.values, u'每季度优秀基金数(左)', 
              avg_asset.index, avg_asset.values, u'每季度优秀基金(top 10% sp)平均规模（亿元）',
              u'优选基金(top 10% sp)的数量和平均规模')

```


    
![png](output_25_0.png)
    


    after choose 2, the Number of chosen fund is 480， the SP&rtn shape is (1263, 10)



    
![png](output_25_2.png)
    


下图分析了夏普率top10%基金构成的等权基金组合的每年超额收益分布图，可以看出在大部分年份，该组合能跑赢等权基金组合，过去10年平均每年能跑赢3.7%。

下图展示了我们每季度按照夏普率筛选的基金数目及规模，可以看到每季度大概筛选40-60只基金，规模均在4亿-5亿之间

choose 1:规模在1亿~10亿之间

choose 2：每次季报的SP在前10%

after choose 2, the Number of chosen fund is 351， the SP&rtn shape is (998, 10)

# 挑选优选基金的超配股

该部分内容包括:

2.1 优选基金的前十大重仓股

2.2 优选基金的超配股(top 10%)

2.3 超配股的超配股(top 30% of top 10%)

首先按照上述每季度选取的基金，调取相应的季度持仓信息


```python
### 提取持仓信息，去掉银行及金融行业
fund_detail = QA_fetch_fund_portfolio_stock(code = choose_2.index.get_level_values(1).unique().tolist())
fund_detail = fund_detail[(fund_detail['report_type'] != '年度' ) & (fund_detail['report_type'] != '半年度')]
fund_detail.index.names = ['reportDate', 'code']
choose_detail = pd.merge(choose_2.drop(columns=['total_asset', 'group']),
                         fund_detail[['rank', 'symbol', 'name', 'market_cap','proportion']].rename(columns = {'symbol':'secID', 'name':'secName'}), 
                         left_index=True, right_index=True, how='left')
##是否绝对持仓比例
# choose_detail['normRatio'] = round((choose_detail['proportion'] / choose_detail['equity_rate']) * 100, 2)
choose_detail['normRatio'] = round(choose_detail['proportion'] , 2)
choose_detail['tradeDate'] = choose_detail.groupby('reportDate')['pub_date'].transform(max)

industry = QA_fetch_industry_by_stock(stock_code = choose_detail['secID'].unique().tolist()).reset_index().astype(str)
industry = industry[(industry.src == 'sw') & (industry.level == 'l1')]
choose_detail = pd.merge(choose_detail.reset_index(),
                         industry[['date', 'code', 'industry_code']].rename(columns={'date':'reportDate','code':'secID'}),
                         left_on = ['reportDate', 'secID'], right_on = ['reportDate', 'secID'],
                         how = 'left').set_index(['reportDate', 'code']).sort_index()
## 去掉801780银行 801790金融 801190 金融服务
choose_detail = choose_detail[(choose_detail.industry_code != '801780') & (choose_detail.industry_code != '801790') & (choose_detail.industry_code != '801190')]
print(choose_detail.shape)
```

    (11639, 16)


## 优选基金的前十大重仓股

下节分析了优选基金的前十大重仓股, 取基金池中每只基金的重仓股并集作为最终该季度的股票池，发现近些年重仓股数量稳定在200只左右，说明优质基金有抱团的倾向；从重仓股的平均持仓权重来看，最近几期在5.5%~6%左右，单个基金的持仓分散度有所降低



```python
## 重仓股合并个数，计算单只重仓股的平均权重
top10_stat = choose_detail.reset_index().groupby('reportDate').apply(
                        lambda x: pd.Series(
                            index=['fundCnt', 'stockCnt', 'weights mean', 'SP mean'],
                            data=[len(x['code'].unique()), len(x['secID'].unique()),  
                                  x['normRatio'].mean(), x['SP'].mean()]))
plot_bar_lines(top10_stat.index, top10_stat['stockCnt'].values, u'优秀基金组合前十大重仓股数量',
              top10_stat.index, top10_stat['weights mean'].values, u'优秀基金组合前十大重仓股平均权重',
              u'优选基金池（按规模和SP剔除后）的前十大重仓股的数量和平均权重')
# print(top10_stat)
```


    
![png](output_32_0.png)
    



```python
### 处理十大重仓股为mean rank，sum rank
choose_res = choose_detail.reset_index().groupby(['reportDate', 'secID']).apply(
    lambda x: pd.Series(index=['fundCnt', 'weights mean', 'weights sum', 'SP mean'],
                        data=[len(x['code'].unique()),  x['normRatio'].mean(), 
                              x['normRatio'].sum(), x['SP'].mean()])).reset_index()
choose_res = pd.merge(choose_res,
                       choose_detail.reset_index()[['reportDate', 'secID', 'secName', 'tradeDate']],                       
                       left_on=['reportDate', 'secID'], right_on=['reportDate', 'secID'], how='left').drop_duplicates()

## score: Rank(mean)+Rank(sum)
choose_res['mean rank'] = choose_res.groupby(['reportDate'])['weights mean'].rank(axis=0, method='first', ascending=False)
choose_res['sum rank'] = choose_res.groupby(['reportDate'])['weights sum'].rank(axis=0, method='first', ascending=False)
choose_res['score'] = choose_res['mean rank'] + choose_res['sum rank']

choose_res.shape
```




    (6088, 11)




```python
## top10 mean
top10_mean = choose_res.sort_values(['reportDate', 'weights mean'], ascending=[True, False])
top10_mean = top10_mean.groupby('reportDate').apply(lambda x: x.head(int(x.shape[0] * 0.1))).reset_index(drop=True)
top10_mean.to_csv('top10_mean.csv', encoding='gbk')
top10mean_stat = top10_mean.groupby('reportDate').apply(
    lambda x: pd.Series(index=['cnt', 'weight'], data=[len(x['secID'].unique()), x['weights mean'].mean()]))
plot_bar_lines(top10mean_stat.index, top10mean_stat['cnt'].values, u'优选基金组合超配股数量',
              top10mean_stat.index, top10mean_stat['weight'].values, u'优选基金组合超配股平均权重',
              u'优选基金组合超配股(top 10% mean)的数量和平均权重')
```


    
![png](output_34_0.png)
    



```python
## top10 sum
top10_sum = choose_res.sort_values(['reportDate', 'weights sum'], ascending=[True, False])
top10_sum = top10_sum.groupby('reportDate').apply(lambda x: x.head(int(x.shape[0] * 0.1))).reset_index(drop=True)
top10_sum.to_csv('top10_sum.csv', encoding='gbk')
top10sum_stat = top10_sum.groupby('reportDate').apply(
    lambda x: pd.Series(index=['cnt', 'weight'], data=[len(x['secID'].unique()), x['weights sum'].mean()]))
plot_bar_lines(top10sum_stat.index, top10sum_stat['cnt'].values, u'优选基金组合超配股数量',
              top10sum_stat.index, top10sum_stat['weight'].values, u'优选基金组合超配股平均权重',
              u'优选基金组合超配股(top 10% sum)的数量和平均权重')
```


    
![png](output_35_0.png)
    



```python
## top10 score: Rank(mean) + rank(sum)
top10_score = choose_res.sort_values(['reportDate', 'score'], ascending=[True, True])
top10_score = top10_score.groupby('reportDate').apply(lambda x: x.head(int(x.shape[0] * 0.1))).reset_index(drop=True)
top10_score.to_csv('top10_score.csv', encoding='gbk')
top10score_stat = top10_score.groupby('reportDate').apply(
    lambda x: pd.Series(index=['cnt', 'mean'], data=[len(x['secID'].unique()), x['score'].mean()]))
plot_bar_lines(top10score_stat.index, top10score_stat['cnt'].values, u'优选基金组合超配股数量',
              top10score_stat.index, top10score_stat['mean'].values, u'优选基金组合超配股平均score',
              u'优选基金组合超配股(top 10% sum)的数量和平均score')
```


    
![png](output_36_0.png)
    



```python
top10_score[top10_score['reportDate'] == top10_score['reportDate'].max()].head(15)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>reportDate</th>
      <th>secID</th>
      <th>fundCnt</th>
      <th>weights mean</th>
      <th>weights sum</th>
      <th>SP mean</th>
      <th>secName</th>
      <th>tradeDate</th>
      <th>mean rank</th>
      <th>sum rank</th>
      <th>score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>561</th>
      <td>2021-06-30</td>
      <td>300750</td>
      <td>39.0</td>
      <td>7.340000</td>
      <td>286.26</td>
      <td>3.170064</td>
      <td>宁德时代</td>
      <td>2021-07-21</td>
      <td>12.0</td>
      <td>1.0</td>
      <td>13.0</td>
    </tr>
    <tr>
      <th>562</th>
      <td>2021-06-30</td>
      <td>300146</td>
      <td>3.0</td>
      <td>8.990000</td>
      <td>26.97</td>
      <td>3.325286</td>
      <td>汤臣倍健</td>
      <td>2021-07-21</td>
      <td>5.0</td>
      <td>24.0</td>
      <td>29.0</td>
    </tr>
    <tr>
      <th>563</th>
      <td>2021-06-30</td>
      <td>601012</td>
      <td>18.0</td>
      <td>6.371667</td>
      <td>114.69</td>
      <td>3.107164</td>
      <td>隆基股份</td>
      <td>2021-07-21</td>
      <td>31.0</td>
      <td>2.0</td>
      <td>33.0</td>
    </tr>
    <tr>
      <th>564</th>
      <td>2021-06-30</td>
      <td>600600</td>
      <td>4.0</td>
      <td>7.290000</td>
      <td>29.16</td>
      <td>3.243289</td>
      <td>青岛啤酒</td>
      <td>2021-07-21</td>
      <td>15.0</td>
      <td>20.0</td>
      <td>35.0</td>
    </tr>
    <tr>
      <th>565</th>
      <td>2021-06-30</td>
      <td>002304</td>
      <td>6.0</td>
      <td>6.628333</td>
      <td>39.77</td>
      <td>3.474151</td>
      <td>洋河股份</td>
      <td>2021-07-21</td>
      <td>26.0</td>
      <td>13.0</td>
      <td>39.0</td>
    </tr>
    <tr>
      <th>566</th>
      <td>2021-06-30</td>
      <td>601058</td>
      <td>5.0</td>
      <td>6.798000</td>
      <td>33.99</td>
      <td>3.492556</td>
      <td>赛轮轮胎</td>
      <td>2021-07-21</td>
      <td>24.0</td>
      <td>15.0</td>
      <td>39.0</td>
    </tr>
    <tr>
      <th>567</th>
      <td>2021-06-30</td>
      <td>300014</td>
      <td>11.0</td>
      <td>6.300000</td>
      <td>69.30</td>
      <td>3.071535</td>
      <td>亿纬锂能</td>
      <td>2021-07-21</td>
      <td>36.0</td>
      <td>4.0</td>
      <td>40.0</td>
    </tr>
    <tr>
      <th>568</th>
      <td>2021-06-30</td>
      <td>002088</td>
      <td>3.0</td>
      <td>7.520000</td>
      <td>22.56</td>
      <td>3.327973</td>
      <td>鲁阳节能</td>
      <td>2021-07-21</td>
      <td>10.0</td>
      <td>32.0</td>
      <td>42.0</td>
    </tr>
    <tr>
      <th>569</th>
      <td>2021-06-30</td>
      <td>002241</td>
      <td>4.0</td>
      <td>7.030000</td>
      <td>28.12</td>
      <td>3.061694</td>
      <td>歌尔股份</td>
      <td>2021-07-21</td>
      <td>20.0</td>
      <td>22.0</td>
      <td>42.0</td>
    </tr>
    <tr>
      <th>570</th>
      <td>2021-06-30</td>
      <td>600141</td>
      <td>3.0</td>
      <td>7.206667</td>
      <td>21.62</td>
      <td>3.327973</td>
      <td>兴发集团</td>
      <td>2021-07-21</td>
      <td>17.0</td>
      <td>33.0</td>
      <td>50.0</td>
    </tr>
    <tr>
      <th>571</th>
      <td>2021-06-30</td>
      <td>600519</td>
      <td>9.0</td>
      <td>5.906667</td>
      <td>53.16</td>
      <td>3.157788</td>
      <td>贵州茅台</td>
      <td>2021-07-21</td>
      <td>44.0</td>
      <td>7.0</td>
      <td>51.0</td>
    </tr>
    <tr>
      <th>572</th>
      <td>2021-06-30</td>
      <td>000568</td>
      <td>5.0</td>
      <td>6.240000</td>
      <td>31.20</td>
      <td>3.207708</td>
      <td>泸州老窖</td>
      <td>2021-07-21</td>
      <td>39.0</td>
      <td>17.0</td>
      <td>56.0</td>
    </tr>
    <tr>
      <th>573</th>
      <td>2021-06-30</td>
      <td>603444</td>
      <td>3.0</td>
      <td>7.006667</td>
      <td>21.02</td>
      <td>3.055567</td>
      <td>吉比特</td>
      <td>2021-07-21</td>
      <td>22.0</td>
      <td>35.0</td>
      <td>57.0</td>
    </tr>
    <tr>
      <th>574</th>
      <td>2021-06-30</td>
      <td>603799</td>
      <td>9.0</td>
      <td>5.681111</td>
      <td>51.13</td>
      <td>2.964516</td>
      <td>华友钴业</td>
      <td>2021-07-21</td>
      <td>53.0</td>
      <td>8.0</td>
      <td>61.0</td>
    </tr>
    <tr>
      <th>575</th>
      <td>2021-06-30</td>
      <td>002709</td>
      <td>14.0</td>
      <td>5.552857</td>
      <td>77.74</td>
      <td>2.937124</td>
      <td>天赐材料</td>
      <td>2021-07-21</td>
      <td>59.0</td>
      <td>3.0</td>
      <td>62.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
top10_mean[top10_mean['reportDate'] == top10_mean['reportDate'].max()].head(15)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>reportDate</th>
      <th>secID</th>
      <th>fundCnt</th>
      <th>weights mean</th>
      <th>weights sum</th>
      <th>SP mean</th>
      <th>secName</th>
      <th>tradeDate</th>
      <th>mean rank</th>
      <th>sum rank</th>
      <th>score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>561</th>
      <td>2021-06-30</td>
      <td>603885</td>
      <td>1.0</td>
      <td>10.01</td>
      <td>10.01</td>
      <td>3.561611</td>
      <td>吉祥航空</td>
      <td>2021-07-21</td>
      <td>1.0</td>
      <td>79.0</td>
      <td>80.0</td>
    </tr>
    <tr>
      <th>562</th>
      <td>2021-06-30</td>
      <td>002648</td>
      <td>1.0</td>
      <td>9.75</td>
      <td>9.75</td>
      <td>2.795186</td>
      <td>卫星石化</td>
      <td>2021-07-21</td>
      <td>2.0</td>
      <td>84.0</td>
      <td>86.0</td>
    </tr>
    <tr>
      <th>563</th>
      <td>2021-06-30</td>
      <td>02333</td>
      <td>1.0</td>
      <td>9.30</td>
      <td>9.30</td>
      <td>3.606551</td>
      <td>长城汽车</td>
      <td>2021-07-21</td>
      <td>3.0</td>
      <td>86.0</td>
      <td>89.0</td>
    </tr>
    <tr>
      <th>564</th>
      <td>2021-06-30</td>
      <td>601668</td>
      <td>1.0</td>
      <td>9.12</td>
      <td>9.12</td>
      <td>3.419380</td>
      <td>中国建筑</td>
      <td>2021-07-21</td>
      <td>4.0</td>
      <td>88.0</td>
      <td>92.0</td>
    </tr>
    <tr>
      <th>565</th>
      <td>2021-06-30</td>
      <td>300146</td>
      <td>3.0</td>
      <td>8.99</td>
      <td>26.97</td>
      <td>3.325286</td>
      <td>汤臣倍健</td>
      <td>2021-07-21</td>
      <td>5.0</td>
      <td>24.0</td>
      <td>29.0</td>
    </tr>
    <tr>
      <th>566</th>
      <td>2021-06-30</td>
      <td>600315</td>
      <td>1.0</td>
      <td>8.83</td>
      <td>8.83</td>
      <td>3.332077</td>
      <td>上海家化</td>
      <td>2021-07-21</td>
      <td>6.0</td>
      <td>90.0</td>
      <td>96.0</td>
    </tr>
    <tr>
      <th>567</th>
      <td>2021-06-30</td>
      <td>300327</td>
      <td>1.0</td>
      <td>8.40</td>
      <td>8.40</td>
      <td>3.069768</td>
      <td>中颖电子</td>
      <td>2021-07-21</td>
      <td>7.0</td>
      <td>98.0</td>
      <td>105.0</td>
    </tr>
    <tr>
      <th>568</th>
      <td>2021-06-30</td>
      <td>002677</td>
      <td>1.0</td>
      <td>8.25</td>
      <td>8.25</td>
      <td>3.332077</td>
      <td>浙江美大</td>
      <td>2021-07-21</td>
      <td>8.0</td>
      <td>101.0</td>
      <td>109.0</td>
    </tr>
    <tr>
      <th>569</th>
      <td>2021-06-30</td>
      <td>01211</td>
      <td>1.0</td>
      <td>7.90</td>
      <td>7.90</td>
      <td>3.926892</td>
      <td>比亚迪股份</td>
      <td>2021-07-21</td>
      <td>9.0</td>
      <td>103.0</td>
      <td>112.0</td>
    </tr>
    <tr>
      <th>570</th>
      <td>2021-06-30</td>
      <td>002088</td>
      <td>3.0</td>
      <td>7.52</td>
      <td>22.56</td>
      <td>3.327973</td>
      <td>鲁阳节能</td>
      <td>2021-07-21</td>
      <td>10.0</td>
      <td>32.0</td>
      <td>42.0</td>
    </tr>
    <tr>
      <th>571</th>
      <td>2021-06-30</td>
      <td>603833</td>
      <td>1.0</td>
      <td>7.41</td>
      <td>7.41</td>
      <td>3.332077</td>
      <td>欧派家居</td>
      <td>2021-07-21</td>
      <td>11.0</td>
      <td>106.0</td>
      <td>117.0</td>
    </tr>
    <tr>
      <th>572</th>
      <td>2021-06-30</td>
      <td>300750</td>
      <td>39.0</td>
      <td>7.34</td>
      <td>286.26</td>
      <td>3.170064</td>
      <td>宁德时代</td>
      <td>2021-07-21</td>
      <td>12.0</td>
      <td>1.0</td>
      <td>13.0</td>
    </tr>
    <tr>
      <th>573</th>
      <td>2021-06-30</td>
      <td>002078</td>
      <td>2.0</td>
      <td>7.30</td>
      <td>14.60</td>
      <td>3.584081</td>
      <td>太阳纸业</td>
      <td>2021-07-21</td>
      <td>13.0</td>
      <td>50.0</td>
      <td>63.0</td>
    </tr>
    <tr>
      <th>574</th>
      <td>2021-06-30</td>
      <td>600176</td>
      <td>2.0</td>
      <td>7.30</td>
      <td>14.60</td>
      <td>3.398463</td>
      <td>中国巨石</td>
      <td>2021-07-21</td>
      <td>14.0</td>
      <td>51.0</td>
      <td>65.0</td>
    </tr>
    <tr>
      <th>575</th>
      <td>2021-06-30</td>
      <td>600600</td>
      <td>4.0</td>
      <td>7.29</td>
      <td>29.16</td>
      <td>3.243289</td>
      <td>青岛啤酒</td>
      <td>2021-07-21</td>
      <td>15.0</td>
      <td>20.0</td>
      <td>35.0</td>
    </tr>
  </tbody>
</table>
</div>



# backtest by QA


```python
init_cash = 10000000
file_name = 'top10_score.csv'  ##从这取策略的买入卖出数据
portfolio = 'QA_Day1'
strategy_id = 'Fund_score_'+dt.datetime.now().strftime('%Y%m%d%H%M') ##每次运行必须更改，否则覆盖

start_date = QA.QA_util_get_next_trade_date('2013-01-01')
end_date = QA.QA_util_get_pre_trade_date(datetime.date.today().strftime("%Y-%m-%d"))

backtest_dir = './backtest_data/'
if not os.path.exists(backtest_dir):
    os.mkdir(backtest_dir)
print(strategy_id)
```

    Fund_score_202108111642



```python
### 处理持仓文件，增加buyDate和sellDate
def fetch_trade_info(filename):    
    def _get_sell_date(date):
        date = str(pd.to_datetime(date, format='%Y-%m-%d').date())
        if(QA.QA_util_if_trade(date)):
            return date.replace('-', '')
        else:
            return QA.QA_util_get_pre_trade_date(date).replace('-', '')
    
    df = pd.read_csv(filename, index_col=0, encoding='gbk', dtype={'secID':str, 'tradeDate':str})
    sell_date_list = list(df['tradeDate'].unique().tolist())
    last_trade_day = QA.QA_util_get_pre_trade_date(QA.QA_util_datetime_to_strdate(QA.QA_util_date_today())).replace('-', '')
    sell_date_list.append(last_trade_day)
    df['sellDate'] = df['tradeDate'].apply(
        lambda x: _get_sell_date(sell_date_list[sell_date_list.index(x)+1]))
    df['buyDate'] = df['tradeDate'].apply(lambda x: QA.QA_util_get_next_trade_date(x).replace('-', ''))
    df = df[['buyDate', 'sellDate', 'secID']]
    df = df[df['secID'].str.len() == 6] ## drop HONGKONG stock
    df.to_csv(backtest_dir+strategy_id+'_trade_info.csv', encoding='gbk')    
    return df
```


```python
## strategy
class fundStrategy(QAStrategyStockBase):
    df = pd.DataFrame()
    
    def user_init(self):
        print('---------user init-------')
        self.init_cash = init_cash
        self.hold_in_record = {}        
        self.df = pd.read_csv(backtest_dir+strategy_id+'_trade_info.csv', index_col=0, encoding='gbk', dtype=str)
        
    def parse_xdxr(self, data):
        today = str(data.name[0])[0:10]
        ticker = data.name[1]
        xdxr_df = QA.QA_fetch_stock_xdxr(ticker).query('category=="1" & date==@today')
        if(xdxr_df.empty):
            return
        xdxr_df = xdxr_df[['code', 'fenhong', 'songzhuangu', 'peigu', 'peigujia']]
        
        print('\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++')
        print(xdxr_df)
        if(float(xdxr_df['fenhong']) != 0):
            origin_cash = self.get_cash()
            add_cash = round(float(xdxr_df['fenhong']) * (self.acc.hold[ticker] / 10), 2)
            self.acc.change_cash(add_cash)
            self.acc.cash_available = self.acc.cash[-1]
            print('分红，增加现金%s' %(str(round(self.get_cash() - origin_cash, 2))))            
             
        if(float(xdxr_df['songzhuangu']) != 0):
            origin_hold = self.acc.hold[ticker]
            vol = math.floor(float(xdxr_df['songzhuangu']) * (self.acc.hold[ticker] / 10) / 100) * 100
            self.send_order(direction="BUY", offset="OPEN", code=ticker, price=0, volume=vol)
            print('转增股，增加股票%s股%s' %(self.acc.hold[ticker] - origin_hold, ticker))
            
            
        if(float(xdxr_df['peigu']) != 0 or float(xdxr_df['peigujia'])!=0):
            ####配股，先卖后买，保持仓位。
            last_day = QA.QA_util_get_pre_trade_date(today)
            last_price = float(QA.QA_fetch_stock_day_adv(code=ticker, start=self.start, end=last_day).close.iloc[-1])
            
            origin_position = last_price * self.acc.hold[ticker]
            self.send_order(direction="SELL", offset="CLOSE", code=ticker, price=last_price, volume=self.acc.hold[ticker])
            a, b = self.acc.history_table.iloc[-1, :][['price', 'amount']]
            print('配股前清仓: 卖出价%s, 卖出数量%s， 金额%s'%(a, b, a*b))
            
            new_price = data.close
            new_amount = math.floor(origin_position / new_price /100) * 100
            self.send_order(direction="OPEN", offset="BUY", code=ticker, price=new_price, volume=new_amount)
            a, b = self.acc.history_table.iloc[-1, :][['price', 'amount']]
            print('配股后买入: 买入价%s, 买入数量%s， 金额%s'%(a, b, a*b))            
            
        print('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n')        
        
  
    def on_bar(self, data):
        today = str(data.name[0])[0:10].replace('-', '')
        ticker = data.name[1]

        if(ticker in self.acc.hold.index):
            self.parse_xdxr(data)            
        
        if(today not in self.df['buyDate'].values and today not in self.df['sellDate'].values):
            return
        
        buy_list = self.df[df['buyDate'] == today]['secID'].tolist()
        sell_list = self.df[df['sellDate'] == today]['secID'].tolist()
        total_list = self.df['secID'].unique().tolist()
        if(ticker not in total_list):
            return        

#         ##1.clear the postion
        if (today in self.df['sellDate'].values and ticker in self.acc.hold.index):
            print('-------today:' +today+' ticker: ' + str(ticker) + ' to sell begin------------')
            print('before cash: %s, price: %s, sell_vol: %s' %(str(round(self.get_cash())), str(data.close), 
                  str(int(self.acc.hold[ticker]))))
            self.send_order(direction="SELL", offset="CLOSE", code=ticker, price=data.close, volume=int(self.acc.hold[ticker]))
#             self.hold_in_record.pop(ticker)
            print('after cash:' + str(round(self.get_cash())))
            print(self.acc.hold)
            if(self.acc.hold.empty):
                print('at %s clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!' %(today))
            print('--------------------- to sell end ---------------------------------------------\n')
        
#         ##2. long the position
        if (today in self.df['buyDate'].values and ticker in buy_list):
            print('------- today:' +today+' ticker: ' + str(ticker) + ' to buy begin--------------')
            to_buy = list(set(buy_list) - set(self.acc.hold.index.tolist()))
            print('to_buy:  ')
            print(to_buy)
            buy_vol = int(math.floor(math.floor(self.acc.cash_available/len(to_buy)/data.close) / 100) *100)
            print('before cash: %s, price: %s, to_buy: %s, buy_vol: %s' %(str(round(self.get_cash())),
                  str(data.close), str(len(to_buy)), str(buy_vol)))
            
            self.send_order(direction="BUY", offset="OPEN", code=ticker, price=data.close, volume=buy_vol)
            
            print('after cash:' + str(round(self.get_cash())))
            print(self.acc.hold)
            to_buy = list(set(buy_list) - set(self.acc.hold.index.tolist()))
            if(not to_buy):
                print('at %s clear the to_buy list successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!' %(today))
            print('--------------------- to buy end -------------------------------------------------\n')

```


```python
## 处理为交易文件
df = fetch_trade_info(file_name)
df.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>buyDate</th>
      <th>sellDate</th>
      <th>secID</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>20100125</td>
      <td>20100422</td>
      <td>600276</td>
    </tr>
    <tr>
      <th>1</th>
      <td>20100125</td>
      <td>20100422</td>
      <td>600153</td>
    </tr>
    <tr>
      <th>2</th>
      <td>20100125</td>
      <td>20100422</td>
      <td>600688</td>
    </tr>
    <tr>
      <th>3</th>
      <td>20100125</td>
      <td>20100422</td>
      <td>600887</td>
    </tr>
    <tr>
      <th>4</th>
      <td>20100125</td>
      <td>20100422</td>
      <td>000568</td>
    </tr>
  </tbody>
</table>
</div>




```python
df = pd.read_csv(backtest_dir+strategy_id+'_trade_info.csv', index_col=0, encoding='gbk', dtype=str)
trade_code_list = df['secID'].unique().tolist()
all_code_list = QA.QA_fetch_stock_list_adv().index.tolist()
code_list = list(set(trade_code_list).intersection(set(all_code_list)))
#print(len(code_list))
portfolio = portfolio
strategy_id = strategy_id

s = fundStrategy(
    code=code_list,
    frequence="day",
    strategy_id=strategy_id,
    portfolio=portfolio,
    start=start_date,
    end=end_date,
)
# s.user_init()
s.run_backtest()

```

    ---------user init-------
     prortfolio with user_cookie  USER_lNKqZ3mc  already exist!!
    QAACCPRO: reload from DATABASE
    QAACCOUNT: THIS ACCOUNT DOESNOT HAVE ANY TRADE
    QAACCOUNT: THIS ACCOUNT DOESNOT HAVE ANY TRADE
    {}
    QAACCOUNT: THIS ACCOUNT DOESNOT HAVE ANY TRADE
    QAACCOUNT: THIS ACCOUNT DOESNOT HAVE ANY TRADE
    < QA_AccountPRO Fund_score_202108111642 market: stock_cn>
    stock_cn
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    ------- today:20130123 ticker: 000002 to buy begin--------------
    to_buy:  
    ['000002', '002310', '600340', '000602', '002415', '600315', '002236', '300070']
    before cash: 10000000, price: 11.69, to_buy: 8, buy_vol: 106900
    after cash:8750027
    code
    000002    106900
    Name: amount, dtype: int64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20130123 ticker: 002236 to buy begin--------------
    to_buy:  
    ['002310', '600340', '000602', '002415', '600315', '002236', '300070']
    before cash: 8750027, price: 49.91, to_buy: 7, buy_vol: 25000
    after cash:7501965
    code
    000002    106900
    002236     25000
    Name: amount, dtype: int64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20130123 ticker: 002310 to buy begin--------------
    to_buy:  
    ['002310', '600340', '000602', '002415', '600315', '300070']
    before cash: 7501965, price: 62.3, to_buy: 6, buy_vol: 20000
    after cash:6255653
    code
    000002    106900
    002236     25000
    002310     20000
    Name: amount, dtype: int64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20130123 ticker: 002415 to buy begin--------------
    to_buy:  
    ['600340', '000602', '002415', '600315', '300070']
    before cash: 6255653, price: 31.81, to_buy: 5, buy_vol: 39300
    after cash:5005208
    code
    000002    106900
    002236     25000
    002310     20000
    002415     39300
    Name: amount, dtype: int64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20130123 ticker: 300070 to buy begin--------------
    to_buy:  
    ['300070', '600315', '600340', '000602']
    before cash: 5005208, price: 41.19, to_buy: 4, buy_vol: 30300
    after cash:3756839
    code
    000002    106900
    002236     25000
    002310     20000
    002415     39300
    300070     30300
    Name: amount, dtype: int64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20130123 ticker: 600315 to buy begin--------------
    to_buy:  
    ['600315', '600340', '000602']
    before cash: 3756839, price: 56.44, to_buy: 3, buy_vol: 22100
    after cash:2509203
    code
    000002    106900
    002236     25000
    002310     20000
    002415     39300
    300070     30300
    600315     22100
    Name: amount, dtype: int64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20130123 ticker: 600340 to buy begin--------------
    to_buy:  
    ['600340', '000602']
    before cash: 2509203, price: 27.14, to_buy: 2, buy_vol: 46200
    after cash:1255021
    code
    000002    106900
    002236     25000
    002310     20000
    002415     39300
    300070     30300
    600315     22100
    600340     46200
    Name: amount, dtype: int64
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2013-04-16  002236      1.6         10.0    0.0       0.0
    分红，增加现金4000.0
    转增股，增加股票25000股002236
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20130422 ticker: 000002 to sell begin------------
    before cash: 1259016, price: 11.69, sell_vol: 106900
    after cash:2507115
    code
    002236    50000.0
    002310    20000.0
    002415    39300.0
    300070    30300.0
    600315    22100.0
    600340    46200.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20130422 ticker: 002236 to sell begin------------
    before cash: 2507115, price: 38.65, sell_vol: 50000
    after cash:4437200
    code
    002310    20000.0
    002415    39300.0
    300070    30300.0
    600315    22100.0
    600340    46200.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20130422 ticker: 002310 to sell begin------------
    before cash: 4437200, price: 88.48, sell_vol: 20000
    after cash:6204588
    code
    002415    39300.0
    300070    30300.0
    600315    22100.0
    600340    46200.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20130422 ticker: 002415 to sell begin------------
    before cash: 6204588, price: 38.7, sell_vol: 39300
    after cash:7723596
    code
    300070    30300.0
    600315    22100.0
    600340    46200.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20130422 ticker: 300070 to sell begin------------
    before cash: 7723596, price: 56.15, sell_vol: 30300
    after cash:9422815
    code
    600315    22100.0
    600340    46200.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20130422 ticker: 600315 to sell begin------------
    before cash: 9422815, price: 69.5, sell_vol: 22100
    after cash:10956845
    code
    600340    46200.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20130422 ticker: 600340 to sell begin------------
    before cash: 10956845, price: 26.68, sell_vol: 46200
    after cash:12187920
    Series([], Name: amount, dtype: float64)
    at 20130422 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20130423 ticker: 000423 to buy begin--------------
    to_buy:  
    ['000963', '000423', '600256', '002450', '600315', '002236', '300070']
    before cash: 12187920, price: 42.24, to_buy: 7, buy_vol: 41200
    after cash:10447197
    code
    000423    41200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20130423 ticker: 000963 to buy begin--------------
    to_buy:  
    ['600256', '000963', '002450', '600315', '002236', '300070']
    before cash: 10447197, price: 41.16, to_buy: 6, buy_vol: 42300
    after cash:8705694
    code
    000423    41200.0
    000963    42300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20130423 ticker: 002236 to buy begin--------------
    to_buy:  
    ['600256', '002450', '600315', '002236', '300070']
    before cash: 8705694, price: 38.09, to_buy: 5, buy_vol: 45700
    after cash:6964546
    code
    000423    41200.0
    000963    42300.0
    002236    45700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20130423 ticker: 300070 to buy begin--------------
    to_buy:  
    ['600256', '002450', '600315', '300070']
    before cash: 6964546, price: 53.32, to_buy: 4, buy_vol: 32600
    after cash:5225879
    code
    000423    41200.0
    000963    42300.0
    002236    45700.0
    300070    32600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20130423 ticker: 600256 to buy begin--------------
    to_buy:  
    ['600256', '002450', '600315']
    before cash: 5225879, price: 18.9, to_buy: 3, buy_vol: 92100
    after cash:3484754
    code
    000423    41200.0
    000963    42300.0
    002236    45700.0
    300070    32600.0
    600256    92100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20130423 ticker: 600315 to buy begin--------------
    to_buy:  
    ['002450', '600315']
    before cash: 3484754, price: 68.52, to_buy: 2, buy_vol: 25400
    after cash:1743911
    code
    000423    41200.0
    000963    42300.0
    002236    45700.0
    300070    32600.0
    600256    92100.0
    600315    25400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code   fenhong  songzhuangu  peigu  peigujia
    date                                                      
    2013-05-14  300070  0.598706     5.987064    0.0       0.0
    分红，增加现金1951.78
    转增股，增加股票19500.0股300070
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2013-05-27  600315      7.0          5.0    0.0       0.0
    分红，增加现金17780.0
    转增股，增加股票12700.0股600315
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2013-06-24  600256      0.5          5.0    0.0       0.0
    分红，增加现金4605.0
    转增股，增加股票46000.0股600256
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20130719 ticker: 000423 to sell begin------------
    before cash: 1768233, price: 39.86, sell_vol: 41200
    after cash:3408412
    code
    000963     42300.0
    002236     45700.0
    300070     52100.0
    600256    138100.0
    600315     38100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20130719 ticker: 000963 to sell begin------------
    before cash: 3408412, price: 42.6, sell_vol: 42300
    after cash:5208139
    code
    002236     45700.0
    300070     52100.0
    600256    138100.0
    600315     38100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20130719 ticker: 002236 to sell begin------------
    before cash: 5208139, price: 41.36, sell_vol: 45700
    after cash:7095929
    code
    300070     52100.0
    600256    138100.0
    600315     38100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20130719 ticker: 300070 to sell begin------------
    before cash: 7095929, price: 42.35, sell_vol: 52100
    after cash:9299606
    code
    600256    138100.0
    600315     38100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20130719 ticker: 600256 to sell begin------------
    before cash: 9299606, price: 9.04, sell_vol: 138100
    after cash:10546469
    code
    600315    38100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20130719 ticker: 600315 to sell begin------------
    before cash: 10546469, price: 46.12, sell_vol: 38100
    after cash:12301445
    Series([], Name: amount, dtype: float64)
    at 20130719 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20130722 ticker: 002236 to buy begin--------------
    to_buy:  
    ['600406', '600637', '002241', '002450', '002353', '002236', '002456']
    before cash: 12301445, price: 42.18, to_buy: 7, buy_vol: 41600
    after cash:10546318
    code
    002236    41600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20130722 ticker: 002241 to buy begin--------------
    to_buy:  
    ['600406', '002241', '002353', '600637', '002450', '002456']
    before cash: 10546318, price: 36.19, to_buy: 6, buy_vol: 48500
    after cash:8790664
    code
    002236    41600.0
    002241    48500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20130722 ticker: 002353 to buy begin--------------
    to_buy:  
    ['600406', '002353', '600637', '002450', '002456']
    before cash: 8790664, price: 70.0, to_buy: 5, buy_vol: 25100
    after cash:7033225
    code
    002236    41600.0
    002241    48500.0
    002353    25100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20130722 ticker: 002456 to buy begin--------------
    to_buy:  
    ['600637', '002450', '600406', '002456']
    before cash: 7033225, price: 48.89, to_buy: 4, buy_vol: 35900
    after cash:5277635
    code
    002236    41600.0
    002241    48500.0
    002353    25100.0
    002456    35900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20130722 ticker: 600406 to buy begin--------------
    to_buy:  
    ['600637', '002450', '600406']
    before cash: 5277635, price: 15.03, to_buy: 3, buy_vol: 117000
    after cash:3518685
    code
    002236     41600.0
    002241     48500.0
    002353     25100.0
    002456     35900.0
    600406    117000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20131025 ticker: 002236 to sell begin------------
    before cash: 3518685, price: 40.25, sell_vol: 41600
    after cash:5190992
    code
    002241     48500.0
    002353     25100.0
    002456     35900.0
    600406    117000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20131025 ticker: 002241 to sell begin------------
    before cash: 5190992, price: 36.4, sell_vol: 48500
    after cash:6954186
    code
    002353     25100.0
    002456     35900.0
    600406    117000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20131025 ticker: 002353 to sell begin------------
    before cash: 6954186, price: 69.0, sell_vol: 25100
    after cash:8683921
    code
    002456     35900.0
    600406    117000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20131025 ticker: 002456 to sell begin------------
    before cash: 8683921, price: 44.03, sell_vol: 35900
    after cash:10262622
    code
    600406    117000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20131025 ticker: 600406 to sell begin------------
    before cash: 10262622, price: 13.16, sell_vol: 117000
    after cash:11800417
    Series([], Name: amount, dtype: float64)
    at 20131025 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20131028 ticker: 000536 to buy begin--------------
    to_buy:  
    ['300070', '002292', '300059', '000536', '002038', '300058', '002024', '002236', '002400']
    before cash: 11800417, price: 28.3, to_buy: 9, buy_vol: 46300
    after cash:10489800
    code
    000536    46300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20131028 ticker: 002038 to buy begin--------------
    to_buy:  
    ['300070', '002292', '300059', '002038', '300058', '002024', '002236', '002400']
    before cash: 10489800, price: 46.0, to_buy: 8, buy_vol: 28500
    after cash:9178472
    code
    000536    46300.0
    002038    28500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20131028 ticker: 002236 to buy begin--------------
    to_buy:  
    ['002292', '300059', '002400', '300058', '002024', '002236', '300070']
    before cash: 9178472, price: 42.73, to_buy: 7, buy_vol: 30600
    after cash:7870607
    code
    000536    46300.0
    002038    28500.0
    002236    30600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20131028 ticker: 002292 to buy begin--------------
    to_buy:  
    ['002292', '300059', '002400', '300058', '002024', '300070']
    before cash: 7870607, price: 32.53, to_buy: 6, buy_vol: 40300
    after cash:6559320
    code
    000536    46300.0
    002038    28500.0
    002236    30600.0
    002292    40300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20131028 ticker: 300058 to buy begin--------------
    to_buy:  
    ['300059', '002400', '300058', '002024', '300070']
    before cash: 6559320, price: 53.79, to_buy: 5, buy_vol: 24300
    after cash:5251897
    code
    000536    46300.0
    002038    28500.0
    002236    30600.0
    002292    40300.0
    300058    24300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20131028 ticker: 300059 to buy begin--------------
    to_buy:  
    ['002024', '300070', '002400', '300059']
    before cash: 5251897, price: 18.36, to_buy: 4, buy_vol: 71500
    after cash:3938828
    code
    000536    46300.0
    002038    28500.0
    002236    30600.0
    002292    40300.0
    300058    24300.0
    300059    71500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20131028 ticker: 300070 to buy begin--------------
    to_buy:  
    ['002024', '300070', '002400']
    before cash: 3938828, price: 42.5, to_buy: 3, buy_vol: 30800
    after cash:2629501
    code
    000536    46300.0
    002038    28500.0
    002236    30600.0
    002292    40300.0
    300058    24300.0
    300059    71500.0
    300070    30800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20140121 ticker: 000536 to sell begin------------
    before cash: 2629501, price: 23.59, sell_vol: 46300
    after cash:3720353
    code
    002038    28500.0
    002236    30600.0
    002292    40300.0
    300058    24300.0
    300059    71500.0
    300070    30800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20140121 ticker: 002038 to sell begin------------
    before cash: 3720353, price: 53.88, sell_vol: 28500
    after cash:5254013
    code
    002236    30600.0
    002292    40300.0
    300058    24300.0
    300059    71500.0
    300070    30800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20140121 ticker: 002236 to sell begin------------
    before cash: 5254013, price: 37.26, sell_vol: 30600
    after cash:6392744
    code
    002292    40300.0
    300058    24300.0
    300059    71500.0
    300070    30800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20140121 ticker: 002292 to sell begin------------
    before cash: 6392744, price: 39.75, sell_vol: 40300
    after cash:7992667
    code
    300058    24300.0
    300059    71500.0
    300070    30800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20140121 ticker: 300058 to sell begin------------
    before cash: 7992667, price: 59.85, sell_vol: 24300
    after cash:9445204
    code
    300059    71500.0
    300070    30800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20140121 ticker: 300059 to sell begin------------
    before cash: 9445204, price: 14.64, sell_vol: 71500
    after cash:10490655
    code
    300070    30800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20140121 ticker: 300070 to sell begin------------
    before cash: 10490655, price: 38.61, sell_vol: 30800
    after cash:11678357
    Series([], Name: amount, dtype: float64)
    at 20140121 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20140122 ticker: 000536 to buy begin--------------
    to_buy:  
    ['000661', '002371', '002292', '000536', '300287', '002429', '300228', '300253', '002249', '002236']
    before cash: 11678357, price: 23.72, to_buy: 10, buy_vol: 49200
    after cash:10511041
    code
    000536    49200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140122 ticker: 000661 to buy begin--------------
    to_buy:  
    ['000661', '002371', '002292', '300287', '002429', '300228', '300253', '002249', '002236']
    before cash: 10511041, price: 123.56, to_buy: 9, buy_vol: 9400
    after cash:9349287
    code
    000536    49200.0
    000661     9400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140122 ticker: 002236 to buy begin--------------
    to_buy:  
    ['002371', '002292', '300287', '002429', '300228', '300253', '002249', '002236']
    before cash: 9349287, price: 38.41, to_buy: 8, buy_vol: 30400
    after cash:8181331
    code
    000536    49200.0
    000661     9400.0
    002236    30400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140122 ticker: 002249 to buy begin--------------
    to_buy:  
    ['002371', '002292', '300287', '002429', '300228', '300253', '002249']
    before cash: 8181331, price: 10.01, to_buy: 7, buy_vol: 116700
    after cash:7012872
    code
    000536     49200.0
    000661      9400.0
    002236     30400.0
    002249    116700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140122 ticker: 002292 to buy begin--------------
    to_buy:  
    ['002371', '002292', '300287', '002429', '300228', '300253']
    before cash: 7012872, price: 39.85, to_buy: 6, buy_vol: 29300
    after cash:5844975
    code
    000536     49200.0
    000661      9400.0
    002236     30400.0
    002249    116700.0
    002292     29300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140122 ticker: 002371 to buy begin--------------
    to_buy:  
    ['002371', '300287', '002429', '300228', '300253']
    before cash: 5844975, price: 21.38, to_buy: 5, buy_vol: 54600
    after cash:4677335
    code
    000536     49200.0
    000661      9400.0
    002236     30400.0
    002249    116700.0
    002292     29300.0
    002371     54600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140122 ticker: 002429 to buy begin--------------
    to_buy:  
    ['300287', '300228', '002429', '300253']
    before cash: 4677335, price: 15.16, to_buy: 4, buy_vol: 77100
    after cash:3508207
    code
    000536     49200.0
    000661      9400.0
    002236     30400.0
    002249    116700.0
    002292     29300.0
    002371     54600.0
    002429     77100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140122 ticker: 300228 to buy begin--------------
    to_buy:  
    ['300287', '300228', '300253']
    before cash: 3508207, price: 83.8, to_buy: 3, buy_vol: 13900
    after cash:2343096
    code
    000536     49200.0
    000661      9400.0
    002236     30400.0
    002249    116700.0
    002292     29300.0
    002371     54600.0
    002429     77100.0
    300228     13900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140122 ticker: 300253 to buy begin--------------
    to_buy:  
    ['300287', '300253']
    before cash: 2343096, price: 86.9, to_buy: 2, buy_vol: 13400
    after cash:1178345
    code
    000536     49200.0
    000661      9400.0
    002236     30400.0
    002249    116700.0
    002292     29300.0
    002371     54600.0
    002429     77100.0
    300228     13900.0
    300253     13400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140122 ticker: 300287 to buy begin--------------
    to_buy:  
    ['300287']
    before cash: 1178345, price: 41.0, to_buy: 1, buy_vol: 28700
    after cash:1350
    code
    000536     49200.0
    000661      9400.0
    002236     30400.0
    002249    116700.0
    002292     29300.0
    002371     54600.0
    002429     77100.0
    300228     13900.0
    300253     13400.0
    300287     28700.0
    Name: amount, dtype: float64
    at 20140122 clear the to_buy list successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2014-04-04  300228      1.5          0.0    0.0       0.0
    分红，增加现金2085.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code   fenhong  songzhuangu  peigu  peigujia
    date                                                      
    2014-04-11  300253  1.999074     9.995371    0.0       0.0
    分红，增加现金2678.76
    转增股，增加股票13300.0股300253
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20140422 ticker: 000661 to sell begin------------
    before cash: 6109, price: 93.2, sell_vol: 9400
    after cash:881094
    code
    000536     49200.0
    002236     30400.0
    002249    116700.0
    002292     29300.0
    002371     54600.0
    002429     77100.0
    300228     13900.0
    300253     26700.0
    300287     28700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20140422 ticker: 002236 to sell begin------------
    before cash: 881094, price: 30.3, sell_vol: 30400
    after cash:1801063
    code
    000536     49200.0
    002249    116700.0
    002292     29300.0
    002371     54600.0
    002429     77100.0
    300228     13900.0
    300253     26700.0
    300287     28700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20140422 ticker: 002249 to sell begin------------
    before cash: 1801063, price: 12.86, sell_vol: 116700
    after cash:3299949
    code
    000536    49200.0
    002292    29300.0
    002371    54600.0
    002429    77100.0
    300228    13900.0
    300253    26700.0
    300287    28700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20140422 ticker: 002292 to sell begin------------
    before cash: 3299949, price: 29.81, sell_vol: 29300
    after cash:4172290
    code
    000536    49200.0
    002371    54600.0
    002429    77100.0
    300228    13900.0
    300253    26700.0
    300287    28700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20140422 ticker: 002371 to sell begin------------
    before cash: 4172290, price: 19.8, sell_vol: 54600
    after cash:5252019
    code
    000536    49200.0
    002429    77100.0
    300228    13900.0
    300253    26700.0
    300287    28700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20140422 ticker: 002429 to sell begin------------
    before cash: 5252019, price: 11.5, sell_vol: 77100
    after cash:6137560
    code
    000536    49200.0
    300228    13900.0
    300253    26700.0
    300287    28700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20140422 ticker: 300228 to sell begin------------
    before cash: 6137560, price: 61.11, sell_vol: 13900
    after cash:6985927
    code
    000536    49200.0
    300253    26700.0
    300287    28700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20140422 ticker: 300253 to sell begin------------
    before cash: 6985927, price: 43.36, sell_vol: 26700
    after cash:8142192
    code
    000536    49200.0
    300287    28700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20140422 ticker: 300287 to sell begin------------
    before cash: 8142192, price: 54.5, sell_vol: 28700
    after cash:9704387
    code
    000536    49200.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20140423 ticker: 002010 to buy begin--------------
    to_buy:  
    ['002371', '600406', '002010', '300124', '300253', '002594', '002249', '002440', '300202']
    before cash: 9704387, price: 9.6, to_buy: 9, buy_vol: 112300
    after cash:8626038
    code
    000536     49200.0
    002010    112300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140423 ticker: 002249 to buy begin--------------
    to_buy:  
    ['002371', '600406', '300124', '300253', '002594', '002249', '002440', '300202']
    before cash: 8626038, price: 12.88, to_buy: 8, buy_vol: 83700
    after cash:7547712
    code
    000536     49200.0
    002010    112300.0
    002249     83700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140423 ticker: 002371 to buy begin--------------
    to_buy:  
    ['002371', '600406', '300124', '300253', '002594', '002440', '300202']
    before cash: 7547712, price: 20.02, to_buy: 7, buy_vol: 53800
    after cash:6470367
    code
    000536     49200.0
    002010    112300.0
    002249     83700.0
    002371     53800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140423 ticker: 002440 to buy begin--------------
    to_buy:  
    ['600406', '300124', '300253', '002594', '002440', '300202']
    before cash: 6470367, price: 21.35, to_buy: 6, buy_vol: 50500
    after cash:5391922
    code
    000536     49200.0
    002010    112300.0
    002249     83700.0
    002371     53800.0
    002440     50500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140423 ticker: 002594 to buy begin--------------
    to_buy:  
    ['600406', '300124', '300253', '002594', '300202']
    before cash: 5391922, price: 46.15, to_buy: 5, buy_vol: 23300
    after cash:4316358
    code
    000536     49200.0
    002010    112300.0
    002249     83700.0
    002371     53800.0
    002440     50500.0
    002594     23300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140423 ticker: 300124 to buy begin--------------
    to_buy:  
    ['300124', '300253', '600406', '300202']
    before cash: 4316358, price: 64.1, to_buy: 4, buy_vol: 16800
    after cash:3239209
    code
    000536     49200.0
    002010    112300.0
    002249     83700.0
    002371     53800.0
    002440     50500.0
    002594     23300.0
    300124     16800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140423 ticker: 300202 to buy begin--------------
    to_buy:  
    ['300253', '600406', '300202']
    before cash: 3239209, price: 39.8, to_buy: 3, buy_vol: 27100
    after cash:2160360
    code
    000536     49200.0
    002010    112300.0
    002249     83700.0
    002371     53800.0
    002440     50500.0
    002594     23300.0
    300124     16800.0
    300202     27100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140423 ticker: 300253 to buy begin--------------
    to_buy:  
    ['300253', '600406']
    before cash: 2160360, price: 42.38, to_buy: 2, buy_vol: 25400
    after cash:1083638
    code
    000536     49200.0
    002010    112300.0
    002249     83700.0
    002371     53800.0
    002440     50500.0
    002594     23300.0
    300124     16800.0
    300202     27100.0
    300253     25400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140423 ticker: 600406 to buy begin--------------
    to_buy:  
    ['600406']
    before cash: 1083638, price: 14.0, to_buy: 1, buy_vol: 77400
    ALERT MONEY NOT ENOUGH!!!
    1083638.4357499946
    after cash:1083638
    code
    000536     49200.0
    002010    112300.0
    002249     83700.0
    002371     53800.0
    002440     50500.0
    002594     23300.0
    300124     16800.0
    300202     27100.0
    300253     25400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2014-05-13  300124  9.93734      9.93734    0.0       0.0
    分红，增加现金16694.73
    转增股，增加股票16600.0股300124
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2014-05-15  002010      1.5          0.0    0.0       0.0
    分红，增加现金16845.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2014-06-18  002249      2.1          0.0    0.0       0.0
    分红，增加现金17577.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2014-06-18  300202      1.0          8.0    0.0       0.0
    分红，增加现金2710.0
    转增股，增加股票21600.0股300202
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2014-07-04  002371      1.0          0.0    0.0       0.0
    分红，增加现金5380.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2014-07-09  002440      3.5          0.0    0.0       0.0
    分红，增加现金17675.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20140721 ticker: 002010 to sell begin------------
    before cash: 1160510, price: 8.78, sell_vol: 112300
    after cash:2145272
    code
    000536    49200.0
    002249    83700.0
    002371    53800.0
    002440    50500.0
    002594    23300.0
    300124    33400.0
    300202    48700.0
    300253    25400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20140721 ticker: 002249 to sell begin------------
    before cash: 2145272, price: 14.48, sell_vol: 83700
    after cash:3355733
    code
    000536    49200.0
    002371    53800.0
    002440    50500.0
    002594    23300.0
    300124    33400.0
    300202    48700.0
    300253    25400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20140721 ticker: 002371 to sell begin------------
    before cash: 3355733, price: 21.09, sell_vol: 53800
    after cash:4488956
    code
    000536    49200.0
    002440    50500.0
    002594    23300.0
    300124    33400.0
    300202    48700.0
    300253    25400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20140721 ticker: 002440 to sell begin------------
    before cash: 4488956, price: 17.99, sell_vol: 50500
    after cash:5396316
    code
    000536    49200.0
    002594    23300.0
    300124    33400.0
    300202    48700.0
    300253    25400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20140721 ticker: 002594 to sell begin------------
    before cash: 5396316, price: 46.03, sell_vol: 23300
    after cash:6467474
    code
    000536    49200.0
    300124    33400.0
    300202    48700.0
    300253    25400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20140721 ticker: 300124 to sell begin------------
    before cash: 6467474, price: 26.05, sell_vol: 33400
    after cash:7336457
    code
    000536    49200.0
    300202    48700.0
    300253    25400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20140721 ticker: 300202 to sell begin------------
    before cash: 7336457, price: 26.39, sell_vol: 48700
    after cash:8620043
    code
    000536    49200.0
    300253    25400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20140722 ticker: 002183 to buy begin--------------
    to_buy:  
    ['002371', '002368', '601012', '300059', '002549', '002429', '600352', '002183', '002249', '600570', '300202']
    before cash: 8620043, price: 7.68, to_buy: 11, buy_vol: 102000
    after cash:7836487
    code
    000536     49200.0
    002183    102000.0
    300253     25400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140722 ticker: 002249 to buy begin--------------
    to_buy:  
    ['002371', '002368', '601012', '300059', '002549', '002429', '600352', '002249', '600570', '300202']
    before cash: 7836487, price: 15.58, to_buy: 10, buy_vol: 50200
    after cash:7054176
    code
    000536     49200.0
    002183    102000.0
    002249     50200.0
    300253     25400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140722 ticker: 002368 to buy begin--------------
    to_buy:  
    ['002371', '002368', '601012', '300059', '002549', '002429', '600352', '600570', '300202']
    before cash: 7054176, price: 37.2, to_buy: 9, buy_vol: 21000
    after cash:6272780
    code
    000536     49200.0
    002183    102000.0
    002249     50200.0
    002368     21000.0
    300253     25400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140722 ticker: 002371 to buy begin--------------
    to_buy:  
    ['002371', '601012', '300059', '002549', '002429', '600352', '600570', '300202']
    before cash: 6272780, price: 21.1, to_buy: 8, buy_vol: 37100
    after cash:5489775
    code
    000536     49200.0
    002183    102000.0
    002249     50200.0
    002368     21000.0
    002371     37100.0
    300253     25400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140722 ticker: 002429 to buy begin--------------
    to_buy:  
    ['601012', '300059', '002549', '002429', '600352', '600570', '300202']
    before cash: 5489775, price: 7.26, to_buy: 7, buy_vol: 108000
    after cash:4705499
    code
    000536     49200.0
    002183    102000.0
    002249     50200.0
    002368     21000.0
    002371     37100.0
    002429    108000.0
    300253     25400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140722 ticker: 002549 to buy begin--------------
    to_buy:  
    ['601012', '300059', '002549', '600352', '600570', '300202']
    before cash: 4705499, price: 12.96, to_buy: 6, buy_vol: 60500
    after cash:3921223
    code
    000536     49200.0
    002183    102000.0
    002249     50200.0
    002368     21000.0
    002371     37100.0
    002429    108000.0
    002549     60500.0
    300253     25400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140722 ticker: 300059 to buy begin--------------
    to_buy:  
    ['601012', '300059', '600352', '600570', '300202']
    before cash: 3921223, price: 10.47, to_buy: 5, buy_vol: 74900
    after cash:3136824
    code
    000536     49200.0
    002183    102000.0
    002249     50200.0
    002368     21000.0
    002371     37100.0
    002429    108000.0
    002549     60500.0
    300059     74900.0
    300253     25400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140722 ticker: 300202 to buy begin--------------
    to_buy:  
    ['600570', '601012', '600352', '300202']
    before cash: 3136824, price: 27.0, to_buy: 4, buy_vol: 29000
    after cash:2353628
    code
    000536     49200.0
    002183    102000.0
    002249     50200.0
    002368     21000.0
    002371     37100.0
    002429    108000.0
    002549     60500.0
    300059     74900.0
    300202     29000.0
    300253     25400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140722 ticker: 600352 to buy begin--------------
    to_buy:  
    ['600570', '601012', '600352']
    before cash: 2353628, price: 14.59, to_buy: 3, buy_vol: 53700
    after cash:1569949
    code
    000536     49200.0
    002183    102000.0
    002249     50200.0
    002368     21000.0
    002371     37100.0
    002429    108000.0
    002549     60500.0
    300059     74900.0
    300202     29000.0
    300253     25400.0
    600352     53700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140722 ticker: 600570 to buy begin--------------
    to_buy:  
    ['600570', '601012']
    before cash: 1569949, price: 28.3, to_buy: 2, buy_vol: 27700
    after cash:785843
    code
    000536     49200.0
    002183    102000.0
    002249     50200.0
    002368     21000.0
    002371     37100.0
    002429    108000.0
    002549     60500.0
    300059     74900.0
    300202     29000.0
    300253     25400.0
    600352     53700.0
    600570     27700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20140722 ticker: 601012 to buy begin--------------
    to_buy:  
    ['601012']
    before cash: 785843, price: 15.94, to_buy: 1, buy_vol: 49300
    ALERT MONEY NOT ENOUGH!!!
    785843.0189999945
    after cash:785843
    code
    000536     49200.0
    002183    102000.0
    002249     50200.0
    002368     21000.0
    002371     37100.0
    002429    108000.0
    002549     60500.0
    300059     74900.0
    300202     29000.0
    300253     25400.0
    600352     53700.0
    600570     27700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2014-09-25  000536      0.0          4.5    0.0       0.0
    转增股，增加股票22100.0股000536
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20141027 ticker: 000536 to sell begin------------
    before cash: 785838, price: 19.55, sell_vol: 71300
    after cash:2178011
    code
    002183    102000.0
    002249     50200.0
    002368     21000.0
    002371     37100.0
    002429    108000.0
    002549     60500.0
    300059     74900.0
    300202     29000.0
    300253     25400.0
    600352     53700.0
    600570     27700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20141027 ticker: 002183 to sell begin------------
    before cash: 2178011, price: 15.53, sell_vol: 102000
    after cash:3760091
    code
    002249     50200.0
    002368     21000.0
    002371     37100.0
    002429    108000.0
    002549     60500.0
    300059     74900.0
    300202     29000.0
    300253     25400.0
    600352     53700.0
    600570     27700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20141027 ticker: 002249 to sell begin------------
    before cash: 3760091, price: 14.46, sell_vol: 50200
    after cash:4485075
    code
    002368     21000.0
    002371     37100.0
    002429    108000.0
    002549     60500.0
    300059     74900.0
    300202     29000.0
    300253     25400.0
    600352     53700.0
    600570     27700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20141027 ticker: 002368 to sell begin------------
    before cash: 4485075, price: 42.4, sell_vol: 21000
    after cash:5374362
    code
    002371     37100.0
    002429    108000.0
    002549     60500.0
    300059     74900.0
    300202     29000.0
    300253     25400.0
    600352     53700.0
    600570     27700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20141027 ticker: 002371 to sell begin------------
    before cash: 5374362, price: 24.98, sell_vol: 37100
    after cash:6299962
    code
    002429    108000.0
    002549     60500.0
    300059     74900.0
    300202     29000.0
    300253     25400.0
    600352     53700.0
    600570     27700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20141027 ticker: 002429 to sell begin------------
    before cash: 6299962, price: 8.28, sell_vol: 108000
    after cash:7193084
    code
    002549    60500.0
    300059    74900.0
    300202    29000.0
    300253    25400.0
    600352    53700.0
    600570    27700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20141027 ticker: 002549 to sell begin------------
    before cash: 7193084, price: 15.38, sell_vol: 60500
    after cash:8122411
    code
    300059    74900.0
    300202    29000.0
    300253    25400.0
    600352    53700.0
    600570    27700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20141027 ticker: 300059 to sell begin------------
    before cash: 8122411, price: 15.4, sell_vol: 74900
    after cash:9274429
    code
    300202    29000.0
    300253    25400.0
    600352    53700.0
    600570    27700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20141027 ticker: 300202 to sell begin------------
    before cash: 9274429, price: 28.05, sell_vol: 29000
    after cash:10086862
    code
    300253    25400.0
    600352    53700.0
    600570    27700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20141027 ticker: 300253 to sell begin------------
    before cash: 10086862, price: 49.28, sell_vol: 25400
    after cash:11337010
    code
    600352    53700.0
    600570    27700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20141027 ticker: 600352 to sell begin------------
    before cash: 11337010, price: 14.23, sell_vol: 53700
    after cash:12100205
    code
    600570    27700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20141027 ticker: 600570 to sell begin------------
    before cash: 12100205, price: 39.89, sell_vol: 27700
    after cash:13203777
    Series([], Name: amount, dtype: float64)
    at 20141027 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20141028 ticker: 002368 to buy begin--------------
    to_buy:  
    ['300288', '002368', '601989', '002522', '600967', '600570', '300085', '600221', '600340', '002638', '002549', '002424', '300322', '000748', '300324', '300202']
    before cash: 13203777, price: 43.29, to_buy: 16, buy_vol: 19000
    after cash:12381062
    code
    002368    19000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20141028 ticker: 002424 to buy begin--------------
    to_buy:  
    ['300288', '601989', '002522', '600967', '600570', '300085', '600221', '600340', '002638', '002549', '002424', '300322', '000748', '300324', '300202']
    before cash: 12381062, price: 43.47, to_buy: 15, buy_vol: 18900
    after cash:11559273
    code
    002368    19000.0
    002424    18900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20141028 ticker: 002522 to buy begin--------------
    to_buy:  
    ['300288', '601989', '002522', '600967', '600570', '300085', '600221', '600340', '002638', '002549', '300322', '000748', '300324', '300202']
    before cash: 11559273, price: 16.73, to_buy: 14, buy_vol: 49300
    after cash:10734278
    code
    002368    19000.0
    002424    18900.0
    002522    49300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20141028 ticker: 002549 to buy begin--------------
    to_buy:  
    ['300288', '601989', '600967', '600570', '300085', '600221', '600340', '002638', '002549', '300322', '000748', '300324', '300202']
    before cash: 10734278, price: 15.8, to_buy: 13, buy_vol: 52200
    after cash:9909312
    code
    002368    19000.0
    002424    18900.0
    002522    49300.0
    002549    52200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20141028 ticker: 002638 to buy begin--------------
    to_buy:  
    ['300288', '600221', '600340', '601989', '002638', '300322', '000748', '600967', '300324', '600570', '300085', '300202']
    before cash: 9909312, price: 17.12, to_buy: 12, buy_vol: 48200
    after cash:9083921
    code
    002368    19000.0
    002424    18900.0
    002522    49300.0
    002549    52200.0
    002638    48200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20141028 ticker: 300085 to buy begin--------------
    to_buy:  
    ['300288', '600221', '600340', '601989', '300322', '000748', '600967', '300324', '600570', '300085', '300202']
    before cash: 9083921, price: 24.0, to_buy: 11, buy_vol: 34400
    after cash:8258115
    code
    002368    19000.0
    002424    18900.0
    002522    49300.0
    002549    52200.0
    002638    48200.0
    300085    34400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20141028 ticker: 300202 to buy begin--------------
    to_buy:  
    ['300288', '600221', '600340', '601989', '300322', '000748', '600967', '300324', '600570', '300202']
    before cash: 8258115, price: 28.5, to_buy: 10, buy_vol: 28900
    after cash:7434259
    code
    002368    19000.0
    002424    18900.0
    002522    49300.0
    002549    52200.0
    002638    48200.0
    300085    34400.0
    300202    28900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20141028 ticker: 300288 to buy begin--------------
    to_buy:  
    ['300288', '600221', '600340', '601989', '300322', '000748', '600967', '300324', '600570']
    before cash: 7434259, price: 98.5, to_buy: 9, buy_vol: 8300
    after cash:6616505
    code
    002368    19000.0
    002424    18900.0
    002522    49300.0
    002549    52200.0
    002638    48200.0
    300085    34400.0
    300202    28900.0
    300288     8300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20141028 ticker: 300322 to buy begin--------------
    to_buy:  
    ['600221', '600340', '601989', '300322', '000748', '600967', '300324', '600570']
    before cash: 6616505, price: 22.5, to_buy: 8, buy_vol: 36700
    after cash:5790548
    code
    002368    19000.0
    002424    18900.0
    002522    49300.0
    002549    52200.0
    002638    48200.0
    300085    34400.0
    300202    28900.0
    300288     8300.0
    300322    36700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20141028 ticker: 600221 to buy begin--------------
    to_buy:  
    ['600221', '600340', '601989', '600967', '000748', '300324', '600570']
    before cash: 5790548, price: 2.06, to_buy: 7, buy_vol: 401500
    after cash:4963252
    code
    002368     19000.0
    002424     18900.0
    002522     49300.0
    002549     52200.0
    002638     48200.0
    300085     34400.0
    300202     28900.0
    300288      8300.0
    300322     36700.0
    600221    401500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20141028 ticker: 600340 to buy begin--------------
    to_buy:  
    ['600340', '601989', '600967', '000748', '300324', '600570']
    before cash: 4963252, price: 25.0, to_buy: 6, buy_vol: 33000
    after cash:4138045
    code
    002368     19000.0
    002424     18900.0
    002522     49300.0
    002549     52200.0
    002638     48200.0
    300085     34400.0
    300202     28900.0
    300288      8300.0
    300322     36700.0
    600221    401500.0
    600340     33000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20141028 ticker: 600570 to buy begin--------------
    to_buy:  
    ['601989', '600967', '000748', '300324', '600570']
    before cash: 4138045, price: 40.1, to_buy: 5, buy_vol: 20600
    after cash:3311779
    code
    002368     19000.0
    002424     18900.0
    002522     49300.0
    002549     52200.0
    002638     48200.0
    300085     34400.0
    300202     28900.0
    300288      8300.0
    300322     36700.0
    600221    401500.0
    600340     33000.0
    600570     20600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20141028 ticker: 600967 to buy begin--------------
    to_buy:  
    ['601989', '600967', '300324', '000748']
    before cash: 3311779, price: 14.85, to_buy: 4, buy_vol: 55700
    after cash:2484427
    code
    002368     19000.0
    002424     18900.0
    002522     49300.0
    002549     52200.0
    002638     48200.0
    300085     34400.0
    300202     28900.0
    300288      8300.0
    300322     36700.0
    600221    401500.0
    600340     33000.0
    600570     20600.0
    600967     55700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20141028 ticker: 601989 to buy begin--------------
    to_buy:  
    ['601989', '300324', '000748']
    before cash: 2484427, price: 6.35, to_buy: 3, buy_vol: 130400
    after cash:1656180
    code
    002368     19000.0
    002424     18900.0
    002522     49300.0
    002549     52200.0
    002638     48200.0
    300085     34400.0
    300202     28900.0
    300288      8300.0
    300322     36700.0
    600221    401500.0
    600340     33000.0
    600570     20600.0
    600967     55700.0
    601989    130400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20150122 ticker: 002368 to sell begin------------
    before cash: 1656180, price: 52.5, sell_vol: 19000
    after cash:2652433
    code
    002424     18900.0
    002522     49300.0
    002549     52200.0
    002638     48200.0
    300085     34400.0
    300202     28900.0
    300288      8300.0
    300322     36700.0
    600221    401500.0
    600340     33000.0
    600570     20600.0
    600967     55700.0
    601989    130400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150122 ticker: 002424 to sell begin------------
    before cash: 2652433, price: 44.41, sell_vol: 18900
    after cash:3490733
    code
    002522     49300.0
    002549     52200.0
    002638     48200.0
    300085     34400.0
    300202     28900.0
    300288      8300.0
    300322     36700.0
    600221    401500.0
    600340     33000.0
    600570     20600.0
    600967     55700.0
    601989    130400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150122 ticker: 002522 to sell begin------------
    before cash: 3490733, price: 17.41, sell_vol: 49300
    after cash:4347973
    code
    002549     52200.0
    002638     48200.0
    300085     34400.0
    300202     28900.0
    300288      8300.0
    300322     36700.0
    600221    401500.0
    600340     33000.0
    600570     20600.0
    600967     55700.0
    601989    130400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150122 ticker: 002549 to sell begin------------
    before cash: 4347973, price: 13.78, sell_vol: 52200
    after cash:5066390
    code
    002638     48200.0
    300085     34400.0
    300202     28900.0
    300288      8300.0
    300322     36700.0
    600221    401500.0
    600340     33000.0
    600570     20600.0
    600967     55700.0
    601989    130400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150122 ticker: 002638 to sell begin------------
    before cash: 5066390, price: 13.26, sell_vol: 48200
    after cash:5704723
    code
    300085     34400.0
    300202     28900.0
    300288      8300.0
    300322     36700.0
    600221    401500.0
    600340     33000.0
    600570     20600.0
    600967     55700.0
    601989    130400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150122 ticker: 300085 to sell begin------------
    before cash: 5704723, price: 64.18, sell_vol: 34400
    after cash:7909755
    code
    300202     28900.0
    300288      8300.0
    300322     36700.0
    600221    401500.0
    600340     33000.0
    600570     20600.0
    600967     55700.0
    601989    130400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150122 ticker: 300202 to sell begin------------
    before cash: 7909755, price: 30.16, sell_vol: 28900
    after cash:8780290
    code
    300288      8300.0
    300322     36700.0
    600221    401500.0
    600340     33000.0
    600570     20600.0
    600967     55700.0
    601989    130400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150122 ticker: 300288 to sell begin------------
    before cash: 8780290, price: 193.0, sell_vol: 8300
    after cash:10380187
    code
    300322     36700.0
    600221    401500.0
    600340     33000.0
    600570     20600.0
    600967     55700.0
    601989    130400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150122 ticker: 300322 to sell begin------------
    before cash: 10380187, price: 21.82, sell_vol: 36700
    after cash:11179980
    code
    600221    401500.0
    600340     33000.0
    600570     20600.0
    600967     55700.0
    601989    130400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150122 ticker: 600221 to sell begin------------
    before cash: 11179980, price: 3.37, sell_vol: 401500
    after cash:12531344
    code
    600340     33000.0
    600570     20600.0
    600967     55700.0
    601989    130400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150122 ticker: 600340 to sell begin------------
    before cash: 12531344, price: 49.91, sell_vol: 33000
    after cash:14176315
    code
    600570     20600.0
    600967     55700.0
    601989    130400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150122 ticker: 600570 to sell begin------------
    before cash: 14176315, price: 61.28, sell_vol: 20600
    after cash:15437105
    code
    600967     55700.0
    601989    130400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150122 ticker: 600967 to sell begin------------
    before cash: 15437105, price: 14.44, sell_vol: 55700
    after cash:16240408
    code
    601989    130400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150122 ticker: 601989 to sell begin------------
    before cash: 16240408, price: 9.12, sell_vol: 130400
    after cash:17428169
    Series([], Name: amount, dtype: float64)
    at 20150122 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20150123 ticker: 000791 to buy begin--------------
    to_buy:  
    ['600888', '002368', '600125', '000791', '000024', '600367', '600048']
    before cash: 17428169, price: 12.49, to_buy: 7, buy_vol: 199300
    after cash:14938290
    code
    000791    199300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20150123 ticker: 002368 to buy begin--------------
    to_buy:  
    ['600888', '002368', '000024', '600367', '600125', '600048']
    before cash: 14938290, price: 50.0, to_buy: 6, buy_vol: 49700
    after cash:12452669
    code
    000791    199300.0
    002368     49700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20150123 ticker: 600048 to buy begin--------------
    to_buy:  
    ['600888', '000024', '600367', '600125', '600048']
    before cash: 12452669, price: 11.43, to_buy: 5, buy_vol: 217800
    after cash:9962592
    code
    000791    199300.0
    002368     49700.0
    600048    217800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20150123 ticker: 600125 to buy begin--------------
    to_buy:  
    ['600888', '600367', '600125', '000024']
    before cash: 9962592, price: 8.35, to_buy: 4, buy_vol: 298200
    after cash:7472000
    code
    000791    199300.0
    002368     49700.0
    600048    217800.0
    600125    298200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20150123 ticker: 600367 to buy begin--------------
    to_buy:  
    ['600888', '600367', '000024']
    before cash: 7472000, price: 11.1, to_buy: 3, buy_vol: 224300
    after cash:4981647
    code
    000791    199300.0
    002368     49700.0
    600048    217800.0
    600125    298200.0
    600367    224300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20150123 ticker: 600888 to buy begin--------------
    to_buy:  
    ['600888', '000024']
    before cash: 4981647, price: 7.04, to_buy: 2, buy_vol: 353800
    after cash:2490273
    code
    000791    199300.0
    002368     49700.0
    600048    217800.0
    600125    298200.0
    600367    224300.0
    600888    353800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20150422 ticker: 000791 to sell begin------------
    before cash: 2490273, price: 15.41, sell_vol: 199300
    after cash:5557647
    code
    002368     49700.0
    600048    217800.0
    600125    298200.0
    600367    224300.0
    600888    353800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150422 ticker: 002368 to sell begin------------
    before cash: 5557647, price: 77.88, sell_vol: 49700
    after cash:9423444
    code
    600048    217800.0
    600125    298200.0
    600367    224300.0
    600888    353800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150422 ticker: 600048 to sell begin------------
    before cash: 9423444, price: 14.06, sell_vol: 217800
    after cash:12481885
    code
    600125    298200.0
    600367    224300.0
    600888    353800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150422 ticker: 600125 to sell begin------------
    before cash: 12481885, price: 13.88, sell_vol: 298200
    after cash:16615727
    code
    600367    224300.0
    600888    353800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150422 ticker: 600367 to sell begin------------
    before cash: 16615727, price: 15.11, sell_vol: 224300
    after cash:20000663
    code
    600888    353800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150422 ticker: 600888 to sell begin------------
    before cash: 20000663, price: 12.57, sell_vol: 353800
    after cash:24442370
    Series([], Name: amount, dtype: float64)
    at 20150422 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20150423 ticker: 002081 to buy begin--------------
    to_buy:  
    ['300288', '002081', '600888', '002368', '300059', '002522', '600367', '600007', '300399', '600703', '000150']
    before cash: 24442370, price: 33.5, to_buy: 11, buy_vol: 66300
    after cash:22220765
    code
    002081    66300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20150423 ticker: 002368 to buy begin--------------
    to_buy:  
    ['300288', '600888', '002368', '300059', '002522', '600367', '600007', '300399', '600703', '000150']
    before cash: 22220765, price: 79.5, to_buy: 10, buy_vol: 27900
    after cash:20002161
    code
    002081    66300.0
    002368    27900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20150423 ticker: 002522 to buy begin--------------
    to_buy:  
    ['300288', '600888', '300059', '002522', '600367', '600007', '300399', '600703', '000150']
    before cash: 20002161, price: 47.9, to_buy: 9, buy_vol: 46300
    after cash:17783836
    code
    002081    66300.0
    002368    27900.0
    002522    46300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20150423 ticker: 300059 to buy begin--------------
    to_buy:  
    ['300288', '600888', '300059', '600367', '600007', '300399', '600703', '000150']
    before cash: 17783836, price: 52.13, to_buy: 8, buy_vol: 42600
    after cash:15562543
    code
    002081    66300.0
    002368    27900.0
    002522    46300.0
    300059    42600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20150423 ticker: 300288 to buy begin--------------
    to_buy:  
    ['300288', '600888', '600367', '600007', '300399', '600703', '000150']
    before cash: 15562543, price: 77.8, to_buy: 7, buy_vol: 28500
    after cash:13344689
    code
    002081    66300.0
    002368    27900.0
    002522    46300.0
    300059    42600.0
    300288    28500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20150423 ticker: 300399 to buy begin--------------
    to_buy:  
    ['600888', '600367', '600007', '300399', '600703', '000150']
    before cash: 13344689, price: 213.02, to_buy: 6, buy_vol: 10400
    after cash:11128727
    code
    002081    66300.0
    002368    27900.0
    002522    46300.0
    300059    42600.0
    300288    28500.0
    300399    10400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20150423 ticker: 600007 to buy begin--------------
    to_buy:  
    ['600888', '600367', '600007', '600703', '000150']
    before cash: 11128727, price: 18.33, to_buy: 5, buy_vol: 121400
    after cash:8902908
    code
    002081     66300.0
    002368     27900.0
    002522     46300.0
    300059     42600.0
    300288     28500.0
    300399     10400.0
    600007    121400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20150423 ticker: 600367 to buy begin--------------
    to_buy:  
    ['600888', '600367', '600703', '000150']
    before cash: 8902908, price: 15.5, to_buy: 4, buy_vol: 143500
    after cash:6678102
    code
    002081     66300.0
    002368     27900.0
    002522     46300.0
    300059     42600.0
    300288     28500.0
    300399     10400.0
    600007    121400.0
    600367    143500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20150423 ticker: 600703 to buy begin--------------
    to_buy:  
    ['600888', '600703', '000150']
    before cash: 6678102, price: 23.88, to_buy: 3, buy_vol: 93200
    after cash:4451930
    code
    002081     66300.0
    002368     27900.0
    002522     46300.0
    300059     42600.0
    300288     28500.0
    300399     10400.0
    600007    121400.0
    600367    143500.0
    600703     93200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20150423 ticker: 600888 to buy begin--------------
    to_buy:  
    ['600888', '000150']
    before cash: 4451930, price: 12.91, to_buy: 2, buy_vol: 172400
    after cash:2225690
    code
    002081     66300.0
    002368     27900.0
    002522     46300.0
    300059     42600.0
    300288     28500.0
    300399     10400.0
    600007    121400.0
    600367    143500.0
    600703     93200.0
    600888    172400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2015-05-06  002522      1.0         10.0    0.0       0.0
    分红，增加现金4630.0
    转增股，增加股票46300.0股002522
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2015-06-19  600007      2.0          0.0    0.0       0.0
    分红，增加现金24280.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2015-06-26  600703      2.0          0.0    0.0       0.0
    分红，增加现金18640.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2015-07-10  600367     0.26          0.0    0.0       0.0
    分红，增加现金3731.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20150721 ticker: 002081 to sell begin------------
    before cash: 2276966, price: 27.98, sell_vol: 66300
    after cash:4129721
    code
    002368     27900.0
    002522     92600.0
    300059     42600.0
    300288     28500.0
    300399     10400.0
    600007    121400.0
    600367    143500.0
    600703     93200.0
    600888    172400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150721 ticker: 002522 to sell begin------------
    before cash: 4129721, price: 25.97, sell_vol: 92600
    after cash:6531537
    code
    002368     27900.0
    300059     42600.0
    300288     28500.0
    300399     10400.0
    600007    121400.0
    600367    143500.0
    600703     93200.0
    600888    172400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150721 ticker: 300059 to sell begin------------
    before cash: 6531537, price: 60.21, sell_vol: 42600
    after cash:9093276
    code
    002368     27900.0
    300288     28500.0
    300399     10400.0
    600007    121400.0
    600367    143500.0
    600703     93200.0
    600888    172400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150721 ticker: 300288 to sell begin------------
    before cash: 9093276, price: 60.7, sell_vol: 28500
    after cash:10821064
    code
    002368     27900.0
    300399     10400.0
    600007    121400.0
    600367    143500.0
    600703     93200.0
    600888    172400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150721 ticker: 300399 to sell begin------------
    before cash: 10821064, price: 101.9, sell_vol: 10400
    after cash:11879499
    code
    002368     27900.0
    600007    121400.0
    600367    143500.0
    600703     93200.0
    600888    172400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150721 ticker: 600007 to sell begin------------
    before cash: 11879499, price: 13.7, sell_vol: 121400
    after cash:13540600
    code
    002368     27900.0
    600367    143500.0
    600703     93200.0
    600888    172400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150721 ticker: 600367 to sell begin------------
    before cash: 13540600, price: 10.37, sell_vol: 143500
    after cash:15026835
    code
    002368     27900.0
    600703     93200.0
    600888    172400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150721 ticker: 600703 to sell begin------------
    before cash: 15026835, price: 30.16, sell_vol: 93200
    after cash:17834234
    code
    002368     27900.0
    600888    172400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20150721 ticker: 600888 to sell begin------------
    before cash: 17834234, price: 9.19, sell_vol: 172400
    after cash:19416609
    code
    002368    27900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20150722 ticker: 002055 to buy begin--------------
    to_buy:  
    ['002055', '002030', '002331', '002707', '002183', '601111', '002276', '002415', '002153', '601021', '600066', '603678', '002739', '600703', '000150']
    before cash: 19416609, price: 49.27, to_buy: 15, buy_vol: 26200
    after cash:18125412
    code
    002055    26200.0
    002368    27900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20150722 ticker: 002153 to buy begin--------------
    to_buy:  
    ['002030', '002331', '002707', '002183', '601111', '002276', '002415', '002153', '601021', '600066', '603678', '002739', '600703', '000150']
    before cash: 18125412, price: 123.98, to_buy: 14, buy_vol: 10400
    after cash:16835698
    code
    002055    26200.0
    002153    10400.0
    002368    27900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20150722 ticker: 002331 to buy begin--------------
    to_buy:  
    ['002739', '600703', '002331', '002030', '002707', '002183', '002276', '601021', '002415', '600066', '601111', '603678', '000150']
    before cash: 16835698, price: 26.41, to_buy: 13, buy_vol: 49000
    after cash:15541285
    code
    002055    26200.0
    002153    10400.0
    002331    49000.0
    002368    27900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20150722 ticker: 002707 to buy begin--------------
    to_buy:  
    ['002739', '600703', '002030', '002276', '002707', '002183', '601021', '002415', '600066', '601111', '603678', '000150']
    before cash: 15541285, price: 95.54, to_buy: 12, buy_vol: 13500
    after cash:14251172
    code
    002055    26200.0
    002153    10400.0
    002331    49000.0
    002368    27900.0
    002707    13500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20150722 ticker: 002739 to buy begin--------------
    to_buy:  
    ['002739', '600703', '002030', '002276', '002183', '601021', '002415', '600066', '601111', '603678', '000150']
    before cash: 14251172, price: 211.27, to_buy: 11, buy_vol: 6100
    after cash:12962103
    code
    002055    26200.0
    002153    10400.0
    002331    49000.0
    002368    27900.0
    002707    13500.0
    002739     6100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20150722 ticker: 600066 to buy begin--------------
    to_buy:  
    ['600703', '002030', '002276', '002183', '601021', '002415', '600066', '601111', '603678', '000150']
    before cash: 12962103, price: 19.77, to_buy: 10, buy_vol: 65500
    after cash:11666844
    code
    002055    26200.0
    002153    10400.0
    002331    49000.0
    002368    27900.0
    002707    13500.0
    002739     6100.0
    600066    65500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20150722 ticker: 600703 to buy begin--------------
    to_buy:  
    ['600703', '002030', '002276', '002183', '601021', '002415', '601111', '603678', '000150']
    before cash: 11666844, price: 30.99, to_buy: 9, buy_vol: 41800
    after cash:10371138
    code
    002055    26200.0
    002153    10400.0
    002331    49000.0
    002368    27900.0
    002707    13500.0
    002739     6100.0
    600066    65500.0
    600703    41800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20150722 ticker: 601021 to buy begin--------------
    to_buy:  
    ['002030', '002276', '002183', '601021', '002415', '601111', '603678', '000150']
    before cash: 10371138, price: 121.13, to_buy: 8, buy_vol: 10700
    after cash:9074723
    code
    002055    26200.0
    002153    10400.0
    002331    49000.0
    002368    27900.0
    002707    13500.0
    002739     6100.0
    600066    65500.0
    600703    41800.0
    601021    10700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20150722 ticker: 603678 to buy begin--------------
    to_buy:  
    ['002030', '002276', '002183', '002415', '601111', '603678', '000150']
    before cash: 9074723, price: 91.71, to_buy: 7, buy_vol: 14100
    after cash:7781289
    code
    002055    26200.0
    002153    10400.0
    002331    49000.0
    002368    27900.0
    002707    13500.0
    002739     6100.0
    600066    65500.0
    600703    41800.0
    601021    10700.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2015-09-29  002707      0.0         10.0    0.0       0.0
    转增股，增加股票13500.0股002707
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2015-10-21  601021      0.0         10.0    0.0       0.0
    转增股，增加股票10700.0股601021
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20151027 ticker: 002055 to sell begin------------
    before cash: 7781279, price: 34.59, sell_vol: 26200
    after cash:8686404
    code
    002153    10400.0
    002331    49000.0
    002368    27900.0
    002707    27000.0
    002739     6100.0
    600066    65500.0
    600703    41800.0
    601021    21400.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20151027 ticker: 002153 to sell begin------------
    before cash: 8686404, price: 108.8, sell_vol: 10400
    after cash:9816510
    code
    002331    49000.0
    002368    27900.0
    002707    27000.0
    002739     6100.0
    600066    65500.0
    600703    41800.0
    601021    21400.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20151027 ticker: 002331 to sell begin------------
    before cash: 9816510, price: 21.03, sell_vol: 49000
    after cash:10845692
    code
    002368    27900.0
    002707    27000.0
    002739     6100.0
    600066    65500.0
    600703    41800.0
    601021    21400.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20151027 ticker: 002707 to sell begin------------
    before cash: 10845692, price: 47.3, sell_vol: 27000
    after cash:12121195
    code
    002368    27900.0
    002739     6100.0
    600066    65500.0
    600703    41800.0
    601021    21400.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20151027 ticker: 002739 to sell begin------------
    before cash: 12121195, price: 101.0, sell_vol: 6100
    after cash:12736525
    code
    002368    27900.0
    600066    65500.0
    600703    41800.0
    601021    21400.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20151027 ticker: 600066 to sell begin------------
    before cash: 12736525, price: 22.19, sell_vol: 65500
    after cash:14188153
    code
    002368    27900.0
    600703    41800.0
    601021    21400.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20151027 ticker: 600703 to sell begin------------
    before cash: 14188153, price: 24.86, sell_vol: 41800
    after cash:15226003
    code
    002368    27900.0
    601021    21400.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20151027 ticker: 601021 to sell begin------------
    before cash: 15226003, price: 61.79, sell_vol: 21400
    after cash:16546656
    code
    002368    27900.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20151028 ticker: 000150 to buy begin--------------
    to_buy:  
    ['002517', '002739', '002030', '002707', '600276', '002450', '600066', '000963', '002415', '000150']
    before cash: 16546656, price: 39.1, to_buy: 10, buy_vol: 42300
    after cash:14892312
    code
    000150    42300.0
    002368    27900.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20151028 ticker: 000963 to buy begin--------------
    to_buy:  
    ['002517', '002739', '002030', '002707', '600276', '002450', '600066', '000963', '002415']
    before cash: 14892312, price: 76.5, to_buy: 9, buy_vol: 21600
    after cash:13239499
    code
    000150    42300.0
    000963    21600.0
    002368    27900.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20151028 ticker: 002030 to buy begin--------------
    to_buy:  
    ['002517', '002739', '002030', '002707', '600276', '002450', '600066', '002415']
    before cash: 13239499, price: 45.2, to_buy: 8, buy_vol: 36600
    after cash:11584765
    code
    000150    42300.0
    000963    21600.0
    002030    36600.0
    002368    27900.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20151028 ticker: 002415 to buy begin--------------
    to_buy:  
    ['002517', '002739', '002707', '600276', '002450', '600066', '002415']
    before cash: 11584765, price: 33.58, to_buy: 7, buy_vol: 49200
    after cash:9932216
    code
    000150    42300.0
    000963    21600.0
    002030    36600.0
    002368    27900.0
    002415    49200.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20151028 ticker: 002517 to buy begin--------------
    to_buy:  
    ['002517', '002739', '002707', '600276', '600066', '002450']
    before cash: 9932216, price: 51.14, to_buy: 6, buy_vol: 32300
    after cash:8279981
    code
    000150    42300.0
    000963    21600.0
    002030    36600.0
    002368    27900.0
    002415    49200.0
    002517    32300.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20151028 ticker: 002707 to buy begin--------------
    to_buy:  
    ['002707', '600276', '002450', '600066', '002739']
    before cash: 8279981, price: 44.65, to_buy: 5, buy_vol: 37000
    after cash:6627518
    code
    000150    42300.0
    000963    21600.0
    002030    36600.0
    002368    27900.0
    002415    49200.0
    002517    32300.0
    002707    37000.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20151028 ticker: 002739 to buy begin--------------
    to_buy:  
    ['002739', '002450', '600066', '600276']
    before cash: 6627518, price: 97.01, to_buy: 4, buy_vol: 17000
    after cash:4977936
    code
    000150    42300.0
    000963    21600.0
    002030    36600.0
    002368    27900.0
    002415    49200.0
    002517    32300.0
    002707    37000.0
    002739    17000.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20151028 ticker: 600066 to buy begin--------------
    to_buy:  
    ['002450', '600066', '600276']
    before cash: 4977936, price: 21.9, to_buy: 3, buy_vol: 75700
    after cash:3319692
    code
    000150    42300.0
    000963    21600.0
    002030    36600.0
    002368    27900.0
    002415    49200.0
    002517    32300.0
    002707    37000.0
    002739    17000.0
    600066    75700.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20151028 ticker: 600276 to buy begin--------------
    to_buy:  
    ['002450', '600276']
    before cash: 3319692, price: 51.87, to_buy: 2, buy_vol: 32000
    after cash:1659437
    code
    000150    42300.0
    000963    21600.0
    002030    36600.0
    002368    27900.0
    002415    49200.0
    002517    32300.0
    002707    37000.0
    002739    17000.0
    600066    75700.0
    600276    32000.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20160122 ticker: 000150 to sell begin------------
    before cash: 1659437, price: 28.5, sell_vol: 42300
    after cash:2863480
    code
    000963    21600.0
    002030    36600.0
    002368    27900.0
    002415    49200.0
    002517    32300.0
    002707    37000.0
    002739    17000.0
    600066    75700.0
    600276    32000.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160122 ticker: 000963 to sell begin------------
    before cash: 2863480, price: 71.0, sell_vol: 21600
    after cash:4395163
    code
    002030    36600.0
    002368    27900.0
    002415    49200.0
    002517    32300.0
    002707    37000.0
    002739    17000.0
    600066    75700.0
    600276    32000.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160122 ticker: 002030 to sell begin------------
    before cash: 4395163, price: 32.8, sell_vol: 36600
    after cash:5594142
    code
    002368    27900.0
    002415    49200.0
    002517    32300.0
    002707    37000.0
    002739    17000.0
    600066    75700.0
    600276    32000.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160122 ticker: 002368 to sell begin------------
    before cash: 5594142, price: 47.21, sell_vol: 27900
    after cash:6909655
    code
    002415    49200.0
    002517    32300.0
    002707    37000.0
    002739    17000.0
    600066    75700.0
    600276    32000.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160122 ticker: 002415 to sell begin------------
    before cash: 6909655, price: 25.97, sell_vol: 49200
    after cash:8185782
    code
    002517    32300.0
    002707    37000.0
    002739    17000.0
    600066    75700.0
    600276    32000.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160122 ticker: 002517 to sell begin------------
    before cash: 8185782, price: 48.78, sell_vol: 32300
    after cash:9759406
    code
    002707    37000.0
    002739    17000.0
    600066    75700.0
    600276    32000.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160122 ticker: 002739 to sell begin------------
    before cash: 9759406, price: 89.6, sell_vol: 17000
    after cash:11280702
    code
    002707    37000.0
    600066    75700.0
    600276    32000.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160122 ticker: 600066 to sell begin------------
    before cash: 11280702, price: 18.69, sell_vol: 75700
    after cash:12693767
    code
    002707    37000.0
    600276    32000.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160122 ticker: 600276 to sell begin------------
    before cash: 12693767, price: 43.32, sell_vol: 32000
    after cash:14078274
    code
    002707    37000.0
    603678    14100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160122 ticker: 603678 to sell begin------------
    before cash: 14078274, price: 59.61, sell_vol: 14100
    after cash:14917724
    code
    002707    37000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20160125 ticker: 000150 to buy begin--------------
    to_buy:  
    ['002183', '300285', '300054', '000018', '002739', '300113', '000150', '002292', '300144', '600900', '300188', '002153', '600745', '002329', '002456']
    before cash: 14917724, price: 28.49, to_buy: 15, buy_vol: 34900
    after cash:13923175
    code
    000150    34900.0
    002707    37000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160125 ticker: 002153 to buy begin--------------
    to_buy:  
    ['002183', '300285', '300054', '000018', '002739', '300113', '002292', '300144', '600900', '300188', '002153', '600745', '002329', '002456']
    before cash: 13923175, price: 89.24, to_buy: 14, buy_vol: 11100
    after cash:12932363
    code
    000150    34900.0
    002153    11100.0
    002707    37000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160125 ticker: 002183 to buy begin--------------
    to_buy:  
    ['002183', '300285', '300054', '000018', '002739', '300113', '002292', '300144', '600900', '300188', '600745', '002329', '002456']
    before cash: 12932363, price: 30.56, to_buy: 13, buy_vol: 32500
    after cash:11938915
    code
    000150    34900.0
    002153    11100.0
    002183    32500.0
    002707    37000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160125 ticker: 002292 to buy begin--------------
    to_buy:  
    ['002292', '002739', '300144', '600900', '300188', '300285', '300054', '600745', '000018', '002329', '002456', '300113']
    before cash: 11938915, price: 36.17, to_buy: 12, buy_vol: 27500
    after cash:10943991
    code
    000150    34900.0
    002153    11100.0
    002183    32500.0
    002292    27500.0
    002707    37000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160125 ticker: 002329 to buy begin--------------
    to_buy:  
    ['002739', '300144', '600900', '300188', '300285', '300054', '600745', '000018', '002329', '002456', '300113']
    before cash: 10943991, price: 18.46, to_buy: 11, buy_vol: 53800
    after cash:9950595
    code
    000150    34900.0
    002153    11100.0
    002183    32500.0
    002292    27500.0
    002329    53800.0
    002707    37000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160125 ticker: 002456 to buy begin--------------
    to_buy:  
    ['300144', '600900', '300188', '300285', '300054', '600745', '000018', '002739', '002456', '300113']
    before cash: 9950595, price: 24.6, to_buy: 10, buy_vol: 40400
    after cash:8956506
    code
    000150    34900.0
    002153    11100.0
    002183    32500.0
    002292    27500.0
    002329    53800.0
    002456    40400.0
    002707    37000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160125 ticker: 002739 to buy begin--------------
    to_buy:  
    ['300144', '600900', '300188', '300285', '300054', '600745', '000018', '002739', '300113']
    before cash: 8956506, price: 86.72, to_buy: 9, buy_vol: 11400
    after cash:7967651
    code
    000150    34900.0
    002153    11100.0
    002183    32500.0
    002292    27500.0
    002329    53800.0
    002456    40400.0
    002707    37000.0
    002739    11400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160125 ticker: 300113 to buy begin--------------
    to_buy:  
    ['300144', '600900', '300188', '300285', '300054', '600745', '000018', '300113']
    before cash: 7967651, price: 77.01, to_buy: 8, buy_vol: 12900
    after cash:6973974
    code
    000150    34900.0
    002153    11100.0
    002183    32500.0
    002292    27500.0
    002329    53800.0
    002456    40400.0
    002707    37000.0
    002739    11400.0
    300113    12900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160125 ticker: 300144 to buy begin--------------
    to_buy:  
    ['300144', '600900', '300188', '300285', '300054', '600745', '000018']
    before cash: 6973974, price: 24.18, to_buy: 7, buy_vol: 41200
    after cash:5977509
    code
    000150    34900.0
    002153    11100.0
    002183    32500.0
    002292    27500.0
    002329    53800.0
    002456    40400.0
    002707    37000.0
    002739    11400.0
    300113    12900.0
    300144    41200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160125 ticker: 300188 to buy begin--------------
    to_buy:  
    ['600900', '300188', '300285', '300054', '600745', '000018']
    before cash: 5977509, price: 30.06, to_buy: 6, buy_vol: 33100
    after cash:4982274
    code
    000150    34900.0
    002153    11100.0
    002183    32500.0
    002292    27500.0
    002329    53800.0
    002456    40400.0
    002707    37000.0
    002739    11400.0
    300113    12900.0
    300144    41200.0
    300188    33100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160125 ticker: 300285 to buy begin--------------
    to_buy:  
    ['600900', '300285', '300054', '600745', '000018']
    before cash: 4982274, price: 30.89, to_buy: 5, buy_vol: 32200
    after cash:3987367
    code
    000150    34900.0
    002153    11100.0
    002183    32500.0
    002292    27500.0
    002329    53800.0
    002456    40400.0
    002707    37000.0
    002739    11400.0
    300113    12900.0
    300144    41200.0
    300188    33100.0
    300285    32200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160125 ticker: 600745 to buy begin--------------
    to_buy:  
    ['300054', '600900', '600745', '000018']
    before cash: 3987367, price: 26.97, to_buy: 4, buy_vol: 36900
    after cash:2991925
    code
    000150    34900.0
    002153    11100.0
    002183    32500.0
    002292    27500.0
    002329    53800.0
    002456    40400.0
    002707    37000.0
    002739    11400.0
    300113    12900.0
    300144    41200.0
    300188    33100.0
    300285    32200.0
    600745    36900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160125 ticker: 600900 to buy begin--------------
    to_buy:  
    ['300054', '600900', '000018']
    before cash: 2991925, price: 12.53, to_buy: 3, buy_vol: 79500
    after cash:1995541
    code
    000150    34900.0
    002153    11100.0
    002183    32500.0
    002292    27500.0
    002329    53800.0
    002456    40400.0
    002707    37000.0
    002739    11400.0
    300113    12900.0
    300144    41200.0
    300188    33100.0
    300285    32200.0
    600745    36900.0
    600900    79500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2016-04-07  300144      0.7          0.0    0.0       0.0
    分红，增加现金2884.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20160422 ticker: 000150 to sell begin------------
    before cash: 1998425, price: 29.03, sell_vol: 34900
    after cash:3010306
    code
    002153    11100.0
    002183    32500.0
    002292    27500.0
    002329    53800.0
    002456    40400.0
    002707    37000.0
    002739    11400.0
    300113    12900.0
    300144    41200.0
    300188    33100.0
    300285    32200.0
    600745    36900.0
    600900    79500.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160422 ticker: 002153 to sell begin------------
    before cash: 3010306, price: 84.83, sell_vol: 11100
    after cash:3950742
    code
    002183    32500.0
    002292    27500.0
    002329    53800.0
    002456    40400.0
    002707    37000.0
    002739    11400.0
    300113    12900.0
    300144    41200.0
    300188    33100.0
    300285    32200.0
    600745    36900.0
    600900    79500.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160422 ticker: 002183 to sell begin------------
    before cash: 3950742, price: 27.17, sell_vol: 32500
    after cash:4832663
    code
    002292    27500.0
    002329    53800.0
    002456    40400.0
    002707    37000.0
    002739    11400.0
    300113    12900.0
    300144    41200.0
    300188    33100.0
    300285    32200.0
    600745    36900.0
    600900    79500.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160422 ticker: 002292 to sell begin------------
    before cash: 4832663, price: 34.91, sell_vol: 27500
    after cash:5791488
    code
    002329    53800.0
    002456    40400.0
    002707    37000.0
    002739    11400.0
    300113    12900.0
    300144    41200.0
    300188    33100.0
    300285    32200.0
    600745    36900.0
    600900    79500.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160422 ticker: 002329 to sell begin------------
    before cash: 5791488, price: 14.43, sell_vol: 53800
    after cash:6566852
    code
    002456    40400.0
    002707    37000.0
    002739    11400.0
    300113    12900.0
    300144    41200.0
    300188    33100.0
    300285    32200.0
    600745    36900.0
    600900    79500.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160422 ticker: 002456 to sell begin------------
    before cash: 6566852, price: 26.2, sell_vol: 40400
    after cash:7624009
    code
    002707    37000.0
    002739    11400.0
    300113    12900.0
    300144    41200.0
    300188    33100.0
    300285    32200.0
    600745    36900.0
    600900    79500.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2016-04-22  002707      0.5         10.0    0.0       0.0
    分红，增加现金1850.0
    转增股，增加股票37000.0股002707
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    -------today:20160422 ticker: 002707 to sell begin------------
    before cash: 7625854, price: 21.3, sell_vol: 74000
    after cash:9200083
    code
    002739    11400.0
    300113    12900.0
    300144    41200.0
    300188    33100.0
    300285    32200.0
    600745    36900.0
    600900    79500.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160422 ticker: 300113 to sell begin------------
    before cash: 9200083, price: 86.0, sell_vol: 12900
    after cash:10308097
    code
    002739    11400.0
    300144    41200.0
    300188    33100.0
    300285    32200.0
    600745    36900.0
    600900    79500.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160422 ticker: 300144 to sell begin------------
    before cash: 10308097, price: 26.85, sell_vol: 41200
    after cash:11412934
    code
    002739    11400.0
    300188    33100.0
    300285    32200.0
    600745    36900.0
    600900    79500.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160422 ticker: 300188 to sell begin------------
    before cash: 11412934, price: 27.6, sell_vol: 33100
    after cash:12325352
    code
    002739    11400.0
    300285    32200.0
    600745    36900.0
    600900    79500.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160422 ticker: 600900 to sell begin------------
    before cash: 12325352, price: 12.33, sell_vol: 79500
    after cash:13304362
    code
    002739    11400.0
    300285    32200.0
    600745    36900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20160425 ticker: 000625 to buy begin--------------
    to_buy:  
    ['300383', '600887', '000651', '300054', '000963', '002450', '002366', '300113', '000002', '600276', '002153', '002045', '600066', '002475', '000625', '002415', '002456']
    before cash: 13304362, price: 15.78, to_buy: 17, buy_vol: 49500
    after cash:12523056
    code
    000625    49500.0
    002739    11400.0
    300285    32200.0
    600745    36900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160425 ticker: 000963 to buy begin--------------
    to_buy:  
    ['000002', '300383', '600887', '000651', '600276', '002153', '002045', '300054', '002415', '600066', '002475', '000963', '002450', '002366', '002456', '300113']
    before cash: 12523056, price: 67.75, to_buy: 16, buy_vol: 11500
    after cash:11743737
    code
    000625    49500.0
    000963    11500.0
    002739    11400.0
    300285    32200.0
    600745    36900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160425 ticker: 002045 to buy begin--------------
    to_buy:  
    ['000002', '300383', '600887', '000651', '600276', '002153', '002045', '300054', '002415', '600066', '002475', '002450', '002366', '002456', '300113']
    before cash: 11743737, price: 11.96, to_buy: 15, buy_vol: 65400
    after cash:10961357
    code
    000625    49500.0
    000963    11500.0
    002045    65400.0
    002739    11400.0
    300285    32200.0
    600745    36900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160425 ticker: 002153 to buy begin--------------
    to_buy:  
    ['000002', '300383', '600887', '000651', '600276', '002153', '300054', '002415', '600066', '002475', '002450', '002366', '002456', '300113']
    before cash: 10961357, price: 84.63, to_buy: 14, buy_vol: 9200
    after cash:10182566
    code
    000625    49500.0
    000963    11500.0
    002045    65400.0
    002153     9200.0
    002739    11400.0
    300285    32200.0
    600745    36900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160425 ticker: 002415 to buy begin--------------
    to_buy:  
    ['000002', '300383', '600887', '000651', '600276', '300054', '002415', '600066', '002475', '002450', '002366', '002456', '300113']
    before cash: 10182566, price: 31.21, to_buy: 13, buy_vol: 25000
    after cash:9402121
    code
    000625    49500.0
    000963    11500.0
    002045    65400.0
    002153     9200.0
    002415    25000.0
    002739    11400.0
    300285    32200.0
    600745    36900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160425 ticker: 002456 to buy begin--------------
    to_buy:  
    ['000002', '300383', '600887', '000651', '600276', '300054', '600066', '002475', '002450', '002366', '002456', '300113']
    before cash: 9402121, price: 26.52, to_buy: 12, buy_vol: 29500
    after cash:8619586
    code
    000625    49500.0
    000963    11500.0
    002045    65400.0
    002153     9200.0
    002415    25000.0
    002456    29500.0
    002739    11400.0
    300285    32200.0
    600745    36900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160425 ticker: 002475 to buy begin--------------
    to_buy:  
    ['000002', '300383', '600887', '000651', '600276', '300054', '600066', '002475', '002450', '002366', '300113']
    before cash: 8619586, price: 27.93, to_buy: 11, buy_vol: 28000
    after cash:7837350
    code
    000625    49500.0
    000963    11500.0
    002045    65400.0
    002153     9200.0
    002415    25000.0
    002456    29500.0
    002475    28000.0
    002739    11400.0
    300285    32200.0
    600745    36900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160425 ticker: 300054 to buy begin--------------
    to_buy:  
    ['000002', '300383', '600887', '000651', '600276', '300054', '600066', '002450', '002366', '300113']
    before cash: 7837350, price: 19.35, to_buy: 10, buy_vol: 40500
    after cash:7053479
    code
    000625    49500.0
    000963    11500.0
    002045    65400.0
    002153     9200.0
    002415    25000.0
    002456    29500.0
    002475    28000.0
    002739    11400.0
    300054    40500.0
    300285    32200.0
    600745    36900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160425 ticker: 300113 to buy begin--------------
    to_buy:  
    ['000002', '300383', '600887', '000651', '600276', '600066', '002450', '002366', '300113']
    before cash: 7053479, price: 84.55, to_buy: 9, buy_vol: 9200
    after cash:6275425
    code
    000625    49500.0
    000963    11500.0
    002045    65400.0
    002153     9200.0
    002415    25000.0
    002456    29500.0
    002475    28000.0
    002739    11400.0
    300054    40500.0
    300113     9200.0
    300285    32200.0
    600745    36900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160425 ticker: 300383 to buy begin--------------
    to_buy:  
    ['000002', '300383', '600887', '000651', '600276', '600066', '002450', '002366']
    before cash: 6275425, price: 34.71, to_buy: 8, buy_vol: 22500
    after cash:5494255
    code
    000625    49500.0
    000963    11500.0
    002045    65400.0
    002153     9200.0
    002415    25000.0
    002456    29500.0
    002475    28000.0
    002739    11400.0
    300054    40500.0
    300113     9200.0
    300285    32200.0
    300383    22500.0
    600745    36900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160425 ticker: 600066 to buy begin--------------
    to_buy:  
    ['000002', '600887', '000651', '600276', '600066', '002450', '002366']
    before cash: 5494255, price: 20.2, to_buy: 7, buy_vol: 38800
    after cash:4710299
    code
    000625    49500.0
    000963    11500.0
    002045    65400.0
    002153     9200.0
    002415    25000.0
    002456    29500.0
    002475    28000.0
    002739    11400.0
    300054    40500.0
    300113     9200.0
    300285    32200.0
    300383    22500.0
    600066    38800.0
    600745    36900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160425 ticker: 600276 to buy begin--------------
    to_buy:  
    ['000002', '600887', '000651', '600276', '002450', '002366']
    before cash: 4710299, price: 46.52, to_buy: 6, buy_vol: 16800
    after cash:3928567
    code
    000625    49500.0
    000963    11500.0
    002045    65400.0
    002153     9200.0
    002415    25000.0
    002456    29500.0
    002475    28000.0
    002739    11400.0
    300054    40500.0
    300113     9200.0
    300285    32200.0
    300383    22500.0
    600066    38800.0
    600276    16800.0
    600745    36900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160425 ticker: 600887 to buy begin--------------
    to_buy:  
    ['000002', '600887', '000651', '002450', '002366']
    before cash: 3928567, price: 14.19, to_buy: 5, buy_vol: 55300
    after cash:3143664
    code
    000625    49500.0
    000963    11500.0
    002045    65400.0
    002153     9200.0
    002415    25000.0
    002456    29500.0
    002475    28000.0
    002739    11400.0
    300054    40500.0
    300113     9200.0
    300285    32200.0
    300383    22500.0
    600066    38800.0
    600276    16800.0
    600745    36900.0
    600887    55300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2016-05-06  600887      4.5          0.0    0.0       0.0
    分红，增加现金24885.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2016-05-11  002153      1.2         20.0    0.0       0.0
    分红，增加现金1104.0
    转增股，增加股票18400.0股002153
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2016-05-18  002415      7.0          5.0    0.0       0.0
    分红，增加现金17500.0
    转增股，增加股票12500.0股002415
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2016-05-23  600066     15.0          0.0    0.0       0.0
    分红，增加现金58200.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2016-06-03  002045      0.8          0.0    0.0       0.0
    分红，增加现金5232.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2016-06-13  002475      0.9          5.0    0.0       0.0
    分红，增加现金2520.0
    转增股，增加股票14000.0股002475
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2016-06-16  000963     12.5          0.0    0.0       0.0
    分红，增加现金14375.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2016-06-16  600276      1.0          2.0    0.0       0.0
    分红，增加现金1680.0
    转增股，增加股票3300.0股600276
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2016-06-17  300285      1.0          0.0    0.0       0.0
    分红，增加现金3220.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2016-06-22  002739      2.0          0.0    0.0       0.0
    分红，增加现金2280.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2016-06-28  000625      6.4          0.0    0.0       0.0
    分红，增加现金31680.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2016-07-01  002456      0.7          0.0    0.0       0.0
    分红，增加现金2065.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20160721 ticker: 000625 to sell begin------------
    before cash: 3308385, price: 15.41, sell_vol: 49500
    after cash:4070227
    code
    000963    11500.0
    002045    65400.0
    002153    27600.0
    002415    37500.0
    002456    29500.0
    002475    42000.0
    002739    11400.0
    300054    40500.0
    300113     9200.0
    300285    32200.0
    300383    22500.0
    600066    38800.0
    600276    20100.0
    600745    36900.0
    600887    55300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160721 ticker: 000963 to sell begin------------
    before cash: 4070227, price: 68.49, sell_vol: 11500
    after cash:4856877
    code
    002045    65400.0
    002153    27600.0
    002415    37500.0
    002456    29500.0
    002475    42000.0
    002739    11400.0
    300054    40500.0
    300113     9200.0
    300285    32200.0
    300383    22500.0
    600066    38800.0
    600276    20100.0
    600745    36900.0
    600887    55300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160721 ticker: 002045 to sell begin------------
    before cash: 4856877, price: 13.72, sell_vol: 65400
    after cash:5753043
    code
    002153    27600.0
    002415    37500.0
    002456    29500.0
    002475    42000.0
    002739    11400.0
    300054    40500.0
    300113     9200.0
    300285    32200.0
    300383    22500.0
    600066    38800.0
    600276    20100.0
    600745    36900.0
    600887    55300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160721 ticker: 002153 to sell begin------------
    before cash: 5753043, price: 28.2, sell_vol: 27600
    after cash:6530391
    code
    002415    37500.0
    002456    29500.0
    002475    42000.0
    002739    11400.0
    300054    40500.0
    300113     9200.0
    300285    32200.0
    300383    22500.0
    600066    38800.0
    600276    20100.0
    600745    36900.0
    600887    55300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160721 ticker: 002415 to sell begin------------
    before cash: 6530391, price: 25.14, sell_vol: 37500
    after cash:7471962
    code
    002456    29500.0
    002475    42000.0
    002739    11400.0
    300054    40500.0
    300113     9200.0
    300285    32200.0
    300383    22500.0
    600066    38800.0
    600276    20100.0
    600745    36900.0
    600887    55300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160721 ticker: 002456 to sell begin------------
    before cash: 7471962, price: 33.29, sell_vol: 29500
    after cash:8452790
    code
    002475    42000.0
    002739    11400.0
    300054    40500.0
    300113     9200.0
    300285    32200.0
    300383    22500.0
    600066    38800.0
    600276    20100.0
    600745    36900.0
    600887    55300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160721 ticker: 002475 to sell begin------------
    before cash: 8452790, price: 17.64, sell_vol: 42000
    after cash:9192743
    code
    002739    11400.0
    300054    40500.0
    300113     9200.0
    300285    32200.0
    300383    22500.0
    600066    38800.0
    600276    20100.0
    600745    36900.0
    600887    55300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160721 ticker: 002739 to sell begin------------
    before cash: 9192743, price: 75.99, sell_vol: 11400
    after cash:10057947
    code
    300054    40500.0
    300113     9200.0
    300285    32200.0
    300383    22500.0
    600066    38800.0
    600276    20100.0
    600745    36900.0
    600887    55300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160721 ticker: 300054 to sell begin------------
    before cash: 10057947, price: 24.32, sell_vol: 40500
    after cash:11041675
    code
    300113     9200.0
    300285    32200.0
    300383    22500.0
    600066    38800.0
    600276    20100.0
    600745    36900.0
    600887    55300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160721 ticker: 300113 to sell begin------------
    before cash: 11041675, price: 39.09, sell_vol: 9200
    after cash:11400854
    code
    300285    32200.0
    300383    22500.0
    600066    38800.0
    600276    20100.0
    600745    36900.0
    600887    55300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160721 ticker: 300285 to sell begin------------
    before cash: 11400854, price: 36.5, sell_vol: 32200
    after cash:12574685
    code
    300383    22500.0
    600066    38800.0
    600276    20100.0
    600745    36900.0
    600887    55300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160721 ticker: 300383 to sell begin------------
    before cash: 12574685, price: 40.18, sell_vol: 22500
    after cash:13477605
    code
    600066    38800.0
    600276    20100.0
    600745    36900.0
    600887    55300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160721 ticker: 600066 to sell begin------------
    before cash: 13477605, price: 21.99, sell_vol: 38800
    after cash:14329750
    code
    600276    20100.0
    600745    36900.0
    600887    55300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160721 ticker: 600276 to sell begin------------
    before cash: 14329750, price: 42.65, sell_vol: 20100
    after cash:15185944
    code
    600745    36900.0
    600887    55300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160721 ticker: 600745 to sell begin------------
    before cash: 15185944, price: 27.42, sell_vol: 36900
    after cash:16196477
    code
    600887    55300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20160721 ticker: 600887 to sell begin------------
    before cash: 16196477, price: 17.89, sell_vol: 55300
    after cash:17184557
    Series([], Name: amount, dtype: float64)
    at 20160721 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20160722 ticker: 002179 to buy begin--------------
    to_buy:  
    ['300267', '000651', '300065', '300285', '600885', '002635', '300073', '300017', '002450', '002530', '300458', '300145', '002179', '300284', '300324', '002415', '300310', '002343']
    before cash: 17184557, price: 41.29, to_buy: 18, buy_vol: 23100
    after cash:16230520
    code
    002179    23100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160722 ticker: 002343 to buy begin--------------
    to_buy:  
    ['300267', '000651', '300065', '300285', '600885', '002635', '300073', '300017', '002450', '002530', '300458', '300145', '300284', '300324', '002415', '300310', '002343']
    before cash: 16230520, price: 46.76, to_buy: 17, buy_vol: 20400
    after cash:15276377
    code
    002179    23100.0
    002343    20400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160722 ticker: 002415 to buy begin--------------
    to_buy:  
    ['300267', '000651', '300065', '300285', '600885', '002635', '300073', '300017', '002450', '002530', '300458', '300145', '300284', '300324', '002415', '300310']
    before cash: 15276377, price: 24.79, to_buy: 16, buy_vol: 38500
    after cash:14321724
    code
    002179    23100.0
    002343    20400.0
    002415    38500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160722 ticker: 002635 to buy begin--------------
    to_buy:  
    ['300267', '000651', '300065', '300285', '600885', '002635', '300073', '300017', '002450', '002530', '300458', '300145', '300284', '300324', '300310']
    before cash: 14321724, price: 37.5, to_buy: 15, buy_vol: 25400
    after cash:13368986
    code
    002179    23100.0
    002343    20400.0
    002415    38500.0
    002635    25400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160722 ticker: 300017 to buy begin--------------
    to_buy:  
    ['300267', '000651', '300065', '300285', '002530', '300458', '300145', '600885', '300284', '300073', '300017', '300324', '002450', '300310']
    before cash: 13368986, price: 71.65, to_buy: 14, buy_vol: 13300
    after cash:12415802
    code
    002179    23100.0
    002343    20400.0
    002415    38500.0
    002635    25400.0
    300017    13300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160722 ticker: 300065 to buy begin--------------
    to_buy:  
    ['300267', '000651', '300065', '300285', '002530', '300458', '300145', '600885', '300284', '300073', '300324', '002450', '300310']
    before cash: 12415802, price: 40.01, to_buy: 13, buy_vol: 23800
    after cash:11463326
    code
    002179    23100.0
    002343    20400.0
    002415    38500.0
    002635    25400.0
    300017    13300.0
    300065    23800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160722 ticker: 300073 to buy begin--------------
    to_buy:  
    ['300267', '000651', '300285', '002530', '300458', '300145', '600885', '300284', '300073', '300324', '002450', '300310']
    before cash: 11463326, price: 67.4, to_buy: 12, buy_vol: 14100
    after cash:10512749
    code
    002179    23100.0
    002343    20400.0
    002415    38500.0
    002635    25400.0
    300017    13300.0
    300065    23800.0
    300073    14100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160722 ticker: 300145 to buy begin--------------
    to_buy:  
    ['300267', '000651', '300285', '002530', '300458', '300145', '600885', '300284', '300324', '002450', '300310']
    before cash: 10512749, price: 23.95, to_buy: 11, buy_vol: 39900
    after cash:9556905
    code
    002179    23100.0
    002343    20400.0
    002415    38500.0
    002635    25400.0
    300017    13300.0
    300065    23800.0
    300073    14100.0
    300145    39900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160722 ticker: 300267 to buy begin--------------
    to_buy:  
    ['300267', '000651', '300285', '002530', '300458', '600885', '300284', '300324', '002450', '300310']
    before cash: 9556905, price: 14.2, to_buy: 10, buy_vol: 67300
    after cash:8601006
    code
    002179    23100.0
    002343    20400.0
    002415    38500.0
    002635    25400.0
    300017    13300.0
    300065    23800.0
    300073    14100.0
    300145    39900.0
    300267    67300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160722 ticker: 300285 to buy begin--------------
    to_buy:  
    ['000651', '300285', '002530', '300458', '600885', '300284', '300324', '002450', '300310']
    before cash: 8601006, price: 36.95, to_buy: 9, buy_vol: 25800
    after cash:7647457
    code
    002179    23100.0
    002343    20400.0
    002415    38500.0
    002635    25400.0
    300017    13300.0
    300065    23800.0
    300073    14100.0
    300145    39900.0
    300267    67300.0
    300285    25800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160722 ticker: 300458 to buy begin--------------
    to_buy:  
    ['000651', '002530', '300458', '600885', '300284', '300324', '002450', '300310']
    before cash: 7647457, price: 98.4, to_buy: 8, buy_vol: 9700
    after cash:6692739
    code
    002179    23100.0
    002343    20400.0
    002415    38500.0
    002635    25400.0
    300017    13300.0
    300065    23800.0
    300073    14100.0
    300145    39900.0
    300267    67300.0
    300285    25800.0
    300458     9700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20160722 ticker: 600885 to buy begin--------------
    to_buy:  
    ['000651', '002530', '600885', '300284', '300324', '002450', '300310']
    before cash: 6692739, price: 31.4, to_buy: 7, buy_vol: 30400
    after cash:5737940
    code
    002179    23100.0
    002343    20400.0
    002415    38500.0
    002635    25400.0
    300017    13300.0
    300065    23800.0
    300073    14100.0
    300145    39900.0
    300267    67300.0
    300285    25800.0
    300458     9700.0
    600885    30400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20161026 ticker: 002179 to sell begin------------
    before cash: 5737940, price: 39.5, sell_vol: 23100
    after cash:6649250
    code
    002343    20400.0
    002415    38500.0
    002635    25400.0
    300017    13300.0
    300065    23800.0
    300073    14100.0
    300145    39900.0
    300267    67300.0
    300285    25800.0
    300458     9700.0
    600885    30400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20161026 ticker: 002343 to sell begin------------
    before cash: 6649250, price: 42.4, sell_vol: 20400
    after cash:7513128
    code
    002415    38500.0
    002635    25400.0
    300017    13300.0
    300065    23800.0
    300073    14100.0
    300145    39900.0
    300267    67300.0
    300285    25800.0
    300458     9700.0
    600885    30400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20161026 ticker: 002415 to sell begin------------
    before cash: 7513128, price: 24.83, sell_vol: 38500
    after cash:8467889
    code
    002635    25400.0
    300017    13300.0
    300065    23800.0
    300073    14100.0
    300145    39900.0
    300267    67300.0
    300285    25800.0
    300458     9700.0
    600885    30400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20161026 ticker: 002635 to sell begin------------
    before cash: 8467889, price: 34.26, sell_vol: 25400
    after cash:9337005
    code
    300017    13300.0
    300065    23800.0
    300073    14100.0
    300145    39900.0
    300267    67300.0
    300285    25800.0
    300458     9700.0
    600885    30400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20161026 ticker: 300017 to sell begin------------
    before cash: 9337005, price: 62.7, sell_vol: 13300
    after cash:10169872
    code
    300065    23800.0
    300073    14100.0
    300145    39900.0
    300267    67300.0
    300285    25800.0
    300458     9700.0
    600885    30400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20161026 ticker: 300065 to sell begin------------
    before cash: 10169872, price: 39.55, sell_vol: 23800
    after cash:11109986
    code
    300073    14100.0
    300145    39900.0
    300267    67300.0
    300285    25800.0
    300458     9700.0
    600885    30400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20161026 ticker: 300073 to sell begin------------
    before cash: 11109986, price: 55.33, sell_vol: 14100
    after cash:11889164
    code
    300145    39900.0
    300267    67300.0
    300285    25800.0
    300458     9700.0
    600885    30400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20161026 ticker: 300145 to sell begin------------
    before cash: 11889164, price: 28.39, sell_vol: 39900
    after cash:13020509
    code
    300267    67300.0
    300285    25800.0
    300458     9700.0
    600885    30400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20161026 ticker: 300267 to sell begin------------
    before cash: 13020509, price: 14.26, sell_vol: 67300
    after cash:13979007
    code
    300285    25800.0
    300458     9700.0
    600885    30400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20161026 ticker: 300285 to sell begin------------
    before cash: 13979007, price: 37.1, sell_vol: 25800
    after cash:14934991
    code
    300458     9700.0
    600885    30400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20161026 ticker: 300458 to sell begin------------
    before cash: 14934991, price: 94.8, sell_vol: 9700
    after cash:15853401
    code
    600885    30400.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20161026 ticker: 600885 to sell begin------------
    before cash: 15853401, price: 33.35, sell_vol: 30400
    after cash:16865974
    Series([], Name: amount, dtype: float64)
    at 20161026 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20161027 ticker: 000089 to buy begin--------------
    to_buy:  
    ['600028', '000651', '000568', '300207', '600079', '300054', '600885', '002304', '300197', '600522', '300012', '002152', '002310', '000089', '600335', '000333', '000858', '600056', '002415', '600519']
    before cash: 16865974, price: 8.71, to_buy: 20, buy_vol: 96800
    after cash:16022635
    code
    000089    96800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20161027 ticker: 000333 to buy begin--------------
    to_buy:  
    ['600028', '000651', '000568', '300207', '600079', '300054', '600885', '002304', '300197', '600522', '300012', '002152', '002310', '600335', '000333', '000858', '600056', '002415', '600519']
    before cash: 16022635, price: 26.68, to_buy: 19, buy_vol: 31600
    after cash:15179336
    code
    000089    96800.0
    000333    31600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20161027 ticker: 000568 to buy begin--------------
    to_buy:  
    ['600028', '000651', '000568', '300207', '600079', '300054', '600885', '002304', '300197', '600522', '300012', '002152', '002310', '600335', '000858', '600056', '002415', '600519']
    before cash: 15179336, price: 34.86, to_buy: 18, buy_vol: 24100
    after cash:14339000
    code
    000089    96800.0
    000333    31600.0
    000568    24100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20161027 ticker: 000651 to buy begin--------------
    to_buy:  
    ['600028', '000651', '300207', '600079', '300054', '600885', '002304', '300197', '600522', '300012', '002152', '002310', '600335', '000858', '600056', '002415', '600519']
    before cash: 14339000, price: 22.42, to_buy: 17, buy_vol: 37600
    after cash:13495797
    code
    000089    96800.0
    000333    31600.0
    000568    24100.0
    000651    37600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20161027 ticker: 000858 to buy begin--------------
    to_buy:  
    ['600028', '300207', '600079', '300054', '600885', '002304', '300197', '600522', '300012', '002152', '002310', '600335', '000858', '600056', '002415', '600519']
    before cash: 13495797, price: 34.65, to_buy: 16, buy_vol: 24300
    after cash:12653592
    code
    000089    96800.0
    000333    31600.0
    000568    24100.0
    000651    37600.0
    000858    24300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20161027 ticker: 002152 to buy begin--------------
    to_buy:  
    ['002310', '600028', '600335', '300207', '600079', '300054', '600885', '002304', '300197', '600056', '600522', '002152', '002415', '600519', '300012']
    before cash: 12653592, price: 15.1, to_buy: 15, buy_vol: 55800
    after cash:11810801
    code
    000089    96800.0
    000333    31600.0
    000568    24100.0
    000651    37600.0
    000858    24300.0
    002152    55800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20161027 ticker: 002304 to buy begin--------------
    to_buy:  
    ['002310', '600028', '600335', '300207', '600079', '300054', '600885', '002304', '300197', '600056', '600522', '002415', '600519', '300012']
    before cash: 11810801, price: 69.39, to_buy: 14, buy_vol: 12100
    after cash:10970972
    code
    000089    96800.0
    000333    31600.0
    000568    24100.0
    000651    37600.0
    000858    24300.0
    002152    55800.0
    002304    12100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20161027 ticker: 002310 to buy begin--------------
    to_buy:  
    ['002310', '600028', '600335', '300207', '600079', '300054', '600885', '300197', '600056', '600522', '002415', '600519', '300012']
    before cash: 10970972, price: 15.47, to_buy: 13, buy_vol: 54500
    after cash:10127647
    code
    000089    96800.0
    000333    31600.0
    000568    24100.0
    000651    37600.0
    000858    24300.0
    002152    55800.0
    002304    12100.0
    002310    54500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20161027 ticker: 002415 to buy begin--------------
    to_buy:  
    ['600028', '600335', '300207', '600079', '300054', '600885', '300197', '600056', '600522', '002415', '600519', '300012']
    before cash: 10127647, price: 24.84, to_buy: 12, buy_vol: 33900
    after cash:9285360
    code
    000089    96800.0
    000333    31600.0
    000568    24100.0
    000651    37600.0
    000858    24300.0
    002152    55800.0
    002304    12100.0
    002310    54500.0
    002415    33900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20161027 ticker: 300012 to buy begin--------------
    to_buy:  
    ['600028', '600335', '300207', '600079', '300054', '600885', '300197', '600056', '600522', '600519', '300012']
    before cash: 9285360, price: 13.18, to_buy: 11, buy_vol: 64000
    after cash:8441629
    code
    000089    96800.0
    000333    31600.0
    000568    24100.0
    000651    37600.0
    000858    24300.0
    002152    55800.0
    002304    12100.0
    002310    54500.0
    002415    33900.0
    300012    64000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20161027 ticker: 300054 to buy begin--------------
    to_buy:  
    ['600028', '600335', '300207', '600079', '300054', '600885', '300197', '600056', '600522', '600519']
    before cash: 8441629, price: 25.34, to_buy: 10, buy_vol: 33300
    after cash:7597596
    code
    000089    96800.0
    000333    31600.0
    000568    24100.0
    000651    37600.0
    000858    24300.0
    002152    55800.0
    002304    12100.0
    002310    54500.0
    002415    33900.0
    300012    64000.0
    300054    33300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20161027 ticker: 300197 to buy begin--------------
    to_buy:  
    ['600028', '600335', '300207', '600079', '600885', '600056', '300197', '600522', '600519']
    before cash: 7597596, price: 12.07, to_buy: 9, buy_vol: 69900
    after cash:6753692
    code
    000089    96800.0
    000333    31600.0
    000568    24100.0
    000651    37600.0
    000858    24300.0
    002152    55800.0
    002304    12100.0
    002310    54500.0
    002415    33900.0
    300012    64000.0
    300054    33300.0
    300197    69900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20161027 ticker: 300207 to buy begin--------------
    to_buy:  
    ['600028', '600335', '300207', '600079', '600885', '600056', '600522', '600519']
    before cash: 6753692, price: 14.15, to_buy: 8, buy_vol: 59600
    after cash:5910141
    code
    000089    96800.0
    000333    31600.0
    000568    24100.0
    000651    37600.0
    000858    24300.0
    002152    55800.0
    002304    12100.0
    002310    54500.0
    002415    33900.0
    300012    64000.0
    300054    33300.0
    300197    69900.0
    300207    59600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20161027 ticker: 600028 to buy begin--------------
    to_buy:  
    ['600028', '600335', '600079', '600885', '600056', '600522', '600519']
    before cash: 5910141, price: 4.98, to_buy: 7, buy_vol: 169500
    after cash:5065820
    code
    000089     96800.0
    000333     31600.0
    000568     24100.0
    000651     37600.0
    000858     24300.0
    002152     55800.0
    002304     12100.0
    002310     54500.0
    002415     33900.0
    300012     64000.0
    300054     33300.0
    300197     69900.0
    300207     59600.0
    600028    169500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20161027 ticker: 600056 to buy begin--------------
    to_buy:  
    ['600335', '600079', '600885', '600056', '600522', '600519']
    before cash: 5065820, price: 20.12, to_buy: 6, buy_vol: 41900
    after cash:4222582
    code
    000089     96800.0
    000333     31600.0
    000568     24100.0
    000651     37600.0
    000858     24300.0
    002152     55800.0
    002304     12100.0
    002310     54500.0
    002415     33900.0
    300012     64000.0
    300054     33300.0
    300197     69900.0
    300207     59600.0
    600028    169500.0
    600056     41900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20161027 ticker: 600079 to buy begin--------------
    to_buy:  
    ['600335', '600079', '600885', '600522', '600519']
    before cash: 4222582, price: 20.48, to_buy: 5, buy_vol: 41200
    after cash:3378595
    code
    000089     96800.0
    000333     31600.0
    000568     24100.0
    000651     37600.0
    000858     24300.0
    002152     55800.0
    002304     12100.0
    002310     54500.0
    002415     33900.0
    300012     64000.0
    300054     33300.0
    300197     69900.0
    300207     59600.0
    600028    169500.0
    600056     41900.0
    600079     41200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20161027 ticker: 600335 to buy begin--------------
    to_buy:  
    ['600885', '600519', '600522', '600335']
    before cash: 3378595, price: 12.96, to_buy: 4, buy_vol: 65100
    after cash:2534688
    code
    000089     96800.0
    000333     31600.0
    000568     24100.0
    000651     37600.0
    000858     24300.0
    002152     55800.0
    002304     12100.0
    002310     54500.0
    002415     33900.0
    300012     64000.0
    300054     33300.0
    300197     69900.0
    300207     59600.0
    600028    169500.0
    600056     41900.0
    600079     41200.0
    600335     65100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20161027 ticker: 600519 to buy begin--------------
    to_buy:  
    ['600885', '600522', '600519']
    before cash: 2534688, price: 316.87, to_buy: 3, buy_vol: 2600
    after cash:1710620
    code
    000089     96800.0
    000333     31600.0
    000568     24100.0
    000651     37600.0
    000858     24300.0
    002152     55800.0
    002304     12100.0
    002310     54500.0
    002415     33900.0
    300012     64000.0
    300054     33300.0
    300197     69900.0
    300207     59600.0
    600028    169500.0
    600056     41900.0
    600079     41200.0
    600335     65100.0
    600519      2600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20161027 ticker: 600522 to buy begin--------------
    to_buy:  
    ['600885', '600522']
    before cash: 1710620, price: 11.11, to_buy: 2, buy_vol: 76900
    after cash:856047
    code
    000089     96800.0
    000333     31600.0
    000568     24100.0
    000651     37600.0
    000858     24300.0
    002152     55800.0
    002304     12100.0
    002310     54500.0
    002415     33900.0
    300012     64000.0
    300054     33300.0
    300197     69900.0
    300207     59600.0
    600028    169500.0
    600056     41900.0
    600079     41200.0
    600335     65100.0
    600519      2600.0
    600522     76900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20161027 ticker: 600885 to buy begin--------------
    to_buy:  
    ['600885']
    before cash: 856047, price: 33.7, to_buy: 1, buy_vol: 25400
    ALERT MONEY NOT ENOUGH!!!
    856047.2879999864
    after cash:856047
    code
    000089     96800.0
    000333     31600.0
    000568     24100.0
    000651     37600.0
    000858     24300.0
    002152     55800.0
    002304     12100.0
    002310     54500.0
    002415     33900.0
    300012     64000.0
    300054     33300.0
    300197     69900.0
    300207     59600.0
    600028    169500.0
    600056     41900.0
    600079     41200.0
    600335     65100.0
    600519      2600.0
    600522     76900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20170120 ticker: 000089 to sell begin------------
    before cash: 856047, price: 8.06, sell_vol: 96800
    after cash:1635280
    code
    000333     31600.0
    000568     24100.0
    000651     37600.0
    000858     24300.0
    002152     55800.0
    002304     12100.0
    002310     54500.0
    002415     33900.0
    300012     64000.0
    300054     33300.0
    300197     69900.0
    300207     59600.0
    600028    169500.0
    600056     41900.0
    600079     41200.0
    600335     65100.0
    600519      2600.0
    600522     76900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170120 ticker: 000333 to sell begin------------
    before cash: 1635280, price: 29.22, sell_vol: 31600
    after cash:2557478
    code
    000568     24100.0
    000651     37600.0
    000858     24300.0
    002152     55800.0
    002304     12100.0
    002310     54500.0
    002415     33900.0
    300012     64000.0
    300054     33300.0
    300197     69900.0
    300207     59600.0
    600028    169500.0
    600056     41900.0
    600079     41200.0
    600335     65100.0
    600519      2600.0
    600522     76900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170120 ticker: 000568 to sell begin------------
    before cash: 2557478, price: 34.08, sell_vol: 24100
    after cash:3377779
    code
    000651     37600.0
    000858     24300.0
    002152     55800.0
    002304     12100.0
    002310     54500.0
    002415     33900.0
    300012     64000.0
    300054     33300.0
    300197     69900.0
    300207     59600.0
    600028    169500.0
    600056     41900.0
    600079     41200.0
    600335     65100.0
    600519      2600.0
    600522     76900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170120 ticker: 000651 to sell begin------------
    before cash: 3377779, price: 25.37, sell_vol: 37600
    after cash:4330499
    code
    000858     24300.0
    002152     55800.0
    002304     12100.0
    002310     54500.0
    002415     33900.0
    300012     64000.0
    300054     33300.0
    300197     69900.0
    300207     59600.0
    600028    169500.0
    600056     41900.0
    600079     41200.0
    600335     65100.0
    600519      2600.0
    600522     76900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170120 ticker: 000858 to sell begin------------
    before cash: 4330499, price: 36.91, sell_vol: 24300
    after cash:5226291
    code
    002152     55800.0
    002304     12100.0
    002310     54500.0
    002415     33900.0
    300012     64000.0
    300054     33300.0
    300197     69900.0
    300207     59600.0
    600028    169500.0
    600056     41900.0
    600079     41200.0
    600335     65100.0
    600519      2600.0
    600522     76900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170120 ticker: 002152 to sell begin------------
    before cash: 5226291, price: 12.89, sell_vol: 55800
    after cash:5944654
    code
    002304     12100.0
    002310     54500.0
    002415     33900.0
    300012     64000.0
    300054     33300.0
    300197     69900.0
    300207     59600.0
    600028    169500.0
    600056     41900.0
    600079     41200.0
    600335     65100.0
    600519      2600.0
    600522     76900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170120 ticker: 002304 to sell begin------------
    before cash: 5944654, price: 69.82, sell_vol: 12100
    after cash:6788420
    code
    002310     54500.0
    002415     33900.0
    300012     64000.0
    300054     33300.0
    300197     69900.0
    300207     59600.0
    600028    169500.0
    600056     41900.0
    600079     41200.0
    600335     65100.0
    600519      2600.0
    600522     76900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170120 ticker: 002310 to sell begin------------
    before cash: 6788420, price: 13.45, sell_vol: 54500
    after cash:7520528
    code
    002415     33900.0
    300012     64000.0
    300054     33300.0
    300197     69900.0
    300207     59600.0
    600028    169500.0
    600056     41900.0
    600079     41200.0
    600335     65100.0
    600519      2600.0
    600522     76900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170120 ticker: 002415 to sell begin------------
    before cash: 7520528, price: 25.12, sell_vol: 33900
    after cash:8371032
    code
    300012     64000.0
    300054     33300.0
    300197     69900.0
    300207     59600.0
    600028    169500.0
    600056     41900.0
    600079     41200.0
    600335     65100.0
    600519      2600.0
    600522     76900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170120 ticker: 300012 to sell begin------------
    before cash: 8371032, price: 10.13, sell_vol: 64000
    after cash:9018541
    code
    300054     33300.0
    300197     69900.0
    300207     59600.0
    600028    169500.0
    600056     41900.0
    600079     41200.0
    600335     65100.0
    600519      2600.0
    600522     76900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170120 ticker: 300054 to sell begin------------
    before cash: 9018541, price: 20.86, sell_vol: 33300
    after cash:9712311
    code
    300197     69900.0
    300207     59600.0
    600028    169500.0
    600056     41900.0
    600079     41200.0
    600335     65100.0
    600519      2600.0
    600522     76900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170120 ticker: 300197 to sell begin------------
    before cash: 9712311, price: 11.7, sell_vol: 69900
    after cash:10529119
    code
    300207     59600.0
    600028    169500.0
    600056     41900.0
    600079     41200.0
    600335     65100.0
    600519      2600.0
    600522     76900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170120 ticker: 300207 to sell begin------------
    before cash: 10529119, price: 11.14, sell_vol: 59600
    after cash:11192233
    code
    600028    169500.0
    600056     41900.0
    600079     41200.0
    600335     65100.0
    600519      2600.0
    600522     76900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170120 ticker: 600028 to sell begin------------
    before cash: 11192233, price: 5.86, sell_vol: 169500
    after cash:12184261
    code
    600056    41900.0
    600079    41200.0
    600335    65100.0
    600519     2600.0
    600522    76900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170120 ticker: 600056 to sell begin------------
    before cash: 12184261, price: 20.42, sell_vol: 41900
    after cash:13038790
    code
    600079    41200.0
    600335    65100.0
    600519     2600.0
    600522    76900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170120 ticker: 600079 to sell begin------------
    before cash: 13038790, price: 18.97, sell_vol: 41200
    after cash:13819377
    code
    600335    65100.0
    600519     2600.0
    600522    76900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170120 ticker: 600335 to sell begin------------
    before cash: 13819377, price: 12.05, sell_vol: 65100
    after cash:14602851
    code
    600519     2600.0
    600522    76900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170120 ticker: 600519 to sell begin------------
    before cash: 14602851, price: 354.99, sell_vol: 2600
    after cash:15524672
    code
    600522    76900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170120 ticker: 600522 to sell begin------------
    before cash: 15524672, price: 11.36, sell_vol: 76900
    after cash:16397164
    Series([], Name: amount, dtype: float64)
    at 20170120 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20170123 ticker: 000333 to buy begin--------------
    to_buy:  
    ['600531', '600887', '000568', '002304', '600123', '600489', '600547', '600988', '002155', '600997', '000786', '300115', '000333', '600500', '000975', '000858', '601069', '002415', '002716', '600519']
    before cash: 16397164, price: 28.96, to_buy: 20, buy_vol: 28300
    after cash:15577391
    code
    000333    28300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170123 ticker: 000568 to buy begin--------------
    to_buy:  
    ['600531', '600887', '000568', '002304', '600123', '600489', '600547', '600988', '002155', '600997', '000786', '300115', '600500', '000975', '000858', '601069', '002415', '002716', '600519']
    before cash: 15577391, price: 34.29, to_buy: 19, buy_vol: 23900
    after cash:14757655
    code
    000333    28300.0
    000568    23900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170123 ticker: 000786 to buy begin--------------
    to_buy:  
    ['600531', '600887', '002304', '600123', '600489', '600547', '600988', '002155', '600997', '000786', '300115', '600500', '000975', '000858', '601069', '002415', '002716', '600519']
    before cash: 14757655, price: 10.64, to_buy: 18, buy_vol: 77000
    after cash:13938170
    code
    000333    28300.0
    000568    23900.0
    000786    77000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170123 ticker: 000858 to buy begin--------------
    to_buy:  
    ['600531', '600887', '002304', '600123', '600489', '600547', '600988', '002155', '600997', '300115', '600500', '000975', '000858', '601069', '002415', '002716', '600519']
    before cash: 13938170, price: 37.38, to_buy: 17, buy_vol: 21900
    after cash:13119343
    code
    000333    28300.0
    000568    23900.0
    000786    77000.0
    000858    21900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170123 ticker: 000975 to buy begin--------------
    to_buy:  
    ['600531', '600887', '002304', '600123', '600489', '600547', '600988', '002155', '600997', '300115', '600500', '000975', '601069', '002415', '002716', '600519']
    before cash: 13119343, price: 16.35, to_buy: 16, buy_vol: 50100
    after cash:12300004
    code
    000333    28300.0
    000568    23900.0
    000786    77000.0
    000858    21900.0
    000975    50100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170123 ticker: 002155 to buy begin--------------
    to_buy:  
    ['600997', '600531', '600988', '300115', '600887', '002304', '600500', '002415', '601069', '600123', '600489', '600547', '002716', '002155', '600519']
    before cash: 12300004, price: 11.25, to_buy: 15, buy_vol: 72800
    after cash:11480799
    code
    000333    28300.0
    000568    23900.0
    000786    77000.0
    000858    21900.0
    000975    50100.0
    002155    72800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170123 ticker: 002304 to buy begin--------------
    to_buy:  
    ['600997', '600531', '600988', '300115', '600887', '002304', '600500', '002415', '601069', '600123', '600489', '600547', '002716', '600519']
    before cash: 11480799, price: 70.49, to_buy: 14, buy_vol: 11600
    after cash:10662910
    code
    000333    28300.0
    000568    23900.0
    000786    77000.0
    000858    21900.0
    000975    50100.0
    002155    72800.0
    002304    11600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170123 ticker: 002415 to buy begin--------------
    to_buy:  
    ['600997', '600531', '600988', '300115', '600887', '600500', '002415', '601069', '600123', '600489', '600547', '002716', '600519']
    before cash: 10662910, price: 25.23, to_buy: 13, buy_vol: 32500
    after cash:9842730
    code
    000333    28300.0
    000568    23900.0
    000786    77000.0
    000858    21900.0
    000975    50100.0
    002155    72800.0
    002304    11600.0
    002415    32500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170123 ticker: 002716 to buy begin--------------
    to_buy:  
    ['600997', '600531', '600988', '300115', '600887', '600500', '601069', '600123', '600489', '600547', '002716', '600519']
    before cash: 9842730, price: 20.93, to_buy: 12, buy_vol: 39100
    after cash:9024163
    code
    000333    28300.0
    000568    23900.0
    000786    77000.0
    000858    21900.0
    000975    50100.0
    002155    72800.0
    002304    11600.0
    002415    32500.0
    002716    39100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170123 ticker: 300115 to buy begin--------------
    to_buy:  
    ['600997', '600531', '600988', '300115', '600887', '600500', '601069', '600123', '600489', '600547', '600519']
    before cash: 9024163, price: 25.11, to_buy: 11, buy_vol: 32600
    after cash:8205372
    code
    000333    28300.0
    000568    23900.0
    000786    77000.0
    000858    21900.0
    000975    50100.0
    002155    72800.0
    002304    11600.0
    002415    32500.0
    002716    39100.0
    300115    32600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170123 ticker: 600123 to buy begin--------------
    to_buy:  
    ['600997', '600531', '600988', '600887', '600500', '601069', '600123', '600489', '600547', '600519']
    before cash: 8205372, price: 7.74, to_buy: 10, buy_vol: 106000
    after cash:7384727
    code
    000333     28300.0
    000568     23900.0
    000786     77000.0
    000858     21900.0
    000975     50100.0
    002155     72800.0
    002304     11600.0
    002415     32500.0
    002716     39100.0
    300115     32600.0
    600123    106000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170123 ticker: 600489 to buy begin--------------
    to_buy:  
    ['600997', '600531', '600988', '600887', '600500', '601069', '600489', '600547', '600519']
    before cash: 7384727, price: 12.4, to_buy: 9, buy_vol: 66100
    after cash:6564882
    code
    000333     28300.0
    000568     23900.0
    000786     77000.0
    000858     21900.0
    000975     50100.0
    002155     72800.0
    002304     11600.0
    002415     32500.0
    002716     39100.0
    300115     32600.0
    600123    106000.0
    600489     66100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170123 ticker: 600500 to buy begin--------------
    to_buy:  
    ['600997', '600531', '600988', '600887', '600500', '601069', '600547', '600519']
    before cash: 6564882, price: 11.85, to_buy: 8, buy_vol: 69200
    after cash:5744657
    code
    000333     28300.0
    000568     23900.0
    000786     77000.0
    000858     21900.0
    000975     50100.0
    002155     72800.0
    002304     11600.0
    002415     32500.0
    002716     39100.0
    300115     32600.0
    600123    106000.0
    600489     66100.0
    600500     69200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170123 ticker: 600519 to buy begin--------------
    to_buy:  
    ['600997', '600531', '600988', '600887', '601069', '600547', '600519']
    before cash: 5744657, price: 351.22, to_buy: 7, buy_vol: 2300
    after cash:4936649
    code
    000333     28300.0
    000568     23900.0
    000786     77000.0
    000858     21900.0
    000975     50100.0
    002155     72800.0
    002304     11600.0
    002415     32500.0
    002716     39100.0
    300115     32600.0
    600123    106000.0
    600489     66100.0
    600500     69200.0
    600519      2300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170123 ticker: 600531 to buy begin--------------
    to_buy:  
    ['600997', '600531', '600887', '601069', '600547', '600988']
    before cash: 4936649, price: 8.23, to_buy: 6, buy_vol: 99900
    after cash:4114267
    code
    000333     28300.0
    000568     23900.0
    000786     77000.0
    000858     21900.0
    000975     50100.0
    002155     72800.0
    002304     11600.0
    002415     32500.0
    002716     39100.0
    300115     32600.0
    600123    106000.0
    600489     66100.0
    600500     69200.0
    600519      2300.0
    600531     99900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170123 ticker: 600547 to buy begin--------------
    to_buy:  
    ['600997', '600887', '601069', '600547', '600988']
    before cash: 4114267, price: 37.85, to_buy: 5, buy_vol: 21700
    after cash:3292716
    code
    000333     28300.0
    000568     23900.0
    000786     77000.0
    000858     21900.0
    000975     50100.0
    002155     72800.0
    002304     11600.0
    002415     32500.0
    002716     39100.0
    300115     32600.0
    600123    106000.0
    600489     66100.0
    600500     69200.0
    600519      2300.0
    600531     99900.0
    600547     21700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170123 ticker: 600887 to buy begin--------------
    to_buy:  
    ['600887', '600988', '601069', '600997']
    before cash: 3292716, price: 18.26, to_buy: 4, buy_vol: 45000
    after cash:2470811
    code
    000333     28300.0
    000568     23900.0
    000786     77000.0
    000858     21900.0
    000975     50100.0
    002155     72800.0
    002304     11600.0
    002415     32500.0
    002716     39100.0
    300115     32600.0
    600123    106000.0
    600489     66100.0
    600500     69200.0
    600519      2300.0
    600531     99900.0
    600547     21700.0
    600887     45000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170123 ticker: 600988 to buy begin--------------
    to_buy:  
    ['600988', '601069', '600997']
    before cash: 2470811, price: 15.23, to_buy: 3, buy_vol: 54000
    after cash:1648185
    code
    000333     28300.0
    000568     23900.0
    000786     77000.0
    000858     21900.0
    000975     50100.0
    002155     72800.0
    002304     11600.0
    002415     32500.0
    002716     39100.0
    300115     32600.0
    600123    106000.0
    600489     66100.0
    600500     69200.0
    600519      2300.0
    600531     99900.0
    600547     21700.0
    600887     45000.0
    600988     54000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170123 ticker: 600997 to buy begin--------------
    to_buy:  
    ['600997', '601069']
    before cash: 1648185, price: 7.21, to_buy: 2, buy_vol: 114200
    after cash:824597
    code
    000333     28300.0
    000568     23900.0
    000786     77000.0
    000858     21900.0
    000975     50100.0
    002155     72800.0
    002304     11600.0
    002415     32500.0
    002716     39100.0
    300115     32600.0
    600123    106000.0
    600489     66100.0
    600500     69200.0
    600519      2300.0
    600531     99900.0
    600547     21700.0
    600887     45000.0
    600988     54000.0
    600997    114200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170123 ticker: 601069 to buy begin--------------
    to_buy:  
    ['601069']
    before cash: 824597, price: 21.17, to_buy: 1, buy_vol: 38900
    after cash:879
    code
    000333     28300.0
    000568     23900.0
    000786     77000.0
    000858     21900.0
    000975     50100.0
    002155     72800.0
    002304     11600.0
    002415     32500.0
    002716     39100.0
    300115     32600.0
    600123    106000.0
    600489     66100.0
    600500     69200.0
    600519      2300.0
    600531     99900.0
    600547     21700.0
    600887     45000.0
    600988     54000.0
    600997    114200.0
    601069     38900.0
    Name: amount, dtype: float64
    at 20170123 clear the to_buy list successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20170424 ticker: 000333 to sell begin------------
    before cash: 879, price: 33.12, sell_vol: 28300
    after cash:937003
    code
    000568     23900.0
    000786     77000.0
    000858     21900.0
    000975     50100.0
    002155     72800.0
    002304     11600.0
    002415     32500.0
    002716     39100.0
    300115     32600.0
    600123    106000.0
    600489     66100.0
    600500     69200.0
    600519      2300.0
    600531     99900.0
    600547     21700.0
    600887     45000.0
    600988     54000.0
    600997    114200.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170424 ticker: 000568 to sell begin------------
    before cash: 937003, price: 44.8, sell_vol: 23900
    after cash:2006385
    code
    000786     77000.0
    000858     21900.0
    000975     50100.0
    002155     72800.0
    002304     11600.0
    002415     32500.0
    002716     39100.0
    300115     32600.0
    600123    106000.0
    600489     66100.0
    600500     69200.0
    600519      2300.0
    600531     99900.0
    600547     21700.0
    600887     45000.0
    600988     54000.0
    600997    114200.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170424 ticker: 000786 to sell begin------------
    before cash: 2006385, price: 14.3, sell_vol: 77000
    after cash:3106108
    code
    000858     21900.0
    000975     50100.0
    002155     72800.0
    002304     11600.0
    002415     32500.0
    002716     39100.0
    300115     32600.0
    600123    106000.0
    600489     66100.0
    600500     69200.0
    600519      2300.0
    600531     99900.0
    600547     21700.0
    600887     45000.0
    600988     54000.0
    600997    114200.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170424 ticker: 000858 to sell begin------------
    before cash: 3106108, price: 44.31, sell_vol: 21900
    after cash:4075284
    code
    000975     50100.0
    002155     72800.0
    002304     11600.0
    002415     32500.0
    002716     39100.0
    300115     32600.0
    600123    106000.0
    600489     66100.0
    600500     69200.0
    600519      2300.0
    600531     99900.0
    600547     21700.0
    600887     45000.0
    600988     54000.0
    600997    114200.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170424 ticker: 000975 to sell begin------------
    before cash: 4075284, price: 13.42, sell_vol: 50100
    after cash:4746786
    code
    002155     72800.0
    002304     11600.0
    002415     32500.0
    002716     39100.0
    300115     32600.0
    600123    106000.0
    600489     66100.0
    600500     69200.0
    600519      2300.0
    600531     99900.0
    600547     21700.0
    600887     45000.0
    600988     54000.0
    600997    114200.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170424 ticker: 002155 to sell begin------------
    before cash: 4746786, price: 10.64, sell_vol: 72800
    after cash:5520409
    code
    002304     11600.0
    002415     32500.0
    002716     39100.0
    300115     32600.0
    600123    106000.0
    600489     66100.0
    600500     69200.0
    600519      2300.0
    600531     99900.0
    600547     21700.0
    600887     45000.0
    600988     54000.0
    600997    114200.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170424 ticker: 002304 to sell begin------------
    before cash: 5520409, price: 84.02, sell_vol: 11600
    after cash:6493823
    code
    002415     32500.0
    002716     39100.0
    300115     32600.0
    600123    106000.0
    600489     66100.0
    600500     69200.0
    600519      2300.0
    600531     99900.0
    600547     21700.0
    600887     45000.0
    600988     54000.0
    600997    114200.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170424 ticker: 002415 to sell begin------------
    before cash: 6493823, price: 36.03, sell_vol: 32500
    after cash:7663334
    code
    002716     39100.0
    300115     32600.0
    600123    106000.0
    600489     66100.0
    600500     69200.0
    600519      2300.0
    600531     99900.0
    600547     21700.0
    600887     45000.0
    600988     54000.0
    600997    114200.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170424 ticker: 002716 to sell begin------------
    before cash: 7663334, price: 18.51, sell_vol: 39100
    after cash:8386171
    code
    300115     32600.0
    600123    106000.0
    600489     66100.0
    600500     69200.0
    600519      2300.0
    600531     99900.0
    600547     21700.0
    600887     45000.0
    600988     54000.0
    600997    114200.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170424 ticker: 300115 to sell begin------------
    before cash: 8386171, price: 29.08, sell_vol: 32600
    after cash:9332994
    code
    600123    106000.0
    600489     66100.0
    600500     69200.0
    600519      2300.0
    600531     99900.0
    600547     21700.0
    600887     45000.0
    600988     54000.0
    600997    114200.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170424 ticker: 600123 to sell begin------------
    before cash: 9332994, price: 7.69, sell_vol: 106000
    after cash:10147115
    code
    600489     66100.0
    600500     69200.0
    600519      2300.0
    600531     99900.0
    600547     21700.0
    600887     45000.0
    600988     54000.0
    600997    114200.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170424 ticker: 600489 to sell begin------------
    before cash: 10147115, price: 11.28, sell_vol: 66100
    after cash:10891791
    code
    600500     69200.0
    600519      2300.0
    600531     99900.0
    600547     21700.0
    600887     45000.0
    600988     54000.0
    600997    114200.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170424 ticker: 600500 to sell begin------------
    before cash: 10891791, price: 10.97, sell_vol: 69200
    after cash:11649966
    code
    600519      2300.0
    600531     99900.0
    600547     21700.0
    600887     45000.0
    600988     54000.0
    600997    114200.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170424 ticker: 600519 to sell begin------------
    before cash: 11649966, price: 398.55, sell_vol: 2300
    after cash:12565485
    code
    600531     99900.0
    600547     21700.0
    600887     45000.0
    600988     54000.0
    600997    114200.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170424 ticker: 600531 to sell begin------------
    before cash: 12565485, price: 7.51, sell_vol: 99900
    after cash:13314796
    code
    600547     21700.0
    600887     45000.0
    600988     54000.0
    600997    114200.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170424 ticker: 600988 to sell begin------------
    before cash: 13314796, price: 13.77, sell_vol: 54000
    after cash:14057447
    code
    600547     21700.0
    600887     45000.0
    600997    114200.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170424 ticker: 600997 to sell begin------------
    before cash: 14057447, price: 6.17, sell_vol: 114200
    after cash:14761180
    code
    600547    21700.0
    600887    45000.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20170425 ticker: 000333 to buy begin--------------
    to_buy:  
    ['600035', '000651', '000568', '002304', '002583', '000786', '300115', '600856', '000333', '600110', '002640', '600382', '000858', '600056', '002475', '002415', '002456', '600519']
    before cash: 14761180, price: 34.24, to_buy: 18, buy_vol: 23900
    after cash:13942639
    code
    000333    23900.0
    600547    21700.0
    600887    45000.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170425 ticker: 000568 to buy begin--------------
    to_buy:  
    ['600035', '000786', '300115', '600856', '000651', '000568', '600110', '002640', '600382', '002304', '002583', '000858', '600056', '002475', '002415', '002456', '600519']
    before cash: 13942639, price: 47.51, to_buy: 17, buy_vol: 17200
    after cash:13125263
    code
    000333    23900.0
    000568    17200.0
    600547    21700.0
    600887    45000.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170425 ticker: 000651 to buy begin--------------
    to_buy:  
    ['600035', '000786', '300115', '600856', '000651', '600110', '002640', '600382', '002304', '002583', '000858', '600056', '002475', '002415', '002456', '600519']
    before cash: 13125263, price: 33.84, to_buy: 16, buy_vol: 24200
    after cash:12306130
    code
    000333    23900.0
    000568    17200.0
    000651    24200.0
    600547    21700.0
    600887    45000.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170425 ticker: 000786 to buy begin--------------
    to_buy:  
    ['600035', '000786', '300115', '600856', '600110', '002640', '600382', '002304', '002583', '000858', '600056', '002475', '002415', '002456', '600519']
    before cash: 12306130, price: 14.47, to_buy: 15, buy_vol: 56600
    after cash:11486924
    code
    000333    23900.0
    000568    17200.0
    000651    24200.0
    000786    56600.0
    600547    21700.0
    600887    45000.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170425 ticker: 000858 to buy begin--------------
    to_buy:  
    ['600035', '300115', '600856', '600110', '002640', '600382', '002304', '002583', '000858', '600056', '002475', '002415', '002456', '600519']
    before cash: 11486924, price: 46.6, to_buy: 14, buy_vol: 17600
    after cash:10666559
    code
    000333    23900.0
    000568    17200.0
    000651    24200.0
    000786    56600.0
    000858    17600.0
    600547    21700.0
    600887    45000.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170425 ticker: 002304 to buy begin--------------
    to_buy:  
    ['600035', '300115', '600856', '600110', '002640', '600382', '002304', '002583', '600056', '002475', '002415', '002456', '600519']
    before cash: 10666559, price: 85.89, to_buy: 13, buy_vol: 9500
    after cash:9850400
    code
    000333    23900.0
    000568    17200.0
    000651    24200.0
    000786    56600.0
    000858    17600.0
    002304     9500.0
    600547    21700.0
    600887    45000.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170425 ticker: 002415 to buy begin--------------
    to_buy:  
    ['600035', '300115', '600856', '600110', '002640', '600382', '002583', '600056', '002475', '002415', '002456', '600519']
    before cash: 9850400, price: 37.55, to_buy: 12, buy_vol: 21800
    after cash:9031605
    code
    000333    23900.0
    000568    17200.0
    000651    24200.0
    000786    56600.0
    000858    17600.0
    002304     9500.0
    002415    21800.0
    600547    21700.0
    600887    45000.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170425 ticker: 002456 to buy begin--------------
    to_buy:  
    ['600035', '300115', '600856', '600110', '002640', '600382', '002583', '600056', '002475', '002456', '600519']
    before cash: 9031605, price: 37.95, to_buy: 11, buy_vol: 21600
    after cash:8211680
    code
    000333    23900.0
    000568    17200.0
    000651    24200.0
    000786    56600.0
    000858    17600.0
    002304     9500.0
    002415    21800.0
    002456    21600.0
    600547    21700.0
    600887    45000.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170425 ticker: 002475 to buy begin--------------
    to_buy:  
    ['600035', '300115', '600856', '600110', '002640', '600382', '002583', '600056', '002475', '600519']
    before cash: 8211680, price: 26.58, to_buy: 10, buy_vol: 30800
    after cash:7392811
    code
    000333    23900.0
    000568    17200.0
    000651    24200.0
    000786    56600.0
    000858    17600.0
    002304     9500.0
    002415    21800.0
    002456    21600.0
    002475    30800.0
    600547    21700.0
    600887    45000.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170425 ticker: 002583 to buy begin--------------
    to_buy:  
    ['600035', '300115', '600856', '600110', '002640', '600382', '002583', '600056', '600519']
    before cash: 7392811, price: 14.68, to_buy: 9, buy_vol: 55900
    after cash:6571994
    code
    000333    23900.0
    000568    17200.0
    000651    24200.0
    000786    56600.0
    000858    17600.0
    002304     9500.0
    002415    21800.0
    002456    21600.0
    002475    30800.0
    002583    55900.0
    600547    21700.0
    600887    45000.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170425 ticker: 002640 to buy begin--------------
    to_buy:  
    ['600035', '300115', '600856', '600110', '002640', '600382', '600056', '600519']
    before cash: 6571994, price: 15.48, to_buy: 8, buy_vol: 53000
    after cash:5751349
    code
    000333    23900.0
    000568    17200.0
    000651    24200.0
    000786    56600.0
    000858    17600.0
    002304     9500.0
    002415    21800.0
    002456    21600.0
    002475    30800.0
    002583    55900.0
    002640    53000.0
    600547    21700.0
    600887    45000.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170425 ticker: 300115 to buy begin--------------
    to_buy:  
    ['600035', '300115', '600856', '600110', '600382', '600056', '600519']
    before cash: 5751349, price: 29.36, to_buy: 7, buy_vol: 27900
    after cash:4932000
    code
    000333    23900.0
    000568    17200.0
    000651    24200.0
    000786    56600.0
    000858    17600.0
    002304     9500.0
    002415    21800.0
    002456    21600.0
    002475    30800.0
    002583    55900.0
    002640    53000.0
    300115    27900.0
    600547    21700.0
    600887    45000.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170425 ticker: 600035 to buy begin--------------
    to_buy:  
    ['600035', '600856', '600110', '600382', '600056', '600519']
    before cash: 4932000, price: 5.56, to_buy: 6, buy_vol: 147800
    after cash:4110027
    code
    000333     23900.0
    000568     17200.0
    000651     24200.0
    000786     56600.0
    000858     17600.0
    002304      9500.0
    002415     21800.0
    002456     21600.0
    002475     30800.0
    002583     55900.0
    002640     53000.0
    300115     27900.0
    600035    147800.0
    600547     21700.0
    600887     45000.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170425 ticker: 600056 to buy begin--------------
    to_buy:  
    ['600856', '600110', '600382', '600056', '600519']
    before cash: 4110027, price: 24.07, to_buy: 5, buy_vol: 34100
    after cash:3289035
    code
    000333     23900.0
    000568     17200.0
    000651     24200.0
    000786     56600.0
    000858     17600.0
    002304      9500.0
    002415     21800.0
    002456     21600.0
    002475     30800.0
    002583     55900.0
    002640     53000.0
    300115     27900.0
    600035    147800.0
    600056     34100.0
    600547     21700.0
    600887     45000.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170425 ticker: 600110 to buy begin--------------
    to_buy:  
    ['600856', '600382', '600110', '600519']
    before cash: 3289035, price: 12.63, to_buy: 4, buy_vol: 65100
    after cash:2466616
    code
    000333     23900.0
    000568     17200.0
    000651     24200.0
    000786     56600.0
    000858     17600.0
    002304      9500.0
    002415     21800.0
    002456     21600.0
    002475     30800.0
    002583     55900.0
    002640     53000.0
    300115     27900.0
    600035    147800.0
    600056     34100.0
    600110     65100.0
    600547     21700.0
    600887     45000.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170425 ticker: 600382 to buy begin--------------
    to_buy:  
    ['600856', '600382', '600519']
    before cash: 2466616, price: 15.24, to_buy: 3, buy_vol: 53900
    after cash:1644975
    code
    000333     23900.0
    000568     17200.0
    000651     24200.0
    000786     56600.0
    000858     17600.0
    002304      9500.0
    002415     21800.0
    002456     21600.0
    002475     30800.0
    002583     55900.0
    002640     53000.0
    300115     27900.0
    600035    147800.0
    600056     34100.0
    600110     65100.0
    600382     53900.0
    600547     21700.0
    600887     45000.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170425 ticker: 600519 to buy begin--------------
    to_buy:  
    ['600856', '600519']
    before cash: 1644975, price: 418.89, to_buy: 2, buy_vol: 1900
    after cash:848885
    code
    000333     23900.0
    000568     17200.0
    000651     24200.0
    000786     56600.0
    000858     17600.0
    002304      9500.0
    002415     21800.0
    002456     21600.0
    002475     30800.0
    002583     55900.0
    002640     53000.0
    300115     27900.0
    600035    147800.0
    600056     34100.0
    600110     65100.0
    600382     53900.0
    600519      1900.0
    600547     21700.0
    600887     45000.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170425 ticker: 600856 to buy begin--------------
    to_buy:  
    ['600856']
    before cash: 848885, price: 10.74, to_buy: 1, buy_vol: 79000
    after cash:213
    code
    000333     23900.0
    000568     17200.0
    000651     24200.0
    000786     56600.0
    000858     17600.0
    002304      9500.0
    002415     21800.0
    002456     21600.0
    002475     30800.0
    002583     55900.0
    002640     53000.0
    300115     27900.0
    600035    147800.0
    600056     34100.0
    600110     65100.0
    600382     53900.0
    600519      1900.0
    600547     21700.0
    600856     79000.0
    600887     45000.0
    601069     38900.0
    Name: amount, dtype: float64
    at 20170425 clear the to_buy list successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2017-05-09  600887      6.0          0.0    0.0       0.0
    分红，增加现金27000.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2017-05-10  000333     10.0          0.0    0.0       0.0
    分红，增加现金23900.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2017-05-12  000858      9.0          0.0    0.0       0.0
    分红，增加现金15840.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2017-05-16  000786      1.8          0.0    0.0       0.0
    分红，增加现金10188.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2017-05-16  002415      6.0          5.0    0.0       0.0
    分红，增加现金13080.0
    转增股，增加股票10900.0股002415
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2017-05-19  600382     0.35          0.0    0.0       0.0
    分红，增加现金1886.5
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2017-05-24  600035      1.0          0.0    0.0       0.0
    分红，增加现金14780.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2017-05-25  002583     0.35          0.0    0.0       0.0
    分红，增加现金1956.5
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2017-05-31  300115      1.5          0.0    0.0       0.0
    分红，增加现金4185.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2017-06-05  002640     0.56          0.0    0.0       0.0
    分红，增加现金2968.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2017-06-06  600547      1.0          0.0    0.0       0.0
    分红，增加现金2170.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2017-06-12  002456      1.1         15.0    0.0       0.0
    分红，增加现金2376.0
    转增股，增加股票32400.0股002456
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2017-06-14  600056   2.6621          0.0    0.0       0.0
    分红，增加现金9077.76
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2017-06-16  002304     21.0          0.0    0.0       0.0
    分红，增加现金19950.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2017-06-19  000568      9.6          0.0    0.0       0.0
    分红，增加现金16512.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2017-07-05  000651     18.0          0.0    0.0       0.0
    分红，增加现金43560.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2017-07-06  002475      0.8          5.0    0.0       0.0
    分红，增加现金2464.0
    转增股，增加股票15400.0股002475
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code    fenhong  songzhuangu  peigu  peigujia
    date                                                       
    2017-07-07  600519  67.870003          0.0    0.0       0.0
    分红，增加现金12895.3
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20170721 ticker: 000333 to sell begin------------
    before cash: 224987, price: 41.9, sell_vol: 23900
    after cash:1225145
    code
    000568     17200.0
    000651     24200.0
    000786     56600.0
    000858     17600.0
    002304      9500.0
    002415     32700.0
    002456     54000.0
    002475     46200.0
    002583     55900.0
    002640     53000.0
    300115     27900.0
    600035    147800.0
    600056     34100.0
    600110     65100.0
    600382     53900.0
    600519      1900.0
    600547     21700.0
    600856     79000.0
    600887     45000.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170721 ticker: 000568 to sell begin------------
    before cash: 1225145, price: 51.38, sell_vol: 17200
    after cash:2107776
    code
    000651     24200.0
    000786     56600.0
    000858     17600.0
    002304      9500.0
    002415     32700.0
    002456     54000.0
    002475     46200.0
    002583     55900.0
    002640     53000.0
    300115     27900.0
    600035    147800.0
    600056     34100.0
    600110     65100.0
    600382     53900.0
    600519      1900.0
    600547     21700.0
    600856     79000.0
    600887     45000.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170721 ticker: 000651 to sell begin------------
    before cash: 2107776, price: 40.71, sell_vol: 24200
    after cash:3091727
    code
    000786     56600.0
    000858     17600.0
    002304      9500.0
    002415     32700.0
    002456     54000.0
    002475     46200.0
    002583     55900.0
    002640     53000.0
    300115     27900.0
    600035    147800.0
    600056     34100.0
    600110     65100.0
    600382     53900.0
    600519      1900.0
    600547     21700.0
    600856     79000.0
    600887     45000.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170721 ticker: 000786 to sell begin------------
    before cash: 3091727, price: 15.04, sell_vol: 56600
    after cash:3941927
    code
    000858     17600.0
    002304      9500.0
    002415     32700.0
    002456     54000.0
    002475     46200.0
    002583     55900.0
    002640     53000.0
    300115     27900.0
    600035    147800.0
    600056     34100.0
    600110     65100.0
    600382     53900.0
    600519      1900.0
    600547     21700.0
    600856     79000.0
    600887     45000.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170721 ticker: 000858 to sell begin------------
    before cash: 3941927, price: 54.71, sell_vol: 17600
    after cash:4903619
    code
    002304      9500.0
    002415     32700.0
    002456     54000.0
    002475     46200.0
    002583     55900.0
    002640     53000.0
    300115     27900.0
    600035    147800.0
    600056     34100.0
    600110     65100.0
    600382     53900.0
    600519      1900.0
    600547     21700.0
    600856     79000.0
    600887     45000.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170721 ticker: 002304 to sell begin------------
    before cash: 4903619, price: 86.32, sell_vol: 9500
    after cash:5722634
    code
    002415     32700.0
    002456     54000.0
    002475     46200.0
    002583     55900.0
    002640     53000.0
    300115     27900.0
    600035    147800.0
    600056     34100.0
    600110     65100.0
    600382     53900.0
    600519      1900.0
    600547     21700.0
    600856     79000.0
    600887     45000.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170721 ticker: 002415 to sell begin------------
    before cash: 5722634, price: 30.59, sell_vol: 32700
    after cash:6721677
    code
    002456     54000.0
    002475     46200.0
    002583     55900.0
    002640     53000.0
    300115     27900.0
    600035    147800.0
    600056     34100.0
    600110     65100.0
    600382     53900.0
    600519      1900.0
    600547     21700.0
    600856     79000.0
    600887     45000.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170721 ticker: 002456 to sell begin------------
    before cash: 6721677, price: 18.95, sell_vol: 54000
    after cash:7743698
    code
    002475     46200.0
    002583     55900.0
    002640     53000.0
    300115     27900.0
    600035    147800.0
    600056     34100.0
    600110     65100.0
    600382     53900.0
    600519      1900.0
    600547     21700.0
    600856     79000.0
    600887     45000.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170721 ticker: 002475 to sell begin------------
    before cash: 7743698, price: 21.01, sell_vol: 46200
    after cash:8713146
    code
    002583     55900.0
    002640     53000.0
    300115     27900.0
    600035    147800.0
    600056     34100.0
    600110     65100.0
    600382     53900.0
    600519      1900.0
    600547     21700.0
    600856     79000.0
    600887     45000.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170721 ticker: 002583 to sell begin------------
    before cash: 8713146, price: 16.49, sell_vol: 55900
    after cash:9633785
    code
    002640     53000.0
    300115     27900.0
    600035    147800.0
    600056     34100.0
    600110     65100.0
    600382     53900.0
    600519      1900.0
    600547     21700.0
    600856     79000.0
    600887     45000.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170721 ticker: 002640 to sell begin------------
    before cash: 9633785, price: 19.48, sell_vol: 53000
    after cash:10664935
    code
    300115     27900.0
    600035    147800.0
    600056     34100.0
    600110     65100.0
    600382     53900.0
    600519      1900.0
    600547     21700.0
    600856     79000.0
    600887     45000.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170721 ticker: 300115 to sell begin------------
    before cash: 10664935, price: 33.5, sell_vol: 27900
    after cash:11598416
    code
    600035    147800.0
    600056     34100.0
    600110     65100.0
    600382     53900.0
    600519      1900.0
    600547     21700.0
    600856     79000.0
    600887     45000.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170721 ticker: 600035 to sell begin------------
    before cash: 11598416, price: 5.51, sell_vol: 147800
    after cash:12411776
    code
    600056    34100.0
    600110    65100.0
    600382    53900.0
    600519     1900.0
    600547    21700.0
    600856    79000.0
    600887    45000.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170721 ticker: 600056 to sell begin------------
    before cash: 12411776, price: 24.53, sell_vol: 34100
    after cash:13247204
    code
    600110    65100.0
    600382    53900.0
    600519     1900.0
    600547    21700.0
    600856    79000.0
    600887    45000.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170721 ticker: 600110 to sell begin------------
    before cash: 13247204, price: 16.16, sell_vol: 65100
    after cash:14297905
    code
    600382    53900.0
    600519     1900.0
    600547    21700.0
    600856    79000.0
    600887    45000.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170721 ticker: 600382 to sell begin------------
    before cash: 14297905, price: 14.59, sell_vol: 53900
    after cash:15083323
    code
    600519     1900.0
    600547    21700.0
    600856    79000.0
    600887    45000.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170721 ticker: 600519 to sell begin------------
    before cash: 15083323, price: 473.2, sell_vol: 1900
    after cash:15981279
    code
    600547    21700.0
    600856    79000.0
    600887    45000.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170721 ticker: 600547 to sell begin------------
    before cash: 15981279, price: 31.82, sell_vol: 21700
    after cash:16670910
    code
    600856    79000.0
    600887    45000.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170721 ticker: 600856 to sell begin------------
    before cash: 16670910, price: 10.91, sell_vol: 79000
    after cash:17531722
    code
    600887    45000.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20170721 ticker: 600887 to sell begin------------
    before cash: 17531722, price: 20.74, sell_vol: 45000
    after cash:18463856
    code
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20170724 ticker: 000333 to buy begin--------------
    to_buy:  
    ['600887', '000333', '000568', '000651', '600110', '002450', '000858', '002475', '600196', '002415']
    before cash: 18463856, price: 43.42, to_buy: 10, buy_vol: 42500
    after cash:16618044
    code
    000333    42500.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170724 ticker: 000568 to buy begin--------------
    to_buy:  
    ['600887', '000651', '000568', '600110', '002415', '000858', '002475', '600196', '002450']
    before cash: 16618044, price: 52.59, to_buy: 9, buy_vol: 35100
    after cash:14771674
    code
    000333    42500.0
    000568    35100.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170724 ticker: 000651 to buy begin--------------
    to_buy:  
    ['600887', '000651', '600110', '002415', '000858', '002475', '600196', '002450']
    before cash: 14771674, price: 41.3, to_buy: 8, buy_vol: 44700
    after cash:12925102
    code
    000333    42500.0
    000568    35100.0
    000651    44700.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170724 ticker: 000858 to buy begin--------------
    to_buy:  
    ['600887', '600110', '002415', '000858', '002475', '600196', '002450']
    before cash: 12925102, price: 55.91, to_buy: 7, buy_vol: 33000
    after cash:11079611
    code
    000333    42500.0
    000568    35100.0
    000651    44700.0
    000858    33000.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170724 ticker: 002415 to buy begin--------------
    to_buy:  
    ['600887', '600110', '002415', '002475', '600196', '002450']
    before cash: 11079611, price: 30.46, to_buy: 6, buy_vol: 60600
    after cash:9233274
    code
    000333    42500.0
    000568    35100.0
    000651    44700.0
    000858    33000.0
    002415    60600.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170724 ticker: 002475 to buy begin--------------
    to_buy:  
    ['600887', '600110', '002475', '600196', '002450']
    before cash: 9233274, price: 21.0, to_buy: 5, buy_vol: 87900
    after cash:7386912
    code
    000333    42500.0
    000568    35100.0
    000651    44700.0
    000858    33000.0
    002415    60600.0
    002475    87900.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170724 ticker: 600110 to buy begin--------------
    to_buy:  
    ['600887', '002450', '600110', '600196']
    before cash: 7386912, price: 15.73, to_buy: 4, buy_vol: 117400
    after cash:5539748
    code
    000333     42500.0
    000568     35100.0
    000651     44700.0
    000858     33000.0
    002415     60600.0
    002475     87900.0
    600110    117400.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170724 ticker: 600196 to buy begin--------------
    to_buy:  
    ['600887', '002450', '600196']
    before cash: 5539748, price: 29.15, to_buy: 3, buy_vol: 63300
    after cash:3694092
    code
    000333     42500.0
    000568     35100.0
    000651     44700.0
    000858     33000.0
    002415     60600.0
    002475     87900.0
    600110    117400.0
    600196     63300.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20170724 ticker: 600887 to buy begin--------------
    to_buy:  
    ['600887', '002450']
    before cash: 3694092, price: 21.19, to_buy: 2, buy_vol: 87100
    after cash:1847982
    code
    000333     42500.0
    000568     35100.0
    000651     44700.0
    000858     33000.0
    002415     60600.0
    002475     87900.0
    600110    117400.0
    600196     63300.0
    600887     87100.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2017-08-09  600196      3.5          0.0    0.0       0.0
    分红，增加现金22155.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20171027 ticker: 000333 to sell begin------------
    before cash: 1870137, price: 50.72, sell_vol: 42500
    after cash:4023042
    code
    000568     35100.0
    000651     44700.0
    000858     33000.0
    002415     60600.0
    002475     87900.0
    600110    117400.0
    600196     63300.0
    600887     87100.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20171027 ticker: 000568 to sell begin------------
    before cash: 4023042, price: 59.8, sell_vol: 35100
    after cash:6119399
    code
    000651     44700.0
    000858     33000.0
    002415     60600.0
    002475     87900.0
    600110    117400.0
    600196     63300.0
    600887     87100.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20171027 ticker: 000651 to sell begin------------
    before cash: 6119399, price: 43.77, sell_vol: 44700
    after cash:8073472
    code
    000858     33000.0
    002415     60600.0
    002475     87900.0
    600110    117400.0
    600196     63300.0
    600887     87100.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20171027 ticker: 000858 to sell begin------------
    before cash: 8073472, price: 67.99, sell_vol: 33000
    after cash:10314337
    code
    002415     60600.0
    002475     87900.0
    600110    117400.0
    600196     63300.0
    600887     87100.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20171027 ticker: 002415 to sell begin------------
    before cash: 10314337, price: 36.0, sell_vol: 60600
    after cash:12493210
    code
    002475     87900.0
    600110    117400.0
    600196     63300.0
    600887     87100.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20171027 ticker: 002475 to sell begin------------
    before cash: 12493210, price: 24.61, sell_vol: 87900
    after cash:14653725
    code
    600110    117400.0
    600196     63300.0
    600887     87100.0
    601069     38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20171027 ticker: 600110 to sell begin------------
    before cash: 14653725, price: 12.36, sell_vol: 117400
    after cash:16102975
    code
    600196    63300.0
    600887    87100.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20171027 ticker: 600196 to sell begin------------
    before cash: 16102975, price: 41.49, sell_vol: 63300
    after cash:18726010
    code
    600887    87100.0
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20171027 ticker: 600887 to sell begin------------
    before cash: 18726010, price: 30.19, sell_vol: 87100
    after cash:21352272
    code
    601069    38900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20171027 ticker: 601069 to sell begin------------
    before cash: 21352272, price: 17.99, sell_vol: 38900
    after cash:22051208
    Series([], Name: amount, dtype: float64)
    at 20171027 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20171030 ticker: 000333 to buy begin--------------
    to_buy:  
    ['300274', '601222', '600009', '000895', '600887', '000333', '000568', '600809', '002304', '000858', '600062', '600056', '002415', '600519']
    before cash: 22051208, price: 51.76, to_buy: 14, buy_vol: 30400
    after cash:20477310
    code
    000333    30400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20171030 ticker: 000568 to buy begin--------------
    to_buy:  
    ['300274', '601222', '600009', '000895', '600887', '000568', '600809', '002304', '000858', '600062', '600056', '002415', '600519']
    before cash: 20477310, price: 59.85, to_buy: 13, buy_vol: 26300
    after cash:18902862
    code
    000333    30400.0
    000568    26300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20171030 ticker: 000858 to buy begin--------------
    to_buy:  
    ['300274', '601222', '600009', '000895', '600887', '600809', '002304', '000858', '600062', '600056', '002415', '600519']
    before cash: 18902862, price: 67.0, to_buy: 12, buy_vol: 23500
    after cash:17327968
    code
    000333    30400.0
    000568    26300.0
    000858    23500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20171030 ticker: 000895 to buy begin--------------
    to_buy:  
    ['300274', '601222', '600009', '000895', '600887', '600809', '002304', '600056', '600062', '002415', '600519']
    before cash: 17327968, price: 25.85, to_buy: 11, buy_vol: 60900
    after cash:15753310
    code
    000333    30400.0
    000568    26300.0
    000858    23500.0
    000895    60900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20171030 ticker: 002304 to buy begin--------------
    to_buy:  
    ['300274', '601222', '600009', '600887', '600809', '002304', '600056', '600062', '002415', '600519']
    before cash: 15753310, price: 112.99, to_buy: 10, buy_vol: 13900
    after cash:14182356
    code
    000333    30400.0
    000568    26300.0
    000858    23500.0
    000895    60900.0
    002304    13900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20171030 ticker: 002415 to buy begin--------------
    to_buy:  
    ['300274', '601222', '600009', '600887', '600809', '600056', '600062', '002415', '600519']
    before cash: 14182356, price: 36.8, to_buy: 9, buy_vol: 42800
    after cash:12606922
    code
    000333    30400.0
    000568    26300.0
    000858    23500.0
    000895    60900.0
    002304    13900.0
    002415    42800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20171030 ticker: 300274 to buy begin--------------
    to_buy:  
    ['300274', '601222', '600009', '600887', '600809', '600056', '600062', '600519']
    before cash: 12606922, price: 17.79, to_buy: 8, buy_vol: 88500
    after cash:11032114
    code
    000333    30400.0
    000568    26300.0
    000858    23500.0
    000895    60900.0
    002304    13900.0
    002415    42800.0
    300274    88500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20171030 ticker: 600009 to buy begin--------------
    to_buy:  
    ['601222', '600009', '600887', '600809', '600056', '600062', '600519']
    before cash: 11032114, price: 43.19, to_buy: 7, buy_vol: 36400
    after cash:9459605
    code
    000333    30400.0
    000568    26300.0
    000858    23500.0
    000895    60900.0
    002304    13900.0
    002415    42800.0
    300274    88500.0
    600009    36400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20171030 ticker: 600056 to buy begin--------------
    to_buy:  
    ['601222', '600887', '600809', '600056', '600062', '600519']
    before cash: 9459605, price: 27.96, to_buy: 6, buy_vol: 56300
    after cash:7885063
    code
    000333    30400.0
    000568    26300.0
    000858    23500.0
    000895    60900.0
    002304    13900.0
    002415    42800.0
    300274    88500.0
    600009    36400.0
    600056    56300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20171030 ticker: 600062 to buy begin--------------
    to_buy:  
    ['601222', '600887', '600809', '600062', '600519']
    before cash: 7885063, price: 22.79, to_buy: 5, buy_vol: 69100
    after cash:6309880
    code
    000333    30400.0
    000568    26300.0
    000858    23500.0
    000895    60900.0
    002304    13900.0
    002415    42800.0
    300274    88500.0
    600009    36400.0
    600056    56300.0
    600062    69100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20171030 ticker: 600519 to buy begin--------------
    to_buy:  
    ['601222', '600887', '600809', '600519']
    before cash: 6309880, price: 622.08, to_buy: 4, buy_vol: 2500
    after cash:4754292
    code
    000333    30400.0
    000568    26300.0
    000858    23500.0
    000895    60900.0
    002304    13900.0
    002415    42800.0
    300274    88500.0
    600009    36400.0
    600056    56300.0
    600062    69100.0
    600519     2500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20171030 ticker: 600809 to buy begin--------------
    to_buy:  
    ['601222', '600887', '600809']
    before cash: 4754292, price: 59.27, to_buy: 3, buy_vol: 26700
    after cash:3171387
    code
    000333    30400.0
    000568    26300.0
    000858    23500.0
    000895    60900.0
    002304    13900.0
    002415    42800.0
    300274    88500.0
    600009    36400.0
    600056    56300.0
    600062    69100.0
    600519     2500.0
    600809    26700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20171030 ticker: 600887 to buy begin--------------
    to_buy:  
    ['601222', '600887']
    before cash: 3171387, price: 30.36, to_buy: 2, buy_vol: 52200
    after cash:1586199
    code
    000333    30400.0
    000568    26300.0
    000858    23500.0
    000895    60900.0
    002304    13900.0
    002415    42800.0
    300274    88500.0
    600009    36400.0
    600056    56300.0
    600062    69100.0
    600519     2500.0
    600809    26700.0
    600887    52200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20171030 ticker: 601222 to buy begin--------------
    to_buy:  
    ['601222']
    before cash: 1586199, price: 8.77, to_buy: 1, buy_vol: 180800
    after cash:186
    code
    000333     30400.0
    000568     26300.0
    000858     23500.0
    000895     60900.0
    002304     13900.0
    002415     42800.0
    300274     88500.0
    600009     36400.0
    600056     56300.0
    600062     69100.0
    600519      2500.0
    600809     26700.0
    600887     52200.0
    601222    180800.0
    Name: amount, dtype: float64
    at 20171030 clear the to_buy list successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20180122 ticker: 000333 to sell begin------------
    before cash: 186, price: 61.43, sell_vol: 30400
    after cash:1865324
    code
    000568     26300.0
    000858     23500.0
    000895     60900.0
    002304     13900.0
    002415     42800.0
    300274     88500.0
    600009     36400.0
    600056     56300.0
    600062     69100.0
    600519      2500.0
    600809     26700.0
    600887     52200.0
    601222    180800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180122 ticker: 000568 to sell begin------------
    before cash: 1865324, price: 70.9, sell_vol: 26300
    after cash:3727663
    code
    000858     23500.0
    000895     60900.0
    002304     13900.0
    002415     42800.0
    300274     88500.0
    600009     36400.0
    600056     56300.0
    600062     69100.0
    600519      2500.0
    600809     26700.0
    600887     52200.0
    601222    180800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180122 ticker: 000858 to sell begin------------
    before cash: 3727663, price: 90.42, sell_vol: 23500
    after cash:5849877
    code
    000895     60900.0
    002304     13900.0
    002415     42800.0
    300274     88500.0
    600009     36400.0
    600056     56300.0
    600062     69100.0
    600519      2500.0
    600809     26700.0
    600887     52200.0
    601222    180800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180122 ticker: 000895 to sell begin------------
    before cash: 5849877, price: 29.62, sell_vol: 60900
    after cash:7651480
    code
    002304     13900.0
    002415     42800.0
    300274     88500.0
    600009     36400.0
    600056     56300.0
    600062     69100.0
    600519      2500.0
    600809     26700.0
    600887     52200.0
    601222    180800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180122 ticker: 002304 to sell begin------------
    before cash: 7651480, price: 133.9, sell_vol: 13900
    after cash:9510364
    code
    002415     42800.0
    300274     88500.0
    600009     36400.0
    600056     56300.0
    600062     69100.0
    600519      2500.0
    600809     26700.0
    600887     52200.0
    601222    180800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180122 ticker: 002415 to sell begin------------
    before cash: 9510364, price: 41.55, sell_vol: 42800
    after cash:11286481
    code
    300274     88500.0
    600009     36400.0
    600056     56300.0
    600062     69100.0
    600519      2500.0
    600809     26700.0
    600887     52200.0
    601222    180800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180122 ticker: 300274 to sell begin------------
    before cash: 11286481, price: 17.14, sell_vol: 88500
    after cash:12801475
    code
    600009     36400.0
    600056     56300.0
    600062     69100.0
    600519      2500.0
    600809     26700.0
    600887     52200.0
    601222    180800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180122 ticker: 600009 to sell begin------------
    before cash: 12801475, price: 44.91, sell_vol: 36400
    after cash:14434155
    code
    600056     56300.0
    600062     69100.0
    600519      2500.0
    600809     26700.0
    600887     52200.0
    601222    180800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180122 ticker: 600056 to sell begin------------
    before cash: 14434155, price: 22.61, sell_vol: 56300
    after cash:15705507
    code
    600062     69100.0
    600519      2500.0
    600809     26700.0
    600887     52200.0
    601222    180800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180122 ticker: 600062 to sell begin------------
    before cash: 15705507, price: 24.21, sell_vol: 69100
    after cash:17376327
    code
    600519      2500.0
    600809     26700.0
    600887     52200.0
    601222    180800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180122 ticker: 600519 to sell begin------------
    before cash: 17376327, price: 773.64, sell_vol: 2500
    after cash:19308009
    code
    600809     26700.0
    600887     52200.0
    601222    180800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180122 ticker: 600887 to sell begin------------
    before cash: 19308009, price: 34.99, sell_vol: 52200
    after cash:21132204
    code
    600809     26700.0
    601222    180800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180122 ticker: 601222 to sell begin------------
    before cash: 21132204, price: 9.22, sell_vol: 180800
    after cash:22797097
    code
    600809    26700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20180123 ticker: 000333 to buy begin--------------
    to_buy:  
    ['601012', '600009', '600887', '000333', '000568', '000418', '002035', '000651', '002304', '000858', '603899', '600519']
    before cash: 22797097, price: 62.12, to_buy: 12, buy_vol: 30500
    after cash:20901963
    code
    000333    30500.0
    600809    26700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180123 ticker: 000568 to buy begin--------------
    to_buy:  
    ['601012', '600009', '600887', '000568', '000418', '002035', '000651', '002304', '000858', '603899', '600519']
    before cash: 20901963, price: 70.52, to_buy: 11, buy_vol: 26900
    after cash:19004501
    code
    000333    30500.0
    000568    26900.0
    600809    26700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180123 ticker: 000651 to buy begin--------------
    to_buy:  
    ['601012', '600009', '600887', '002035', '000651', '000418', '002304', '000858', '603899', '600519']
    before cash: 19004501, price: 56.79, to_buy: 10, buy_vol: 33400
    after cash:17107241
    code
    000333    30500.0
    000568    26900.0
    000651    33400.0
    600809    26700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180123 ticker: 000858 to buy begin--------------
    to_buy:  
    ['601012', '600009', '600887', '002035', '000418', '002304', '000858', '603899', '600519']
    before cash: 17107241, price: 89.71, to_buy: 9, buy_vol: 21100
    after cash:15213886
    code
    000333    30500.0
    000568    26900.0
    000651    33400.0
    000858    21100.0
    600809    26700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180123 ticker: 002035 to buy begin--------------
    to_buy:  
    ['601012', '600009', '600887', '002035', '000418', '002304', '603899', '600519']
    before cash: 15213886, price: 33.57, to_buy: 8, buy_vol: 56600
    after cash:13313349
    code
    000333    30500.0
    000568    26900.0
    000651    33400.0
    000858    21100.0
    002035    56600.0
    600809    26700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180123 ticker: 002304 to buy begin--------------
    to_buy:  
    ['601012', '600009', '600887', '000418', '002304', '603899', '600519']
    before cash: 13313349, price: 136.28, to_buy: 7, buy_vol: 13900
    after cash:11418584
    code
    000333    30500.0
    000568    26900.0
    000651    33400.0
    000858    21100.0
    002035    56600.0
    002304    13900.0
    600809    26700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180123 ticker: 600009 to buy begin--------------
    to_buy:  
    ['601012', '600009', '600887', '000418', '603899', '600519']
    before cash: 11418584, price: 47.02, to_buy: 6, buy_vol: 40400
    after cash:9518501
    code
    000333    30500.0
    000568    26900.0
    000651    33400.0
    000858    21100.0
    002035    56600.0
    002304    13900.0
    600009    40400.0
    600809    26700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180123 ticker: 600519 to buy begin--------------
    to_buy:  
    ['601012', '600887', '000418', '603899', '600519']
    before cash: 9518501, price: 773.78, to_buy: 5, buy_vol: 2400
    after cash:7660965
    code
    000333    30500.0
    000568    26900.0
    000651    33400.0
    000858    21100.0
    002035    56600.0
    002304    13900.0
    600009    40400.0
    600519     2400.0
    600809    26700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180123 ticker: 600887 to buy begin--------------
    to_buy:  
    ['600887', '603899', '601012', '000418']
    before cash: 7660965, price: 35.46, to_buy: 4, buy_vol: 54000
    after cash:5745646
    code
    000333    30500.0
    000568    26900.0
    000651    33400.0
    000858    21100.0
    002035    56600.0
    002304    13900.0
    600009    40400.0
    600519     2400.0
    600809    26700.0
    600887    54000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180123 ticker: 601012 to buy begin--------------
    to_buy:  
    ['603899', '601012', '000418']
    before cash: 5745646, price: 38.26, to_buy: 3, buy_vol: 50000
    after cash:3832168
    code
    000333    30500.0
    000568    26900.0
    000651    33400.0
    000858    21100.0
    002035    56600.0
    002304    13900.0
    600009    40400.0
    600519     2400.0
    600809    26700.0
    600887    54000.0
    601012    50000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180123 ticker: 603899 to buy begin--------------
    to_buy:  
    ['603899', '000418']
    before cash: 3832168, price: 24.4, to_buy: 2, buy_vol: 78500
    after cash:1916289
    code
    000333    30500.0
    000568    26900.0
    000651    33400.0
    000858    21100.0
    002035    56600.0
    002304    13900.0
    600009    40400.0
    600519     2400.0
    600809    26700.0
    600887    54000.0
    601012    50000.0
    603899    78500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20180423 ticker: 000333 to sell begin------------
    before cash: 1916289, price: 52.05, sell_vol: 30500
    after cash:3501829
    code
    000568    26900.0
    000651    33400.0
    000858    21100.0
    002035    56600.0
    002304    13900.0
    600009    40400.0
    600519     2400.0
    600809    26700.0
    600887    54000.0
    601012    50000.0
    603899    78500.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180423 ticker: 000568 to sell begin------------
    before cash: 3501829, price: 59.35, sell_vol: 26900
    after cash:5096349
    code
    000651    33400.0
    000858    21100.0
    002035    56600.0
    002304    13900.0
    600009    40400.0
    600519     2400.0
    600809    26700.0
    600887    54000.0
    601012    50000.0
    603899    78500.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180423 ticker: 000651 to sell begin------------
    before cash: 5096349, price: 49.72, sell_vol: 33400
    after cash:6754921
    code
    000858    21100.0
    002035    56600.0
    002304    13900.0
    600009    40400.0
    600519     2400.0
    600809    26700.0
    600887    54000.0
    601012    50000.0
    603899    78500.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180423 ticker: 000858 to sell begin------------
    before cash: 6754921, price: 69.69, sell_vol: 21100
    after cash:8223542
    code
    002035    56600.0
    002304    13900.0
    600009    40400.0
    600519     2400.0
    600809    26700.0
    600887    54000.0
    601012    50000.0
    603899    78500.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180423 ticker: 002035 to sell begin------------
    before cash: 8223542, price: 25.28, sell_vol: 56600
    after cash:9652601
    code
    002304    13900.0
    600009    40400.0
    600519     2400.0
    600809    26700.0
    600887    54000.0
    601012    50000.0
    603899    78500.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180423 ticker: 002304 to sell begin------------
    before cash: 9652601, price: 110.99, sell_vol: 13900
    after cash:11193434
    code
    600009    40400.0
    600519     2400.0
    600809    26700.0
    600887    54000.0
    601012    50000.0
    603899    78500.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180423 ticker: 600009 to sell begin------------
    before cash: 11193434, price: 45.27, sell_vol: 40400
    after cash:13020056
    code
    600519     2400.0
    600809    26700.0
    600887    54000.0
    601012    50000.0
    603899    78500.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180423 ticker: 600519 to sell begin------------
    before cash: 13020056, price: 674.01, sell_vol: 2400
    after cash:14635658
    code
    600809    26700.0
    600887    54000.0
    601012    50000.0
    603899    78500.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180423 ticker: 600809 to sell begin------------
    before cash: 14635658, price: 53.47, sell_vol: 26700
    after cash:16061522
    code
    600887    54000.0
    601012    50000.0
    603899    78500.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180423 ticker: 600887 to sell begin------------
    before cash: 16061522, price: 28.26, sell_vol: 54000
    after cash:17585655
    code
    601012    50000.0
    603899    78500.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180423 ticker: 601012 to sell begin------------
    before cash: 17585655, price: 34.08, sell_vol: 50000
    after cash:19287525
    code
    603899    78500.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180423 ticker: 603899 to sell begin------------
    before cash: 19287525, price: 27.83, sell_vol: 78500
    after cash:21469449
    Series([], Name: amount, dtype: float64)
    at 20180423 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20180424 ticker: 000333 to buy begin--------------
    to_buy:  
    ['601012', '002044', '000333', '000568', '000651', '600276', '002304', '002475', '600867', '603899', '600566', '600519']
    before cash: 21469449, price: 53.55, to_buy: 12, buy_vol: 33400
    after cash:19680432
    code
    000333    33400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180424 ticker: 000568 to buy begin--------------
    to_buy:  
    ['601012', '002044', '000568', '000651', '600276', '002304', '002475', '600867', '603899', '600566', '600519']
    before cash: 19680432, price: 62.67, to_buy: 11, buy_vol: 28500
    after cash:17893890
    code
    000333    33400.0
    000568    28500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180424 ticker: 000651 to buy begin--------------
    to_buy:  
    ['601012', '002044', '000651', '600276', '002304', '002475', '600867', '603899', '600566', '600519']
    before cash: 17893890, price: 50.19, to_buy: 10, buy_vol: 35600
    after cash:16106679
    code
    000333    33400.0
    000568    28500.0
    000651    35600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180424 ticker: 002044 to buy begin--------------
    to_buy:  
    ['601012', '002044', '600276', '002304', '002475', '600867', '603899', '600566', '600519']
    before cash: 16106679, price: 26.7, to_buy: 9, buy_vol: 67000
    after cash:14317332
    code
    000333    33400.0
    000568    28500.0
    000651    35600.0
    002044    67000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180424 ticker: 002304 to buy begin--------------
    to_buy:  
    ['601012', '600276', '002304', '600867', '002475', '603899', '600566', '600519']
    before cash: 14317332, price: 114.32, to_buy: 8, buy_vol: 15600
    after cash:12533494
    code
    000333    33400.0
    000568    28500.0
    000651    35600.0
    002044    67000.0
    002304    15600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180424 ticker: 002475 to buy begin--------------
    to_buy:  
    ['601012', '600276', '600867', '002475', '603899', '600566', '600519']
    before cash: 12533494, price: 20.35, to_buy: 7, buy_vol: 87900
    after cash:10744282
    code
    000333    33400.0
    000568    28500.0
    000651    35600.0
    002044    67000.0
    002304    15600.0
    002475    87900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180424 ticker: 600276 to buy begin--------------
    to_buy:  
    ['601012', '600276', '600867', '603899', '600566', '600519']
    before cash: 10744282, price: 84.75, to_buy: 6, buy_vol: 21100
    after cash:8955610
    code
    000333    33400.0
    000568    28500.0
    000651    35600.0
    002044    67000.0
    002304    15600.0
    002475    87900.0
    600276    21100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180424 ticker: 600519 to buy begin--------------
    to_buy:  
    ['601012', '600867', '603899', '600566', '600519']
    before cash: 8955610, price: 689.88, to_buy: 5, buy_vol: 2500
    after cash:7230479
    code
    000333    33400.0
    000568    28500.0
    000651    35600.0
    002044    67000.0
    002304    15600.0
    002475    87900.0
    600276    21100.0
    600519     2500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180424 ticker: 600566 to buy begin--------------
    to_buy:  
    ['603899', '601012', '600867', '600566']
    before cash: 7230479, price: 49.67, to_buy: 4, buy_vol: 36300
    after cash:5427007
    code
    000333    33400.0
    000568    28500.0
    000651    35600.0
    002044    67000.0
    002304    15600.0
    002475    87900.0
    600276    21100.0
    600519     2500.0
    600566    36300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180424 ticker: 600867 to buy begin--------------
    to_buy:  
    ['603899', '601012', '600867']
    before cash: 5427007, price: 25.41, to_buy: 3, buy_vol: 71100
    after cash:3619904
    code
    000333    33400.0
    000568    28500.0
    000651    35600.0
    002044    67000.0
    002304    15600.0
    002475    87900.0
    600276    21100.0
    600519     2500.0
    600566    36300.0
    600867    71100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180424 ticker: 601012 to buy begin--------------
    to_buy:  
    ['603899', '601012']
    before cash: 3619904, price: 35.32, to_buy: 2, buy_vol: 51200
    after cash:1811068
    code
    000333    33400.0
    000568    28500.0
    000651    35600.0
    002044    67000.0
    002304    15600.0
    002475    87900.0
    600276    21100.0
    600519     2500.0
    600566    36300.0
    600867    71100.0
    601012    51200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180424 ticker: 603899 to buy begin--------------
    to_buy:  
    ['603899']
    before cash: 1811068, price: 28.79, to_buy: 1, buy_vol: 62900
    ALERT MONEY NOT ENOUGH!!!
    1811068.3587499866
    after cash:1811068
    code
    000333    33400.0
    000568    28500.0
    000651    35600.0
    002044    67000.0
    002304    15600.0
    002475    87900.0
    600276    21100.0
    600519     2500.0
    600566    36300.0
    600867    71100.0
    601012    51200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2018-05-04  000333     12.0          0.0    0.0       0.0
    分红，增加现金40080.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2018-05-25  600867      2.0          2.0    0.0       0.0
    分红，增加现金14220.0
    转增股，增加股票14200.0股600867
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2018-05-29  601012      1.8          4.0    0.0       0.0
    分红，增加现金9216.0
    转增股，增加股票20400.0股601012
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2018-05-30  600276      1.3          3.0    0.0       0.0
    分红，增加现金2743.0
    转增股，增加股票6300.0股600276
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2018-06-01  600566     10.0          0.0    0.0       0.0
    分红，增加现金36300.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2018-06-11  002044      0.5          2.0    0.0       0.0
    分红，增加现金3350.0
    转增股，增加股票13400.0股002044
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code     fenhong  songzhuangu  peigu  peigujia
    date                                                        
    2018-06-15  600519  109.989998          0.0    0.0       0.0
    分红，增加现金27497.5
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2018-06-22  002304     25.5          0.0    0.0       0.0
    分红，增加现金39780.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2018-07-16  000568     12.5          0.0    0.0       0.0
    分红，增加现金35625.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2018-07-17  002475      0.6          3.0    0.0       0.0
    分红，增加现金5274.0
    转增股，增加股票26300.0股002475
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20180720 ticker: 000333 to sell begin------------
    before cash: 2025129, price: 46.57, sell_vol: 33400
    after cash:3578623
    code
    000568     28500.0
    000651     35600.0
    002044     80400.0
    002304     15600.0
    002475    114200.0
    600276     27400.0
    600519      2500.0
    600566     36300.0
    600867     85300.0
    601012     71600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180720 ticker: 000568 to sell begin------------
    before cash: 3578623, price: 56.37, sell_vol: 28500
    after cash:5183159
    code
    000651     35600.0
    002044     80400.0
    002304     15600.0
    002475    114200.0
    600276     27400.0
    600519      2500.0
    600566     36300.0
    600867     85300.0
    601012     71600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180720 ticker: 000651 to sell begin------------
    before cash: 5183159, price: 45.06, sell_vol: 35600
    after cash:6785290
    code
    002044     80400.0
    002304     15600.0
    002475    114200.0
    600276     27400.0
    600519      2500.0
    600566     36300.0
    600867     85300.0
    601012     71600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180720 ticker: 002044 to sell begin------------
    before cash: 6785290, price: 22.39, sell_vol: 80400
    after cash:8583196
    code
    002304     15600.0
    002475    114200.0
    600276     27400.0
    600519      2500.0
    600566     36300.0
    600867     85300.0
    601012     71600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180720 ticker: 002304 to sell begin------------
    before cash: 8583196, price: 132.26, sell_vol: 15600
    after cash:10643873
    code
    002475    114200.0
    600276     27400.0
    600519      2500.0
    600566     36300.0
    600867     85300.0
    601012     71600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180720 ticker: 002475 to sell begin------------
    before cash: 10643873, price: 18.56, sell_vol: 114200
    after cash:12760776
    code
    600276    27400.0
    600519     2500.0
    600566    36300.0
    600867    85300.0
    601012    71600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180720 ticker: 600276 to sell begin------------
    before cash: 12760776, price: 73.76, sell_vol: 27400
    after cash:14779273
    code
    600519     2500.0
    600566    36300.0
    600867    85300.0
    601012    71600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180720 ticker: 600519 to sell begin------------
    before cash: 14779273, price: 741.13, sell_vol: 2500
    after cash:16629782
    code
    600566    36300.0
    600867    85300.0
    601012    71600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180720 ticker: 600566 to sell begin------------
    before cash: 16629782, price: 49.95, sell_vol: 36300
    after cash:18440701
    code
    600867    85300.0
    601012    71600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180720 ticker: 600867 to sell begin------------
    before cash: 18440701, price: 25.29, sell_vol: 85300
    after cash:20595241
    code
    601012    71600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20180720 ticker: 601012 to sell begin------------
    before cash: 20595241, price: 15.08, sell_vol: 71600
    after cash:21673620
    Series([], Name: amount, dtype: float64)
    at 20180720 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20180723 ticker: 000333 to buy begin--------------
    to_buy:  
    ['600887', '600763', '000651', '000568', '000333', '600276', '600703', '002304', '000858', '600741', '603883', '600566', '600519']
    before cash: 21673620, price: 46.58, to_buy: 13, buy_vol: 35700
    after cash:20010298
    code
    000333    35700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180723 ticker: 000568 to buy begin--------------
    to_buy:  
    ['600887', '600763', '000651', '000568', '600276', '600703', '002304', '000858', '600741', '603883', '600566', '600519']
    before cash: 20010298, price: 55.23, to_buy: 12, buy_vol: 30100
    after cash:18347459
    code
    000333    35700.0
    000568    30100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180723 ticker: 000651 to buy begin--------------
    to_buy:  
    ['600887', '600763', '000651', '600276', '600703', '002304', '000858', '600741', '603883', '600566', '600519']
    before cash: 18347459, price: 44.5, to_buy: 11, buy_vol: 37400
    after cash:16682743
    code
    000333    35700.0
    000568    30100.0
    000651    37400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180723 ticker: 000858 to buy begin--------------
    to_buy:  
    ['600887', '600763', '600566', '600276', '002304', '000858', '600741', '603883', '600703', '600519']
    before cash: 16682743, price: 72.12, to_buy: 10, buy_vol: 23100
    after cash:15016355
    code
    000333    35700.0
    000568    30100.0
    000651    37400.0
    000858    23100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180723 ticker: 002304 to buy begin--------------
    to_buy:  
    ['600887', '600763', '600566', '600276', '002304', '600741', '603883', '600703', '600519']
    before cash: 15016355, price: 129.9, to_buy: 9, buy_vol: 12800
    after cash:13353219
    code
    000333    35700.0
    000568    30100.0
    000651    37400.0
    000858    23100.0
    002304    12800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180723 ticker: 600276 to buy begin--------------
    to_buy:  
    ['600887', '600763', '600566', '600276', '600741', '603883', '600703', '600519']
    before cash: 13353219, price: 70.19, to_buy: 8, buy_vol: 23700
    after cash:11689300
    code
    000333    35700.0
    000568    30100.0
    000651    37400.0
    000858    23100.0
    002304    12800.0
    600276    23700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180723 ticker: 600519 to buy begin--------------
    to_buy:  
    ['600887', '600763', '600566', '600741', '603883', '600703', '600519']
    before cash: 11689300, price: 732.07, to_buy: 7, buy_vol: 2200
    after cash:10078343
    code
    000333    35700.0
    000568    30100.0
    000651    37400.0
    000858    23100.0
    002304    12800.0
    600276    23700.0
    600519     2200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180723 ticker: 600566 to buy begin--------------
    to_buy:  
    ['600887', '600763', '600566', '600741', '603883', '600703']
    before cash: 10078343, price: 47.63, to_buy: 6, buy_vol: 35200
    after cash:8401348
    code
    000333    35700.0
    000568    30100.0
    000651    37400.0
    000858    23100.0
    002304    12800.0
    600276    23700.0
    600519     2200.0
    600566    35200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180723 ticker: 600703 to buy begin--------------
    to_buy:  
    ['600887', '600763', '600741', '603883', '600703']
    before cash: 8401348, price: 20.18, to_buy: 5, buy_vol: 83200
    after cash:6721953
    code
    000333    35700.0
    000568    30100.0
    000651    37400.0
    000858    23100.0
    002304    12800.0
    600276    23700.0
    600519     2200.0
    600566    35200.0
    600703    83200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180723 ticker: 600741 to buy begin--------------
    to_buy:  
    ['600887', '600763', '603883', '600741']
    before cash: 6721953, price: 23.28, to_buy: 4, buy_vol: 72100
    after cash:5043045
    code
    000333    35700.0
    000568    30100.0
    000651    37400.0
    000858    23100.0
    002304    12800.0
    600276    23700.0
    600519     2200.0
    600566    35200.0
    600703    83200.0
    600741    72100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180723 ticker: 600763 to buy begin--------------
    to_buy:  
    ['600887', '600763', '603883']
    before cash: 5043045, price: 51.4, to_buy: 3, buy_vol: 32700
    after cash:3361845
    code
    000333    35700.0
    000568    30100.0
    000651    37400.0
    000858    23100.0
    002304    12800.0
    600276    23700.0
    600519     2200.0
    600566    35200.0
    600703    83200.0
    600741    72100.0
    600763    32700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180723 ticker: 600887 to buy begin--------------
    to_buy:  
    ['600887', '603883']
    before cash: 3361845, price: 27.59, to_buy: 2, buy_vol: 60900
    after cash:1681194
    code
    000333    35700.0
    000568    30100.0
    000651    37400.0
    000858    23100.0
    002304    12800.0
    600276    23700.0
    600519     2200.0
    600566    35200.0
    600703    83200.0
    600741    72100.0
    600763    32700.0
    600887    60900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20180723 ticker: 603883 to buy begin--------------
    to_buy:  
    ['603883']
    before cash: 1681194, price: 77.08, to_buy: 1, buy_vol: 21800
    after cash:430
    code
    000333    35700.0
    000568    30100.0
    000651    37400.0
    000858    23100.0
    002304    12800.0
    600276    23700.0
    600519     2200.0
    600566    35200.0
    600703    83200.0
    600741    72100.0
    600763    32700.0
    600887    60900.0
    603883    21800.0
    Name: amount, dtype: float64
    at 20180723 clear the to_buy list successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20181026 ticker: 000568 to sell begin------------
    before cash: 430, price: 38.36, sell_vol: 30100
    after cash:1153622
    code
    000333    35700.0
    000651    37400.0
    000858    23100.0
    002304    12800.0
    600276    23700.0
    600519     2200.0
    600566    35200.0
    600703    83200.0
    600741    72100.0
    600763    32700.0
    600887    60900.0
    603883    21800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20181026 ticker: 000651 to sell begin------------
    before cash: 1153622, price: 38.8, sell_vol: 37400
    after cash:2602928
    code
    000333    35700.0
    000858    23100.0
    002304    12800.0
    600276    23700.0
    600519     2200.0
    600566    35200.0
    600703    83200.0
    600741    72100.0
    600763    32700.0
    600887    60900.0
    603883    21800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20181026 ticker: 000858 to sell begin------------
    before cash: 2602928, price: 54.3, sell_vol: 23100
    after cash:3855690
    code
    000333    35700.0
    002304    12800.0
    600276    23700.0
    600519     2200.0
    600566    35200.0
    600703    83200.0
    600741    72100.0
    600763    32700.0
    600887    60900.0
    603883    21800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20181026 ticker: 002304 to sell begin------------
    before cash: 3855690, price: 96.0, sell_vol: 12800
    after cash:5082954
    code
    000333    35700.0
    600276    23700.0
    600519     2200.0
    600566    35200.0
    600703    83200.0
    600741    72100.0
    600763    32700.0
    600887    60900.0
    603883    21800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20181026 ticker: 600276 to sell begin------------
    before cash: 5082954, price: 57.8, sell_vol: 23700
    after cash:6451102
    code
    000333    35700.0
    600519     2200.0
    600566    35200.0
    600703    83200.0
    600741    72100.0
    600763    32700.0
    600887    60900.0
    603883    21800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20181026 ticker: 600519 to sell begin------------
    before cash: 6451102, price: 610.1, sell_vol: 2200
    after cash:7791644
    code
    000333    35700.0
    600566    35200.0
    600703    83200.0
    600741    72100.0
    600763    32700.0
    600887    60900.0
    603883    21800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20181026 ticker: 600566 to sell begin------------
    before cash: 7791644, price: 39.83, sell_vol: 35200
    after cash:9191908
    code
    000333    35700.0
    600703    83200.0
    600741    72100.0
    600763    32700.0
    600887    60900.0
    603883    21800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20181026 ticker: 600703 to sell begin------------
    before cash: 9191908, price: 13.2, sell_vol: 83200
    after cash:10288775
    code
    000333    35700.0
    600741    72100.0
    600763    32700.0
    600887    60900.0
    603883    21800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20181026 ticker: 600741 to sell begin------------
    before cash: 10288775, price: 18.7, sell_vol: 72100
    after cash:11635360
    code
    000333    35700.0
    600763    32700.0
    600887    60900.0
    603883    21800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20181026 ticker: 600763 to sell begin------------
    before cash: 11635360, price: 46.42, sell_vol: 32700
    after cash:13151396
    code
    000333    35700.0
    600887    60900.0
    603883    21800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20181026 ticker: 600887 to sell begin------------
    before cash: 13151396, price: 22.81, sell_vol: 60900
    after cash:14538789
    code
    000333    35700.0
    603883    21800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20181026 ticker: 603883 to sell begin------------
    before cash: 14538789, price: 54.9, sell_vol: 21800
    after cash:15734113
    code
    000333    35700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20181029 ticker: 000568 to buy begin--------------
    to_buy:  
    ['000661', '000651', '000568', '600763', '600276', '002304', '000858', '300015', '603883', '603899', '600519', '002311']
    before cash: 15734113, price: 35.6, to_buy: 12, buy_vol: 36800
    after cash:14423705
    code
    000333    35700.0
    000568    36800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20181029 ticker: 000651 to buy begin--------------
    to_buy:  
    ['000661', '000651', '600763', '600276', '002304', '000858', '300015', '603883', '603899', '600519', '002311']
    before cash: 14423705, price: 36.38, to_buy: 11, buy_vol: 36000
    after cash:13113698
    code
    000333    35700.0
    000568    36800.0
    000651    36000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20181029 ticker: 000661 to buy begin--------------
    to_buy:  
    ['000661', '600763', '600276', '002304', '000858', '300015', '002311', '603883', '603899', '600519']
    before cash: 13113698, price: 161.98, to_buy: 10, buy_vol: 8000
    after cash:11817534
    code
    000333    35700.0
    000568    36800.0
    000651    36000.0
    000661     8000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20181029 ticker: 000858 to buy begin--------------
    to_buy:  
    ['600763', '600276', '002304', '000858', '300015', '002311', '603883', '603899', '600519']
    before cash: 11817534, price: 48.87, to_buy: 9, buy_vol: 26800
    after cash:10507491
    code
    000333    35700.0
    000568    36800.0
    000651    36000.0
    000661     8000.0
    000858    26800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20181029 ticker: 002304 to buy begin--------------
    to_buy:  
    ['600763', '600276', '002304', '300015', '002311', '603883', '603899', '600519']
    before cash: 10507491, price: 86.4, to_buy: 8, buy_vol: 15200
    after cash:9193882
    code
    000333    35700.0
    000568    36800.0
    000651    36000.0
    000661     8000.0
    000858    26800.0
    002304    15200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20181029 ticker: 002311 to buy begin--------------
    to_buy:  
    ['600763', '600276', '300015', '002311', '603883', '603899', '600519']
    before cash: 9193882, price: 19.43, to_buy: 7, buy_vol: 67500
    after cash:7882029
    code
    000333    35700.0
    000568    36800.0
    000651    36000.0
    000661     8000.0
    000858    26800.0
    002304    15200.0
    002311    67500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20181029 ticker: 300015 to buy begin--------------
    to_buy:  
    ['600763', '600276', '300015', '603883', '603899', '600519']
    before cash: 7882029, price: 26.21, to_buy: 6, buy_vol: 50100
    after cash:6568580
    code
    000333    35700.0
    000568    36800.0
    000651    36000.0
    000661     8000.0
    000858    26800.0
    002304    15200.0
    002311    67500.0
    300015    50100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20181029 ticker: 600276 to buy begin--------------
    to_buy:  
    ['600763', '600276', '603883', '603899', '600519']
    before cash: 6568580, price: 56.51, to_buy: 5, buy_vol: 23200
    after cash:5257220
    code
    000333    35700.0
    000568    36800.0
    000651    36000.0
    000661     8000.0
    000858    26800.0
    002304    15200.0
    002311    67500.0
    300015    50100.0
    600276    23200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20181029 ticker: 600519 to buy begin--------------
    to_buy:  
    ['600763', '603883', '603899', '600519']
    before cash: 5257220, price: 549.09, to_buy: 4, buy_vol: 2300
    after cash:3993998
    code
    000333    35700.0
    000568    36800.0
    000651    36000.0
    000661     8000.0
    000858    26800.0
    002304    15200.0
    002311    67500.0
    300015    50100.0
    600276    23200.0
    600519     2300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20181029 ticker: 600763 to buy begin--------------
    to_buy:  
    ['600763', '603883', '603899']
    before cash: 3993998, price: 45.3, to_buy: 3, buy_vol: 29300
    after cash:2666376
    code
    000333    35700.0
    000568    36800.0
    000651    36000.0
    000661     8000.0
    000858    26800.0
    002304    15200.0
    002311    67500.0
    300015    50100.0
    600276    23200.0
    600519     2300.0
    600763    29300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20181029 ticker: 603883 to buy begin--------------
    to_buy:  
    ['603883', '603899']
    before cash: 2666376, price: 54.68, to_buy: 2, buy_vol: 24300
    after cash:1337320
    code
    000333    35700.0
    000568    36800.0
    000651    36000.0
    000661     8000.0
    000858    26800.0
    002304    15200.0
    002311    67500.0
    300015    50100.0
    600276    23200.0
    600519     2300.0
    600763    29300.0
    603883    24300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20181029 ticker: 603899 to buy begin--------------
    to_buy:  
    ['603899']
    before cash: 1337320, price: 25.9, to_buy: 1, buy_vol: 51600
    after cash:545
    code
    000333    35700.0
    000568    36800.0
    000651    36000.0
    000661     8000.0
    000858    26800.0
    002304    15200.0
    002311    67500.0
    300015    50100.0
    600276    23200.0
    600519     2300.0
    600763    29300.0
    603883    24300.0
    603899    51600.0
    Name: amount, dtype: float64
    at 20181029 clear the to_buy list successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20190122 ticker: 000333 to sell begin------------
    before cash: 545, price: 41.3, sell_vol: 35700
    after cash:1473112
    code
    000568    36800.0
    000651    36000.0
    000661     8000.0
    000858    26800.0
    002304    15200.0
    002311    67500.0
    300015    50100.0
    600276    23200.0
    600519     2300.0
    600763    29300.0
    603883    24300.0
    603899    51600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190122 ticker: 000568 to sell begin------------
    before cash: 1473112, price: 42.05, sell_vol: 36800
    after cash:3018618
    code
    000651    36000.0
    000661     8000.0
    000858    26800.0
    002304    15200.0
    002311    67500.0
    300015    50100.0
    600276    23200.0
    600519     2300.0
    600763    29300.0
    603883    24300.0
    603899    51600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190122 ticker: 000651 to sell begin------------
    before cash: 3018618, price: 38.91, sell_vol: 36000
    after cash:4417627
    code
    000661     8000.0
    000858    26800.0
    002304    15200.0
    002311    67500.0
    300015    50100.0
    600276    23200.0
    600519     2300.0
    600763    29300.0
    603883    24300.0
    603899    51600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190122 ticker: 000661 to sell begin------------
    before cash: 4417627, price: 187.51, sell_vol: 8000
    after cash:5915832
    code
    000858    26800.0
    002304    15200.0
    002311    67500.0
    300015    50100.0
    600276    23200.0
    600519     2300.0
    600763    29300.0
    603883    24300.0
    603899    51600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190122 ticker: 000858 to sell begin------------
    before cash: 5915832, price: 55.21, sell_vol: 26800
    after cash:7393611
    code
    002304    15200.0
    002311    67500.0
    300015    50100.0
    600276    23200.0
    600519     2300.0
    600763    29300.0
    603883    24300.0
    603899    51600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190122 ticker: 002304 to sell begin------------
    before cash: 7393611, price: 98.75, sell_vol: 15200
    after cash:8892734
    code
    002311    67500.0
    300015    50100.0
    600276    23200.0
    600519     2300.0
    600763    29300.0
    603883    24300.0
    603899    51600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190122 ticker: 002311 to sell begin------------
    before cash: 8892734, price: 23.9, sell_vol: 67500
    after cash:10503968
    code
    300015    50100.0
    600276    23200.0
    600519     2300.0
    600763    29300.0
    603883    24300.0
    603899    51600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190122 ticker: 300015 to sell begin------------
    before cash: 10503968, price: 26.84, sell_vol: 50100
    after cash:11846971
    code
    600276    23200.0
    600519     2300.0
    600763    29300.0
    603883    24300.0
    603899    51600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190122 ticker: 600276 to sell begin------------
    before cash: 11846971, price: 57.69, sell_vol: 23200
    after cash:13183706
    code
    600519     2300.0
    600763    29300.0
    603883    24300.0
    603899    51600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190122 ticker: 600519 to sell begin------------
    before cash: 13183706, price: 671.0, sell_vol: 2300
    after cash:14725077
    code
    600763    29300.0
    603883    24300.0
    603899    51600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190122 ticker: 600763 to sell begin------------
    before cash: 14725077, price: 49.15, sell_vol: 29300
    after cash:16163372
    code
    603883    24300.0
    603899    51600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190122 ticker: 603883 to sell begin------------
    before cash: 16163372, price: 48.17, sell_vol: 24300
    after cash:17332439
    code
    603899    51600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190122 ticker: 603899 to sell begin------------
    before cash: 17332439, price: 29.24, sell_vol: 51600
    after cash:18839337
    Series([], Name: amount, dtype: float64)
    at 20190122 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20190123 ticker: 000568 to buy begin--------------
    to_buy:  
    ['600406', '002044', '600887', '000651', '000568', '002304', '000858', '600085', '300253', '300498', '300365', '603288', '600519', '002311']
    before cash: 18839337, price: 42.26, to_buy: 14, buy_vol: 31800
    after cash:17495134
    code
    000568    31800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190123 ticker: 000651 to buy begin--------------
    to_buy:  
    ['600406', '002044', '600887', '000651', '002304', '000858', '600085', '300253', '300498', '300365', '603288', '600519', '002311']
    before cash: 17495134, price: 39.19, to_buy: 13, buy_vol: 34300
    after cash:16150580
    code
    000568    31800.0
    000651    34300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190123 ticker: 000858 to buy begin--------------
    to_buy:  
    ['600406', '002044', '600887', '002304', '000858', '600085', '300253', '300498', '300365', '603288', '600519', '002311']
    before cash: 16150580, price: 55.07, to_buy: 12, buy_vol: 24400
    after cash:14806537
    code
    000568    31800.0
    000651    34300.0
    000858    24400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190123 ticker: 002044 to buy begin--------------
    to_buy:  
    ['600406', '002044', '600887', '002304', '600085', '300253', '002311', '300498', '300365', '603288', '600519']
    before cash: 14806537, price: 15.57, to_buy: 11, buy_vol: 86400
    after cash:13460952
    code
    000568    31800.0
    000651    34300.0
    000858    24400.0
    002044    86400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190123 ticker: 002304 to buy begin--------------
    to_buy:  
    ['600406', '600887', '002304', '600085', '300253', '002311', '300498', '300365', '603288', '600519']
    before cash: 13460952, price: 98.98, to_buy: 10, buy_vol: 13500
    after cash:12124388
    code
    000568    31800.0
    000651    34300.0
    000858    24400.0
    002044    86400.0
    002304    13500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190123 ticker: 002311 to buy begin--------------
    to_buy:  
    ['600406', '600887', '600085', '300253', '002311', '300498', '300365', '603288', '600519']
    before cash: 12124388, price: 24.5, to_buy: 9, buy_vol: 54900
    after cash:10779002
    code
    000568    31800.0
    000651    34300.0
    000858    24400.0
    002044    86400.0
    002304    13500.0
    002311    54900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190123 ticker: 300253 to buy begin--------------
    to_buy:  
    ['600406', '600887', '600085', '300253', '300498', '300365', '603288', '600519']
    before cash: 10779002, price: 10.0, to_buy: 8, buy_vol: 134700
    after cash:9431665
    code
    000568     31800.0
    000651     34300.0
    000858     24400.0
    002044     86400.0
    002304     13500.0
    002311     54900.0
    300253    134700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190123 ticker: 300365 to buy begin--------------
    to_buy:  
    ['600406', '600887', '600085', '300498', '300365', '603288', '600519']
    before cash: 9431665, price: 20.84, to_buy: 7, buy_vol: 64600
    after cash:8085065
    code
    000568     31800.0
    000651     34300.0
    000858     24400.0
    002044     86400.0
    002304     13500.0
    002311     54900.0
    300253    134700.0
    300365     64600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190123 ticker: 300498 to buy begin--------------
    to_buy:  
    ['600406', '600887', '600085', '300498', '603288', '600519']
    before cash: 8085065, price: 27.2, to_buy: 6, buy_vol: 49500
    after cash:6738328
    code
    000568     31800.0
    000651     34300.0
    000858     24400.0
    002044     86400.0
    002304     13500.0
    002311     54900.0
    300253    134700.0
    300365     64600.0
    300498     49500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190123 ticker: 600085 to buy begin--------------
    to_buy:  
    ['600406', '600887', '600085', '603288', '600519']
    before cash: 6738328, price: 26.91, to_buy: 5, buy_vol: 50000
    after cash:5392492
    code
    000568     31800.0
    000651     34300.0
    000858     24400.0
    002044     86400.0
    002304     13500.0
    002311     54900.0
    300253    134700.0
    300365     64600.0
    300498     49500.0
    600085     50000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190123 ticker: 600406 to buy begin--------------
    to_buy:  
    ['600887', '600406', '603288', '600519']
    before cash: 5392492, price: 19.49, to_buy: 4, buy_vol: 69100
    after cash:4045396
    code
    000568     31800.0
    000651     34300.0
    000858     24400.0
    002044     86400.0
    002304     13500.0
    002311     54900.0
    300253    134700.0
    300365     64600.0
    300498     49500.0
    600085     50000.0
    600406     69100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190123 ticker: 600519 to buy begin--------------
    to_buy:  
    ['600887', '603288', '600519']
    before cash: 4045396, price: 665.66, to_buy: 3, buy_vol: 2000
    after cash:2713743
    code
    000568     31800.0
    000651     34300.0
    000858     24400.0
    002044     86400.0
    002304     13500.0
    002311     54900.0
    300253    134700.0
    300365     64600.0
    300498     49500.0
    600085     50000.0
    600406     69100.0
    600519      2000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190123 ticker: 600887 to buy begin--------------
    to_buy:  
    ['600887', '603288']
    before cash: 2713743, price: 24.3, to_buy: 2, buy_vol: 55800
    after cash:1357464
    code
    000568     31800.0
    000651     34300.0
    000858     24400.0
    002044     86400.0
    002304     13500.0
    002311     54900.0
    300253    134700.0
    300365     64600.0
    300498     49500.0
    600085     50000.0
    600406     69100.0
    600519      2000.0
    600887     55800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190123 ticker: 603288 to buy begin--------------
    to_buy:  
    ['603288']
    before cash: 1357464, price: 71.99, to_buy: 1, buy_vol: 18800
    after cash:3714
    code
    000568     31800.0
    000651     34300.0
    000858     24400.0
    002044     86400.0
    002304     13500.0
    002311     54900.0
    300253    134700.0
    300365     64600.0
    300498     49500.0
    600085     50000.0
    600406     69100.0
    600519      2000.0
    600887     55800.0
    603288     18800.0
    Name: amount, dtype: float64
    at 20190123 clear the to_buy list successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2019-02-25  000651      6.0          0.0    0.0       0.0
    分红，增加现金20580.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2019-04-08  600887      7.0          0.0    0.0       0.0
    分红，增加现金39060.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20190422 ticker: 000568 to sell begin------------
    before cash: 63354, price: 69.98, sell_vol: 31800
    after cash:2285936
    code
    000651     34300.0
    000858     24400.0
    002044     86400.0
    002304     13500.0
    002311     54900.0
    300253    134700.0
    300365     64600.0
    300498     49500.0
    600085     50000.0
    600406     69100.0
    600519      2000.0
    600887     55800.0
    603288     18800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190422 ticker: 000651 to sell begin------------
    before cash: 2285936, price: 61.14, sell_vol: 34300
    after cash:4380417
    code
    000858     24400.0
    002044     86400.0
    002304     13500.0
    002311     54900.0
    300253    134700.0
    300365     64600.0
    300498     49500.0
    600085     50000.0
    600406     69100.0
    600519      2000.0
    600887     55800.0
    603288     18800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190422 ticker: 000858 to sell begin------------
    before cash: 4380417, price: 101.13, sell_vol: 24400
    after cash:6844904
    code
    002044     86400.0
    002304     13500.0
    002311     54900.0
    300253    134700.0
    300365     64600.0
    300498     49500.0
    600085     50000.0
    600406     69100.0
    600519      2000.0
    600887     55800.0
    603288     18800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190422 ticker: 002044 to sell begin------------
    before cash: 6844904, price: 17.4, sell_vol: 86400
    after cash:8346385
    code
    002304     13500.0
    002311     54900.0
    300253    134700.0
    300365     64600.0
    300498     49500.0
    600085     50000.0
    600406     69100.0
    600519      2000.0
    600887     55800.0
    603288     18800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190422 ticker: 002304 to sell begin------------
    before cash: 8346385, price: 121.49, sell_vol: 13500
    after cash:9984450
    code
    002311     54900.0
    300253    134700.0
    300365     64600.0
    300498     49500.0
    600085     50000.0
    600406     69100.0
    600519      2000.0
    600887     55800.0
    603288     18800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190422 ticker: 002311 to sell begin------------
    before cash: 9984450, price: 30.68, sell_vol: 54900
    after cash:11666676
    code
    300253    134700.0
    300365     64600.0
    300498     49500.0
    600085     50000.0
    600406     69100.0
    600519      2000.0
    600887     55800.0
    603288     18800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190422 ticker: 300253 to sell begin------------
    before cash: 11666676, price: 13.95, sell_vol: 134700
    after cash:13543393
    code
    300365    64600.0
    300498    49500.0
    600085    50000.0
    600406    69100.0
    600519     2000.0
    600887    55800.0
    603288    18800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190422 ticker: 300365 to sell begin------------
    before cash: 13543393, price: 24.37, sell_vol: 64600
    after cash:15115727
    code
    300498    49500.0
    600085    50000.0
    600406    69100.0
    600519     2000.0
    600887    55800.0
    603288    18800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190422 ticker: 300498 to sell begin------------
    before cash: 15115727, price: 40.71, sell_vol: 49500
    after cash:17128353
    code
    600085    50000.0
    600406    69100.0
    600519     2000.0
    600887    55800.0
    603288    18800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190422 ticker: 600085 to sell begin------------
    before cash: 17128353, price: 32.61, sell_vol: 50000
    after cash:18756815
    code
    600406    69100.0
    600519     2000.0
    600887    55800.0
    603288    18800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190422 ticker: 600406 to sell begin------------
    before cash: 18756815, price: 21.16, sell_vol: 69100
    after cash:20217143
    code
    600519     2000.0
    600887    55800.0
    603288    18800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190422 ticker: 600519 to sell begin------------
    before cash: 20217143, price: 949.2, sell_vol: 2000
    after cash:22113170
    code
    600887    55800.0
    603288    18800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190422 ticker: 600887 to sell begin------------
    before cash: 22113170, price: 30.98, sell_vol: 55800
    after cash:23839693
    code
    603288    18800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190422 ticker: 603288 to sell begin------------
    before cash: 23839693, price: 85.5, sell_vol: 18800
    after cash:25445084
    Series([], Name: amount, dtype: float64)
    at 20190422 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20190423 ticker: 000568 to buy begin--------------
    to_buy:  
    ['000661', '002714', '600406', '601012', '600887', '000568', '600809', '002304', '000858', '002311', '300498', '603899', '000596', '600519']
    before cash: 25445084, price: 72.45, to_buy: 14, buy_vol: 25000
    after cash:23633381
    code
    000568    25000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190423 ticker: 000596 to buy begin--------------
    to_buy:  
    ['000661', '002714', '600406', '601012', '600887', '600809', '002304', '000858', '002311', '300498', '603899', '000596', '600519']
    before cash: 23633381, price: 110.83, to_buy: 13, buy_vol: 16400
    after cash:21815315
    code
    000568    25000.0
    000596    16400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190423 ticker: 000661 to buy begin--------------
    to_buy:  
    ['000661', '002714', '600406', '601012', '600887', '600809', '002304', '000858', '002311', '300498', '603899', '600519']
    before cash: 21815315, price: 299.85, to_buy: 12, buy_vol: 6000
    after cash:20015765
    code
    000568    25000.0
    000596    16400.0
    000661     6000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190423 ticker: 000858 to buy begin--------------
    to_buy:  
    ['002714', '601012', '600406', '600887', '600809', '002304', '000858', '300498', '603899', '600519', '002311']
    before cash: 20015765, price: 104.31, to_buy: 11, buy_vol: 17400
    after cash:18200317
    code
    000568    25000.0
    000596    16400.0
    000661     6000.0
    000858    17400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190423 ticker: 002304 to buy begin--------------
    to_buy:  
    ['002714', '601012', '600406', '600887', '600809', '002304', '300498', '603899', '600519', '002311']
    before cash: 18200317, price: 121.77, to_buy: 10, buy_vol: 14900
    after cash:16385491
    code
    000568    25000.0
    000596    16400.0
    000661     6000.0
    000858    17400.0
    002304    14900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190423 ticker: 002311 to buy begin--------------
    to_buy:  
    ['002714', '601012', '600406', '600887', '600809', '300498', '603899', '600519', '002311']
    before cash: 16385491, price: 30.5, to_buy: 9, buy_vol: 59600
    after cash:14567236
    code
    000568    25000.0
    000596    16400.0
    000661     6000.0
    000858    17400.0
    002304    14900.0
    002311    59600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190423 ticker: 002714 to buy begin--------------
    to_buy:  
    ['002714', '601012', '600406', '600887', '600809', '300498', '603899', '600519']
    before cash: 14567236, price: 66.88, to_buy: 8, buy_vol: 27200
    after cash:12747645
    code
    000568    25000.0
    000596    16400.0
    000661     6000.0
    000858    17400.0
    002304    14900.0
    002311    59600.0
    002714    27200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190423 ticker: 300498 to buy begin--------------
    to_buy:  
    ['601012', '600406', '600887', '600809', '300498', '603899', '600519']
    before cash: 12747645, price: 40.86, to_buy: 7, buy_vol: 44500
    after cash:10928921
    code
    000568    25000.0
    000596    16400.0
    000661     6000.0
    000858    17400.0
    002304    14900.0
    002311    59600.0
    002714    27200.0
    300498    44500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190423 ticker: 600406 to buy begin--------------
    to_buy:  
    ['601012', '600406', '600887', '600809', '603899', '600519']
    before cash: 10928921, price: 21.25, to_buy: 6, buy_vol: 85700
    after cash:9107340
    code
    000568    25000.0
    000596    16400.0
    000661     6000.0
    000858    17400.0
    002304    14900.0
    002311    59600.0
    002714    27200.0
    300498    44500.0
    600406    85700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190423 ticker: 600519 to buy begin--------------
    to_buy:  
    ['601012', '600887', '600809', '603899', '600519']
    before cash: 9107340, price: 974.95, to_buy: 5, buy_vol: 1800
    after cash:7351992
    code
    000568    25000.0
    000596    16400.0
    000661     6000.0
    000858    17400.0
    002304    14900.0
    002311    59600.0
    002714    27200.0
    300498    44500.0
    600406    85700.0
    600519     1800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190423 ticker: 600809 to buy begin--------------
    to_buy:  
    ['600887', '600809', '603899', '601012']
    before cash: 7351992, price: 58.22, to_buy: 4, buy_vol: 31500
    after cash:5517603
    code
    000568    25000.0
    000596    16400.0
    000661     6000.0
    000858    17400.0
    002304    14900.0
    002311    59600.0
    002714    27200.0
    300498    44500.0
    600406    85700.0
    600519     1800.0
    600809    31500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190423 ticker: 600887 to buy begin--------------
    to_buy:  
    ['600887', '603899', '601012']
    before cash: 5517603, price: 30.48, to_buy: 3, buy_vol: 60300
    after cash:3679200
    code
    000568    25000.0
    000596    16400.0
    000661     6000.0
    000858    17400.0
    002304    14900.0
    002311    59600.0
    002714    27200.0
    300498    44500.0
    600406    85700.0
    600519     1800.0
    600809    31500.0
    600887    60300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190423 ticker: 601012 to buy begin--------------
    to_buy:  
    ['603899', '601012']
    before cash: 3679200, price: 23.59, to_buy: 2, buy_vol: 77900
    after cash:1841079
    code
    000568    25000.0
    000596    16400.0
    000661     6000.0
    000858    17400.0
    002304    14900.0
    002311    59600.0
    002714    27200.0
    300498    44500.0
    600406    85700.0
    600519     1800.0
    600809    31500.0
    600887    60300.0
    601012    77900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190423 ticker: 603899 to buy begin--------------
    to_buy:  
    ['603899']
    before cash: 1841079, price: 36.92, to_buy: 1, buy_vol: 49800
    after cash:2004
    code
    000568    25000.0
    000596    16400.0
    000661     6000.0
    000858    17400.0
    002304    14900.0
    002311    59600.0
    002714    27200.0
    300498    44500.0
    600406    85700.0
    600519     1800.0
    600809    31500.0
    600887    60300.0
    601012    77900.0
    603899    49800.0
    Name: amount, dtype: float64
    at 20190423 clear the to_buy list successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2019-05-07  603899      3.0          0.0    0.0       0.0
    分红，增加现金14940.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2019-05-24  000661      8.0          0.0    0.0       0.0
    分红，增加现金4800.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2019-05-31  300498      5.0          0.0    0.0       0.0
    分红，增加现金22250.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2019-06-06  000858     17.0          0.0    0.0       0.0
    分红，增加现金29580.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2019-06-10  601012      1.0          0.0    0.0       0.0
    分红，增加现金7790.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2019-06-21  000596     15.0          0.0    0.0       0.0
    分红，增加现金24600.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2019-06-27  002304     32.0          0.0    0.0       0.0
    分红，增加现金47680.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2019-06-27  002311      3.0          0.0    0.0       0.0
    分红，增加现金17880.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code     fenhong  songzhuangu  peigu  peigujia
    date                                                        
    2019-06-28  600519  145.389999          0.0    0.0       0.0
    分红，增加现金26170.2
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2019-07-04  002714      0.5          0.0    0.0       0.0
    分红，增加现金1360.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20190719 ticker: 000568 to sell begin------------
    before cash: 199054, price: 84.45, sell_vol: 25000
    after cash:2307665
    code
    000596    16400.0
    000661     6000.0
    000858    17400.0
    002304    14900.0
    002311    59600.0
    002714    27200.0
    300498    44500.0
    600406    85700.0
    600519     1800.0
    600809    31500.0
    600887    60300.0
    601012    77900.0
    603899    49800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190719 ticker: 000596 to sell begin------------
    before cash: 2307665, price: 119.65, sell_vol: 16400
    after cash:4267472
    code
    000661     6000.0
    000858    17400.0
    002304    14900.0
    002311    59600.0
    002714    27200.0
    300498    44500.0
    600406    85700.0
    600519     1800.0
    600809    31500.0
    600887    60300.0
    601012    77900.0
    603899    49800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190719 ticker: 000661 to sell begin------------
    before cash: 4267472, price: 326.23, sell_vol: 6000
    after cash:6222405
    code
    000858    17400.0
    002304    14900.0
    002311    59600.0
    002714    27200.0
    300498    44500.0
    600406    85700.0
    600519     1800.0
    600809    31500.0
    600887    60300.0
    601012    77900.0
    603899    49800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190719 ticker: 000858 to sell begin------------
    before cash: 6222405, price: 122.14, sell_vol: 17400
    after cash:8344985
    code
    002304    14900.0
    002311    59600.0
    002714    27200.0
    300498    44500.0
    600406    85700.0
    600519     1800.0
    600809    31500.0
    600887    60300.0
    601012    77900.0
    603899    49800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190719 ticker: 002304 to sell begin------------
    before cash: 8344985, price: 125.98, sell_vol: 14900
    after cash:10219740
    code
    002311    59600.0
    002714    27200.0
    300498    44500.0
    600406    85700.0
    600519     1800.0
    600809    31500.0
    600887    60300.0
    601012    77900.0
    603899    49800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190719 ticker: 002311 to sell begin------------
    before cash: 10219740, price: 28.33, sell_vol: 59600
    after cash:11906098
    code
    002714    27200.0
    300498    44500.0
    600406    85700.0
    600519     1800.0
    600809    31500.0
    600887    60300.0
    601012    77900.0
    603899    49800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190719 ticker: 002714 to sell begin------------
    before cash: 11906098, price: 71.75, sell_vol: 27200
    after cash:13855258
    code
    300498    44500.0
    600406    85700.0
    600519     1800.0
    600809    31500.0
    600887    60300.0
    601012    77900.0
    603899    49800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190719 ticker: 300498 to sell begin------------
    before cash: 13855258, price: 40.85, sell_vol: 44500
    after cash:15670811
    code
    600406    85700.0
    600519     1800.0
    600809    31500.0
    600887    60300.0
    601012    77900.0
    603899    49800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190719 ticker: 600406 to sell begin------------
    before cash: 15670811, price: 18.07, sell_vol: 85700
    after cash:17217474
    code
    600519     1800.0
    600809    31500.0
    600887    60300.0
    601012    77900.0
    603899    49800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190719 ticker: 600519 to sell begin------------
    before cash: 17217474, price: 955.87, sell_vol: 1800
    after cash:18935890
    code
    600809    31500.0
    600887    60300.0
    601012    77900.0
    603899    49800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190719 ticker: 600809 to sell begin------------
    before cash: 18935890, price: 69.49, sell_vol: 31500
    after cash:21122088
    code
    600887    60300.0
    601012    77900.0
    603899    49800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190719 ticker: 600887 to sell begin------------
    before cash: 21122088, price: 32.25, sell_vol: 60300
    after cash:23064333
    code
    601012    77900.0
    603899    49800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190719 ticker: 601012 to sell begin------------
    before cash: 23064333, price: 24.0, sell_vol: 77900
    after cash:24931596
    code
    603899    49800.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20190719 ticker: 603899 to sell begin------------
    before cash: 24931596, price: 39.51, sell_vol: 49800
    after cash:26896734
    Series([], Name: amount, dtype: float64)
    at 20190719 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20190722 ticker: 000568 to buy begin--------------
    to_buy:  
    ['300012', '002371', '002714', '600340', '300590', '600887', '601933', '000568', '600674', '002304', '000858', '300498', '600519']
    before cash: 26896734, price: 85.2, to_buy: 13, buy_vol: 24200
    after cash:24834379
    code
    000568    24200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190722 ticker: 000858 to buy begin--------------
    to_buy:  
    ['300012', '002371', '002714', '600340', '300590', '600887', '601933', '600674', '002304', '000858', '300498', '600519']
    before cash: 24834379, price: 123.45, to_buy: 12, buy_vol: 16700
    after cash:22772248
    code
    000568    24200.0
    000858    16700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190722 ticker: 002304 to buy begin--------------
    to_buy:  
    ['300012', '002371', '002714', '600340', '300590', '600887', '601933', '600674', '002304', '300498', '600519']
    before cash: 22772248, price: 126.02, to_buy: 11, buy_vol: 16400
    after cash:20705003
    code
    000568    24200.0
    000858    16700.0
    002304    16400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190722 ticker: 002371 to buy begin--------------
    to_buy:  
    ['002371', '002714', '600340', '300590', '600887', '601933', '600674', '300498', '600519', '300012']
    before cash: 20705003, price: 63.75, to_buy: 10, buy_vol: 32400
    after cash:18638987
    code
    000568    24200.0
    000858    16700.0
    002304    16400.0
    002371    32400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190722 ticker: 002714 to buy begin--------------
    to_buy:  
    ['300590', '002714', '600340', '600887', '601933', '600674', '300498', '600519', '300012']
    before cash: 18638987, price: 70.65, to_buy: 9, buy_vol: 29300
    after cash:16568425
    code
    000568    24200.0
    000858    16700.0
    002304    16400.0
    002371    32400.0
    002714    29300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190722 ticker: 300012 to buy begin--------------
    to_buy:  
    ['300590', '600340', '600887', '601933', '600674', '300498', '600519', '300012']
    before cash: 16568425, price: 11.2, to_buy: 8, buy_vol: 184900
    after cash:14497027
    code
    000568     24200.0
    000858     16700.0
    002304     16400.0
    002371     32400.0
    002714     29300.0
    300012    184900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190722 ticker: 300498 to buy begin--------------
    to_buy:  
    ['300590', '600340', '600887', '601933', '600674', '300498', '600519']
    before cash: 14497027, price: 39.91, to_buy: 7, buy_vol: 51800
    after cash:12429172
    code
    000568     24200.0
    000858     16700.0
    002304     16400.0
    002371     32400.0
    002714     29300.0
    300012    184900.0
    300498     51800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190722 ticker: 300590 to buy begin--------------
    to_buy:  
    ['300590', '600340', '600887', '601933', '600674', '600519']
    before cash: 12429172, price: 29.89, to_buy: 6, buy_vol: 69300
    after cash:10357277
    code
    000568     24200.0
    000858     16700.0
    002304     16400.0
    002371     32400.0
    002714     29300.0
    300012    184900.0
    300498     51800.0
    300590     69300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190722 ticker: 600340 to buy begin--------------
    to_buy:  
    ['600340', '600887', '601933', '600674', '600519']
    before cash: 10357277, price: 30.67, to_buy: 5, buy_vol: 67500
    after cash:8286535
    code
    000568     24200.0
    000858     16700.0
    002304     16400.0
    002371     32400.0
    002714     29300.0
    300012    184900.0
    300498     51800.0
    300590     69300.0
    600340     67500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190722 ticker: 600519 to buy begin--------------
    to_buy:  
    ['600887', '601933', '600519', '600674']
    before cash: 8286535, price: 957.02, to_buy: 4, buy_vol: 2100
    after cash:6276290
    code
    000568     24200.0
    000858     16700.0
    002304     16400.0
    002371     32400.0
    002714     29300.0
    300012    184900.0
    300498     51800.0
    300590     69300.0
    600340     67500.0
    600519      2100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190722 ticker: 600674 to buy begin--------------
    to_buy:  
    ['600887', '601933', '600674']
    before cash: 6276290, price: 8.79, to_buy: 3, buy_vol: 238000
    after cash:4183747
    code
    000568     24200.0
    000858     16700.0
    002304     16400.0
    002371     32400.0
    002714     29300.0
    300012    184900.0
    300498     51800.0
    300590     69300.0
    600340     67500.0
    600519      2100.0
    600674    238000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190722 ticker: 600887 to buy begin--------------
    to_buy:  
    ['600887', '601933']
    before cash: 4183747, price: 32.26, to_buy: 2, buy_vol: 64800
    after cash:2092777
    code
    000568     24200.0
    000858     16700.0
    002304     16400.0
    002371     32400.0
    002714     29300.0
    300012    184900.0
    300498     51800.0
    300590     69300.0
    600340     67500.0
    600519      2100.0
    600674    238000.0
    600887     64800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20190722 ticker: 601933 to buy begin--------------
    to_buy:  
    ['601933']
    before cash: 2092777, price: 9.44, to_buy: 1, buy_vol: 221600
    after cash:350
    code
    000568     24200.0
    000858     16700.0
    002304     16400.0
    002371     32400.0
    002714     29300.0
    300012    184900.0
    300498     51800.0
    300590     69300.0
    600340     67500.0
    600519      2100.0
    600674    238000.0
    600887     64800.0
    601933    221600.0
    Name: amount, dtype: float64
    at 20190722 clear the to_buy list successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2019-08-22  000568     15.5          0.0    0.0       0.0
    分红，增加现金37510.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2019-10-11  300498      3.0          0.0    0.0       0.0
    分红，增加现金15540.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20191025 ticker: 000568 to sell begin------------
    before cash: 53400, price: 83.0, sell_vol: 24200
    after cash:2059489
    code
    000858     16700.0
    002304     16400.0
    002371     32400.0
    002714     29300.0
    300012    184900.0
    300498     51800.0
    300590     69300.0
    600340     67500.0
    600519      2100.0
    600674    238000.0
    600887     64800.0
    601933    221600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20191025 ticker: 000858 to sell begin------------
    before cash: 2059489, price: 128.2, sell_vol: 16700
    after cash:4197753
    code
    002304     16400.0
    002371     32400.0
    002714     29300.0
    300012    184900.0
    300498     51800.0
    300590     69300.0
    600340     67500.0
    600519      2100.0
    600674    238000.0
    600887     64800.0
    601933    221600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20191025 ticker: 002304 to sell begin------------
    before cash: 4197753, price: 101.76, sell_vol: 16400
    after cash:5864531
    code
    002371     32400.0
    002714     29300.0
    300012    184900.0
    300498     51800.0
    300590     69300.0
    600340     67500.0
    600519      2100.0
    600674    238000.0
    600887     64800.0
    601933    221600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20191025 ticker: 002371 to sell begin------------
    before cash: 5864531, price: 64.85, sell_vol: 32400
    after cash:7963044
    code
    002714     29300.0
    300012    184900.0
    300498     51800.0
    300590     69300.0
    600340     67500.0
    600519      2100.0
    600674    238000.0
    600887     64800.0
    601933    221600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20191025 ticker: 002714 to sell begin------------
    before cash: 7963044, price: 99.73, sell_vol: 29300
    after cash:10881481
    code
    300012    184900.0
    300498     51800.0
    300590     69300.0
    600340     67500.0
    600519      2100.0
    600674    238000.0
    600887     64800.0
    601933    221600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20191025 ticker: 300012 to sell begin------------
    before cash: 10881481, price: 14.19, sell_vol: 184900
    after cash:13501932
    code
    300498     51800.0
    300590     69300.0
    600340     67500.0
    600519      2100.0
    600674    238000.0
    600887     64800.0
    601933    221600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20191025 ticker: 300498 to sell begin------------
    before cash: 13501932, price: 41.03, sell_vol: 51800
    after cash:15624629
    code
    300590     69300.0
    600340     67500.0
    600519      2100.0
    600674    238000.0
    600887     64800.0
    601933    221600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20191025 ticker: 300590 to sell begin------------
    before cash: 15624629, price: 31.2, sell_vol: 69300
    after cash:17784087
    code
    600340     67500.0
    600519      2100.0
    600674    238000.0
    600887     64800.0
    601933    221600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20191025 ticker: 600340 to sell begin------------
    before cash: 17784087, price: 29.9, sell_vol: 67500
    after cash:19799814
    code
    600519      2100.0
    600674    238000.0
    600887     64800.0
    601933    221600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20191025 ticker: 600519 to sell begin------------
    before cash: 19799814, price: 1171.35, sell_vol: 2100
    after cash:22256574
    code
    600674    238000.0
    600887     64800.0
    601933    221600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20191025 ticker: 600674 to sell begin------------
    before cash: 22256574, price: 9.7, sell_vol: 238000
    after cash:24562288
    code
    600887     64800.0
    601933    221600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20191025 ticker: 600887 to sell begin------------
    before cash: 24562288, price: 27.37, sell_vol: 64800
    after cash:26333647
    code
    601933    221600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20191025 ticker: 601933 to sell begin------------
    before cash: 26333647, price: 8.37, sell_vol: 221600
    after cash:28186121
    Series([], Name: amount, dtype: float64)
    at 20191025 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20191028 ticker: 000568 to buy begin--------------
    to_buy:  
    ['300012', '000661', '002714', '002241', '300601', '600763', '000568', '600276', '000858', '300498', '603986', '300347', '603882', '300661', '600519']
    before cash: 28186121, price: 84.88, to_buy: 15, buy_vol: 22100
    after cash:26309804
    code
    000568    22100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20191028 ticker: 000661 to buy begin--------------
    to_buy:  
    ['300012', '000661', '002714', '002241', '300601', '600763', '600276', '000858', '300498', '603986', '300347', '603882', '300661', '600519']
    before cash: 26309804, price: 436.18, to_buy: 14, buy_vol: 4300
    after cash:24433761
    code
    000568    22100.0
    000661     4300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20191028 ticker: 000858 to buy begin--------------
    to_buy:  
    ['300012', '002714', '002241', '300601', '600763', '600276', '000858', '300498', '603986', '300347', '603882', '300661', '600519']
    before cash: 24433761, price: 130.05, to_buy: 13, buy_vol: 14400
    after cash:22560573
    code
    000568    22100.0
    000661     4300.0
    000858    14400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20191028 ticker: 002241 to buy begin--------------
    to_buy:  
    ['002714', '002241', '300601', '600763', '600276', '600519', '300498', '603986', '300347', '603882', '300661', '300012']
    before cash: 22560573, price: 18.23, to_buy: 12, buy_vol: 103100
    after cash:20680590
    code
    000568     22100.0
    000661      4300.0
    000858     14400.0
    002241    103100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20191028 ticker: 002714 to buy begin--------------
    to_buy:  
    ['002714', '300601', '600763', '600276', '600519', '300498', '603986', '300347', '603882', '300661', '300012']
    before cash: 20680590, price: 99.78, to_buy: 11, buy_vol: 18800
    after cash:18804257
    code
    000568     22100.0
    000661      4300.0
    000858     14400.0
    002241    103100.0
    002714     18800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20191028 ticker: 300012 to buy begin--------------
    to_buy:  
    ['300601', '600763', '600276', '600519', '300498', '603986', '300347', '603882', '300661', '300012']
    before cash: 18804257, price: 14.03, to_buy: 10, buy_vol: 134000
    after cash:16923767
    code
    000568     22100.0
    000661      4300.0
    000858     14400.0
    002241    103100.0
    002714     18800.0
    300012    134000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20191028 ticker: 300347 to buy begin--------------
    to_buy:  
    ['300601', '600763', '600276', '300498', '603986', '300347', '603882', '300661', '600519']
    before cash: 16923767, price: 65.75, to_buy: 9, buy_vol: 28500
    after cash:15049423
    code
    000568     22100.0
    000661      4300.0
    000858     14400.0
    002241    103100.0
    002714     18800.0
    300012    134000.0
    300347     28500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20191028 ticker: 300498 to buy begin--------------
    to_buy:  
    ['300601', '600763', '600276', '300498', '603986', '603882', '300661', '600519']
    before cash: 15049423, price: 40.57, to_buy: 8, buy_vol: 46300
    after cash:13170563
    code
    000568     22100.0
    000661      4300.0
    000858     14400.0
    002241    103100.0
    002714     18800.0
    300012    134000.0
    300347     28500.0
    300498     46300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20191028 ticker: 300601 to buy begin--------------
    to_buy:  
    ['300601', '600763', '600276', '603986', '603882', '300661', '600519']
    before cash: 13170563, price: 82.51, to_buy: 7, buy_vol: 22800
    after cash:11288864
    code
    000568     22100.0
    000661      4300.0
    000858     14400.0
    002241    103100.0
    002714     18800.0
    300012    134000.0
    300347     28500.0
    300498     46300.0
    300601     22800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20191028 ticker: 300661 to buy begin--------------
    to_buy:  
    ['600763', '600276', '603986', '603882', '300661', '600519']
    before cash: 11288864, price: 191.1, to_buy: 6, buy_vol: 9800
    after cash:9415616
    code
    000568     22100.0
    000661      4300.0
    000858     14400.0
    002241    103100.0
    002714     18800.0
    300012    134000.0
    300347     28500.0
    300498     46300.0
    300601     22800.0
    300661      9800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20191028 ticker: 600276 to buy begin--------------
    to_buy:  
    ['600763', '600276', '603986', '603882', '600519']
    before cash: 9415616, price: 91.08, to_buy: 5, buy_vol: 20600
    after cash:7538899
    code
    000568     22100.0
    000661      4300.0
    000858     14400.0
    002241    103100.0
    002714     18800.0
    300012    134000.0
    300347     28500.0
    300498     46300.0
    300601     22800.0
    300661      9800.0
    600276     20600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20191028 ticker: 600519 to buy begin--------------
    to_buy:  
    ['600763', '603986', '603882', '600519']
    before cash: 7538899, price: 1178.29, to_buy: 4, buy_vol: 1500
    after cash:5771022
    code
    000568     22100.0
    000661      4300.0
    000858     14400.0
    002241    103100.0
    002714     18800.0
    300012    134000.0
    300347     28500.0
    300498     46300.0
    300601     22800.0
    300661      9800.0
    600276     20600.0
    600519      1500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20191028 ticker: 600763 to buy begin--------------
    to_buy:  
    ['600763', '603986', '603882']
    before cash: 5771022, price: 111.18, to_buy: 3, buy_vol: 17300
    after cash:3847127
    code
    000568     22100.0
    000661      4300.0
    000858     14400.0
    002241    103100.0
    002714     18800.0
    300012    134000.0
    300347     28500.0
    300498     46300.0
    300601     22800.0
    300661      9800.0
    600276     20600.0
    600519      1500.0
    600763     17300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20191028 ticker: 603882 to buy begin--------------
    to_buy:  
    ['603986', '603882']
    before cash: 3847127, price: 53.15, to_buy: 2, buy_vol: 36100
    after cash:1927933
    code
    000568     22100.0
    000661      4300.0
    000858     14400.0
    002241    103100.0
    002714     18800.0
    300012    134000.0
    300347     28500.0
    300498     46300.0
    300601     22800.0
    300661      9800.0
    600276     20600.0
    600519      1500.0
    600763     17300.0
    603882     36100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20191028 ticker: 603986 to buy begin--------------
    to_buy:  
    ['603986']
    before cash: 1927933, price: 149.26, to_buy: 1, buy_vol: 12900
    after cash:1997
    code
    000568     22100.0
    000661      4300.0
    000858     14400.0
    002241    103100.0
    002714     18800.0
    300012    134000.0
    300347     28500.0
    300498     46300.0
    300601     22800.0
    300661      9800.0
    600276     20600.0
    600519      1500.0
    600763     17300.0
    603882     36100.0
    603986     12900.0
    Name: amount, dtype: float64
    at 20191028 clear the to_buy list successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20200121 ticker: 000568 to sell begin------------
    before cash: 1997, price: 87.26, sell_vol: 22100
    after cash:1928033
    code
    000661      4300.0
    000858     14400.0
    002241    103100.0
    002714     18800.0
    300012    134000.0
    300347     28500.0
    300498     46300.0
    300601     22800.0
    300661      9800.0
    600276     20600.0
    600519      1500.0
    600763     17300.0
    603882     36100.0
    603986     12900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200121 ticker: 000661 to sell begin------------
    before cash: 1928033, price: 511.7, sell_vol: 4300
    after cash:4125592
    code
    000858     14400.0
    002241    103100.0
    002714     18800.0
    300012    134000.0
    300347     28500.0
    300498     46300.0
    300601     22800.0
    300661      9800.0
    600276     20600.0
    600519      1500.0
    600763     17300.0
    603882     36100.0
    603986     12900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200121 ticker: 000858 to sell begin------------
    before cash: 4125592, price: 132.62, sell_vol: 14400
    after cash:6032933
    code
    002241    103100.0
    002714     18800.0
    300012    134000.0
    300347     28500.0
    300498     46300.0
    300601     22800.0
    300661      9800.0
    600276     20600.0
    600519      1500.0
    600763     17300.0
    603882     36100.0
    603986     12900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200121 ticker: 002241 to sell begin------------
    before cash: 6032933, price: 22.99, sell_vol: 103100
    after cash:8400239
    code
    002714     18800.0
    300012    134000.0
    300347     28500.0
    300498     46300.0
    300601     22800.0
    300661      9800.0
    600276     20600.0
    600519      1500.0
    600763     17300.0
    603882     36100.0
    603986     12900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200121 ticker: 002714 to sell begin------------
    before cash: 8400239, price: 88.5, sell_vol: 18800
    after cash:10061960
    code
    300012    134000.0
    300347     28500.0
    300498     46300.0
    300601     22800.0
    300661      9800.0
    600276     20600.0
    600519      1500.0
    600763     17300.0
    603882     36100.0
    603986     12900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200121 ticker: 300012 to sell begin------------
    before cash: 10061960, price: 16.3, sell_vol: 134000
    after cash:12243429
    code
    300347    28500.0
    300498    46300.0
    300601    22800.0
    300661     9800.0
    600276    20600.0
    600519     1500.0
    600763    17300.0
    603882    36100.0
    603986    12900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200121 ticker: 300347 to sell begin------------
    before cash: 12243429, price: 74.98, sell_vol: 28500
    after cash:14377688
    code
    300498    46300.0
    300601    22800.0
    300661     9800.0
    600276    20600.0
    600519     1500.0
    600763    17300.0
    603882    36100.0
    603986    12900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200121 ticker: 300498 to sell begin------------
    before cash: 14377688, price: 35.72, sell_vol: 46300
    after cash:16029457
    code
    300601    22800.0
    300661     9800.0
    600276    20600.0
    600519     1500.0
    600763    17300.0
    603882    36100.0
    603986    12900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200121 ticker: 300601 to sell begin------------
    before cash: 16029457, price: 102.3, sell_vol: 22800
    after cash:18358981
    code
    300661     9800.0
    600276    20600.0
    600519     1500.0
    600763    17300.0
    603882    36100.0
    603986    12900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200121 ticker: 300661 to sell begin------------
    before cash: 18358981, price: 282.3, sell_vol: 9800
    after cash:21122063
    code
    600276    20600.0
    600519     1500.0
    600763    17300.0
    603882    36100.0
    603986    12900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200121 ticker: 600276 to sell begin------------
    before cash: 21122063, price: 90.37, sell_vol: 20600
    after cash:22981358
    code
    600519     1500.0
    600763    17300.0
    603882    36100.0
    603986    12900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200121 ticker: 600519 to sell begin------------
    before cash: 22981358, price: 1075.3, sell_vol: 1500
    after cash:24592292
    code
    600763    17300.0
    603882    36100.0
    603986    12900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200121 ticker: 600763 to sell begin------------
    before cash: 24592292, price: 106.67, sell_vol: 17300
    after cash:26435376
    code
    603882    36100.0
    603986    12900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200121 ticker: 603882 to sell begin------------
    before cash: 26435376, price: 61.95, sell_vol: 36100
    after cash:28668976
    code
    603986    12900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200121 ticker: 603986 to sell begin------------
    before cash: 28668976, price: 271.42, sell_vol: 12900
    after cash:32165917
    Series([], Name: amount, dtype: float64)
    at 20200121 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20200122 ticker: 000568 to buy begin--------------
    to_buy:  
    ['002714', '300601', '300014', '000568', '000860', '300661', '300012', '000661', '603259', '600536', '600276', '000858', '300498', '600031', '600703', '600519']
    before cash: 32165917, price: 87.51, to_buy: 16, buy_vol: 22900
    after cash:30161437
    code
    000568    22900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200122 ticker: 000661 to buy begin--------------
    to_buy:  
    ['002714', '300601', '300014', '000860', '300661', '300012', '000661', '603259', '600536', '600276', '000858', '300498', '600031', '600703', '600519']
    before cash: 30161437, price: 517.0, to_buy: 15, buy_vol: 3800
    after cash:28196346
    code
    000568    22900.0
    000661     3800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200122 ticker: 000858 to buy begin--------------
    to_buy:  
    ['002714', '300601', '300014', '000860', '300661', '300012', '603259', '600536', '600276', '000858', '300498', '600031', '600703', '600519']
    before cash: 28196346, price: 131.7, to_buy: 14, buy_vol: 15200
    after cash:26194006
    code
    000568    22900.0
    000661     3800.0
    000858    15200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200122 ticker: 000860 to buy begin--------------
    to_buy:  
    ['002714', '300601', '300014', '000860', '300661', '300012', '603259', '600536', '600276', '300498', '600031', '600703', '600519']
    before cash: 26194006, price: 53.42, to_buy: 13, buy_vol: 37700
    after cash:24179568
    code
    000568    22900.0
    000661     3800.0
    000858    15200.0
    000860    37700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200122 ticker: 002714 to buy begin--------------
    to_buy:  
    ['002714', '300601', '300014', '600703', '603259', '600536', '600276', '300498', '600031', '600519', '300661', '300012']
    before cash: 24179568, price: 86.05, to_buy: 12, buy_vol: 23400
    after cash:22165495
    code
    000568    22900.0
    000661     3800.0
    000858    15200.0
    000860    37700.0
    002714    23400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200122 ticker: 300012 to buy begin--------------
    to_buy:  
    ['300601', '300014', '600703', '603259', '600536', '600276', '300498', '600031', '600519', '300661', '300012']
    before cash: 22165495, price: 16.25, to_buy: 11, buy_vol: 124000
    after cash:20149991
    code
    000568     22900.0
    000661      3800.0
    000858     15200.0
    000860     37700.0
    002714     23400.0
    300012    124000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200122 ticker: 300014 to buy begin--------------
    to_buy:  
    ['300601', '300014', '600703', '600536', '603259', '600276', '300498', '600031', '300661', '600519']
    before cash: 20149991, price: 62.7, to_buy: 10, buy_vol: 32100
    after cash:18136818
    code
    000568     22900.0
    000661      3800.0
    000858     15200.0
    000860     37700.0
    002714     23400.0
    300012    124000.0
    300014     32100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200122 ticker: 300498 to buy begin--------------
    to_buy:  
    ['300601', '600703', '600536', '603259', '600276', '300498', '600031', '300661', '600519']
    before cash: 18136818, price: 34.42, to_buy: 9, buy_vol: 58500
    after cash:16122744
    code
    000568     22900.0
    000661      3800.0
    000858     15200.0
    000860     37700.0
    002714     23400.0
    300012    124000.0
    300014     32100.0
    300498     58500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200122 ticker: 300601 to buy begin--------------
    to_buy:  
    ['300601', '600703', '600536', '603259', '600276', '600031', '300661', '600519']
    before cash: 16122744, price: 101.95, to_buy: 8, buy_vol: 19700
    after cash:14113827
    code
    000568     22900.0
    000661      3800.0
    000858     15200.0
    000860     37700.0
    002714     23400.0
    300012    124000.0
    300014     32100.0
    300498     58500.0
    300601     19700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200122 ticker: 300661 to buy begin--------------
    to_buy:  
    ['600703', '600536', '603259', '600276', '600031', '300661', '600519']
    before cash: 14113827, price: 291.18, to_buy: 7, buy_vol: 6900
    after cash:12104183
    code
    000568     22900.0
    000661      3800.0
    000858     15200.0
    000860     37700.0
    002714     23400.0
    300012    124000.0
    300014     32100.0
    300498     58500.0
    300601     19700.0
    300661      6900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200122 ticker: 600031 to buy begin--------------
    to_buy:  
    ['600536', '603259', '600276', '600031', '600703', '600519']
    before cash: 12104183, price: 16.9, to_buy: 6, buy_vol: 119300
    after cash:10087509
    code
    000568     22900.0
    000661      3800.0
    000858     15200.0
    000860     37700.0
    002714     23400.0
    300012    124000.0
    300014     32100.0
    300498     58500.0
    300601     19700.0
    300661      6900.0
    600031    119300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200122 ticker: 600276 to buy begin--------------
    to_buy:  
    ['600536', '603259', '600276', '600703', '600519']
    before cash: 10087509, price: 90.33, to_buy: 5, buy_vol: 22300
    after cash:8072646
    code
    000568     22900.0
    000661      3800.0
    000858     15200.0
    000860     37700.0
    002714     23400.0
    300012    124000.0
    300014     32100.0
    300498     58500.0
    300601     19700.0
    300661      6900.0
    600031    119300.0
    600276     22300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200122 ticker: 600519 to buy begin--------------
    to_buy:  
    ['600536', '603259', '600703', '600519']
    before cash: 8072646, price: 1075.51, to_buy: 4, buy_vol: 1800
    after cash:6136244
    code
    000568     22900.0
    000661      3800.0
    000858     15200.0
    000860     37700.0
    002714     23400.0
    300012    124000.0
    300014     32100.0
    300498     58500.0
    300601     19700.0
    300661      6900.0
    600031    119300.0
    600276     22300.0
    600519      1800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200122 ticker: 600536 to buy begin--------------
    to_buy:  
    ['600536', '603259', '600703']
    before cash: 6136244, price: 77.73, to_buy: 3, buy_vol: 26300
    after cash:4091434
    code
    000568     22900.0
    000661      3800.0
    000858     15200.0
    000860     37700.0
    002714     23400.0
    300012    124000.0
    300014     32100.0
    300498     58500.0
    300601     19700.0
    300661      6900.0
    600031    119300.0
    600276     22300.0
    600519      1800.0
    600536     26300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200122 ticker: 600703 to buy begin--------------
    to_buy:  
    ['603259', '600703']
    before cash: 4091434, price: 23.29, to_buy: 2, buy_vol: 87800
    after cash:2046061
    code
    000568     22900.0
    000661      3800.0
    000858     15200.0
    000860     37700.0
    002714     23400.0
    300012    124000.0
    300014     32100.0
    300498     58500.0
    300601     19700.0
    300661      6900.0
    600031    119300.0
    600276     22300.0
    600519      1800.0
    600536     26300.0
    600703     87800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200122 ticker: 603259 to buy begin--------------
    to_buy:  
    ['603259']
    before cash: 2046061, price: 98.75, to_buy: 1, buy_vol: 20700
    after cash:1425
    code
    000568     22900.0
    000661      3800.0
    000858     15200.0
    000860     37700.0
    002714     23400.0
    300012    124000.0
    300014     32100.0
    300498     58500.0
    300601     19700.0
    300661      6900.0
    600031    119300.0
    600276     22300.0
    600519      1800.0
    600536     26300.0
    600703     87800.0
    603259     20700.0
    Name: amount, dtype: float64
    at 20200122 clear the to_buy list successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20200422 ticker: 000568 to sell begin------------
    before cash: 1425, price: 77.28, sell_vol: 22900
    after cash:1768925
    code
    000661      3800.0
    000858     15200.0
    000860     37700.0
    002714     23400.0
    300012    124000.0
    300014     32100.0
    300498     58500.0
    300601     19700.0
    300661      6900.0
    600031    119300.0
    600276     22300.0
    600519      1800.0
    600536     26300.0
    600703     87800.0
    603259     20700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200422 ticker: 000661 to sell begin------------
    before cash: 1768925, price: 588.6, sell_vol: 3800
    after cash:4002809
    code
    000858     15200.0
    000860     37700.0
    002714     23400.0
    300012    124000.0
    300014     32100.0
    300498     58500.0
    300601     19700.0
    300661      6900.0
    600031    119300.0
    600276     22300.0
    600519      1800.0
    600536     26300.0
    600703     87800.0
    603259     20700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200422 ticker: 000858 to sell begin------------
    before cash: 4002809, price: 130.3, sell_vol: 15200
    after cash:5980893
    code
    000860     37700.0
    002714     23400.0
    300012    124000.0
    300014     32100.0
    300498     58500.0
    300601     19700.0
    300661      6900.0
    600031    119300.0
    600276     22300.0
    600519      1800.0
    600536     26300.0
    600703     87800.0
    603259     20700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200422 ticker: 000860 to sell begin------------
    before cash: 5980893, price: 62.15, sell_vol: 37700
    after cash:8321020
    code
    002714     23400.0
    300012    124000.0
    300014     32100.0
    300498     58500.0
    300601     19700.0
    300661      6900.0
    600031    119300.0
    600276     22300.0
    600519      1800.0
    600536     26300.0
    600703     87800.0
    603259     20700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200422 ticker: 002714 to sell begin------------
    before cash: 8321020, price: 126.46, sell_vol: 23400
    after cash:11276485
    code
    300012    124000.0
    300014     32100.0
    300498     58500.0
    300601     19700.0
    300661      6900.0
    600031    119300.0
    600276     22300.0
    600519      1800.0
    600536     26300.0
    600703     87800.0
    603259     20700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200422 ticker: 300012 to sell begin------------
    before cash: 11276485, price: 16.68, sell_vol: 124000
    after cash:13342219
    code
    300014     32100.0
    300498     58500.0
    300601     19700.0
    300661      6900.0
    600031    119300.0
    600276     22300.0
    600519      1800.0
    600536     26300.0
    600703     87800.0
    603259     20700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200422 ticker: 300014 to sell begin------------
    before cash: 13342219, price: 63.94, sell_vol: 32100
    after cash:15392128
    code
    300498     58500.0
    300601     19700.0
    300661      6900.0
    600031    119300.0
    600276     22300.0
    600519      1800.0
    600536     26300.0
    600703     87800.0
    603259     20700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200422 ticker: 300498 to sell begin------------
    before cash: 15392128, price: 30.88, sell_vol: 58500
    after cash:17196350
    code
    300601     19700.0
    300661      6900.0
    600031    119300.0
    600276     22300.0
    600519      1800.0
    600536     26300.0
    600703     87800.0
    603259     20700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200422 ticker: 300601 to sell begin------------
    before cash: 17196350, price: 131.6, sell_vol: 19700
    after cash:19785629
    code
    300661      6900.0
    600031    119300.0
    600276     22300.0
    600519      1800.0
    600536     26300.0
    600703     87800.0
    603259     20700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200422 ticker: 300661 to sell begin------------
    before cash: 19785629, price: 290.7, sell_vol: 6900
    after cash:21788952
    code
    600031    119300.0
    600276     22300.0
    600519      1800.0
    600536     26300.0
    600703     87800.0
    603259     20700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200422 ticker: 600031 to sell begin------------
    before cash: 21788952, price: 19.5, sell_vol: 119300
    after cash:24112394
    code
    600276    22300.0
    600519     1800.0
    600536    26300.0
    600703    87800.0
    603259    20700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200422 ticker: 600276 to sell begin------------
    before cash: 24112394, price: 97.5, sell_vol: 22300
    after cash:26283926
    code
    600519     1800.0
    600536    26300.0
    600703    87800.0
    603259    20700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200422 ticker: 600519 to sell begin------------
    before cash: 26283926, price: 1244.5, sell_vol: 1800
    after cash:28521226
    code
    600536    26300.0
    600703    87800.0
    603259    20700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200422 ticker: 600536 to sell begin------------
    before cash: 28521226, price: 84.88, sell_vol: 26300
    after cash:30750779
    code
    600703    87800.0
    603259    20700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200422 ticker: 600703 to sell begin------------
    before cash: 30750779, price: 20.64, sell_vol: 87800
    after cash:32560706
    code
    603259    20700.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200422 ticker: 603259 to sell begin------------
    before cash: 32560706, price: 105.15, sell_vol: 20700
    after cash:34734590
    Series([], Name: amount, dtype: float64)
    at 20200422 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20200423 ticker: 000661 to buy begin--------------
    to_buy:  
    ['000977', '000661', '300529', '300699', '002555', '600276', '600529', '000739', '300015', '603019', '002385', '300760', '300003']
    before cash: 34734590, price: 584.96, to_buy: 13, buy_vol: 4500
    after cash:32101612
    code
    000661    4500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200423 ticker: 000739 to buy begin--------------
    to_buy:  
    ['000977', '300529', '300699', '002555', '600276', '600529', '000739', '300015', '603019', '002385', '300760', '300003']
    before cash: 32101612, price: 18.11, to_buy: 12, buy_vol: 147700
    after cash:29426097
    code
    000661      4500.0
    000739    147700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200423 ticker: 000977 to buy begin--------------
    to_buy:  
    ['000977', '300529', '300699', '002555', '600276', '600529', '300015', '603019', '002385', '300760', '300003']
    before cash: 29426097, price: 39.26, to_buy: 11, buy_vol: 68100
    after cash:26751822
    code
    000661      4500.0
    000739    147700.0
    000977     68100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200423 ticker: 002385 to buy begin--------------
    to_buy:  
    ['300529', '300699', '002555', '600276', '600529', '300015', '603019', '002385', '300760', '300003']
    before cash: 26751822, price: 9.2, to_buy: 10, buy_vol: 290700
    after cash:24076713
    code
    000661      4500.0
    000739    147700.0
    000977     68100.0
    002385    290700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200423 ticker: 002555 to buy begin--------------
    to_buy:  
    ['300529', '300699', '002555', '600276', '600529', '300015', '603019', '300760', '300003']
    before cash: 24076713, price: 35.81, to_buy: 9, buy_vol: 74700
    after cash:21401038
    code
    000661      4500.0
    000739    147700.0
    000977     68100.0
    002385    290700.0
    002555     74700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200423 ticker: 300003 to buy begin--------------
    to_buy:  
    ['300529', '300699', '600276', '600529', '300015', '603019', '300760', '300003']
    before cash: 21401038, price: 40.57, to_buy: 8, buy_vol: 65900
    after cash:18726806
    code
    000661      4500.0
    000739    147700.0
    000977     68100.0
    002385    290700.0
    002555     74700.0
    300003     65900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200423 ticker: 300529 to buy begin--------------
    to_buy:  
    ['300529', '300699', '600276', '600529', '300015', '603019', '300760']
    before cash: 18726806, price: 115.02, to_buy: 7, buy_vol: 23200
    after cash:16057675
    code
    000661      4500.0
    000739    147700.0
    000977     68100.0
    002385    290700.0
    002555     74700.0
    300003     65900.0
    300529     23200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200423 ticker: 300699 to buy begin--------------
    to_buy:  
    ['300699', '600276', '600529', '300015', '603019', '300760']
    before cash: 16057675, price: 52.03, to_buy: 6, buy_vol: 51400
    after cash:13382665
    code
    000661      4500.0
    000739    147700.0
    000977     68100.0
    002385    290700.0
    002555     74700.0
    300003     65900.0
    300529     23200.0
    300699     51400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200423 ticker: 300760 to buy begin--------------
    to_buy:  
    ['600276', '600529', '300015', '603019', '300760']
    before cash: 13382665, price: 270.52, to_buy: 5, buy_vol: 9800
    after cash:10730906
    code
    000661      4500.0
    000739    147700.0
    000977     68100.0
    002385    290700.0
    002555     74700.0
    300003     65900.0
    300529     23200.0
    300699     51400.0
    300760      9800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200423 ticker: 600276 to buy begin--------------
    to_buy:  
    ['603019', '300015', '600276', '600529']
    before cash: 10730906, price: 96.05, to_buy: 4, buy_vol: 27900
    after cash:8050441
    code
    000661      4500.0
    000739    147700.0
    000977     68100.0
    002385    290700.0
    002555     74700.0
    300003     65900.0
    300529     23200.0
    300699     51400.0
    300760      9800.0
    600276     27900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200423 ticker: 600529 to buy begin--------------
    to_buy:  
    ['300015', '603019', '600529']
    before cash: 8050441, price: 36.18, to_buy: 3, buy_vol: 74100
    after cash:5368833
    code
    000661      4500.0
    000739    147700.0
    000977     68100.0
    002385    290700.0
    002555     74700.0
    300003     65900.0
    300529     23200.0
    300699     51400.0
    300760      9800.0
    600276     27900.0
    600529     74100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200423 ticker: 603019 to buy begin--------------
    to_buy:  
    ['300015', '603019']
    before cash: 5368833, price: 46.0, to_buy: 2, buy_vol: 58300
    after cash:2686362
    code
    000661      4500.0
    000739    147700.0
    000977     68100.0
    002385    290700.0
    002555     74700.0
    300003     65900.0
    300529     23200.0
    300699     51400.0
    300760      9800.0
    600276     27900.0
    600529     74100.0
    603019     58300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2020-05-08  603019      1.4          4.0    0.0       0.0
    分红，增加现金8162.0
    转增股，增加股票23300.0股603019
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2020-05-11  002555      3.0          0.0    0.0       0.0
    分红，增加现金22410.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2020-05-14  300699      5.0          0.0    0.0       0.0
    分红，增加现金25700.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2020-05-15  300760     15.0          0.0    0.0       0.0
    分红，增加现金14700.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2020-05-19  000739     1.65          0.0    0.0       0.0
    分红，增加现金24370.5
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2020-05-20  000977      0.7          0.0    0.0       0.0
    分红，增加现金4767.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2020-05-20  300529      9.0          9.0    0.0       0.0
    分红，增加现金20880.0
    转增股，增加股票20800.0股300529
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2020-05-25  600276      2.3          2.0    0.0       0.0
    分红，增加现金6417.0
    转增股，增加股票5500.0股600276
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2020-05-26  002385      2.3          0.0    0.0       0.0
    分红，增加现金66861.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2020-06-09  000661     10.0         10.0    0.0       0.0
    分红，增加现金4500.0
    转增股，增加股票4500.0股000661
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2020-06-16  300003      2.0          0.0    0.0       0.0
    分红，增加现金13180.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2020-07-07  600529      3.0          0.0    0.0       0.0
    分红，增加现金22230.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20200721 ticker: 000661 to sell begin------------
    before cash: 2920520, price: 479.26, sell_vol: 9000
    after cash:7228468
    code
    000739    147700.0
    000977     68100.0
    002385    290700.0
    002555     74700.0
    300003     65900.0
    300529     44000.0
    300699     51400.0
    300760      9800.0
    600276     33400.0
    600529     74100.0
    603019     81600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200721 ticker: 000739 to sell begin------------
    before cash: 7228468, price: 24.0, sell_vol: 147700
    after cash:10768837
    code
    000977     68100.0
    002385    290700.0
    002555     74700.0
    300003     65900.0
    300529     44000.0
    300699     51400.0
    300760      9800.0
    600276     33400.0
    600529     74100.0
    603019     81600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200721 ticker: 000977 to sell begin------------
    before cash: 10768837, price: 39.67, sell_vol: 68100
    after cash:13466987
    code
    002385    290700.0
    002555     74700.0
    300003     65900.0
    300529     44000.0
    300699     51400.0
    300760      9800.0
    600276     33400.0
    600529     74100.0
    603019     81600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200721 ticker: 002385 to sell begin------------
    before cash: 13466987, price: 10.04, sell_vol: 290700
    after cash:16381967
    code
    002555    74700.0
    300003    65900.0
    300529    44000.0
    300699    51400.0
    300760     9800.0
    600276    33400.0
    600529    74100.0
    603019    81600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200721 ticker: 002555 to sell begin------------
    before cash: 16381967, price: 47.11, sell_vol: 74700
    after cash:19896685
    code
    300003    65900.0
    300529    44000.0
    300699    51400.0
    300760     9800.0
    600276    33400.0
    600529    74100.0
    603019    81600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200721 ticker: 300003 to sell begin------------
    before cash: 19896685, price: 44.1, sell_vol: 65900
    after cash:22799242
    code
    300529    44000.0
    300699    51400.0
    300760     9800.0
    600276    33400.0
    600529    74100.0
    603019    81600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200721 ticker: 300529 to sell begin------------
    before cash: 22799242, price: 73.61, sell_vol: 44000
    after cash:26034034
    code
    300699    51400.0
    300760     9800.0
    600276    33400.0
    600529    74100.0
    603019    81600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200721 ticker: 300699 to sell begin------------
    before cash: 26034034, price: 73.25, sell_vol: 51400
    after cash:29794377
    code
    300760     9800.0
    600276    33400.0
    600529    74100.0
    603019    81600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200721 ticker: 300760 to sell begin------------
    before cash: 29794377, price: 344.75, sell_vol: 9800
    after cash:33168704
    code
    600276    33400.0
    600529    74100.0
    603019    81600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200721 ticker: 600276 to sell begin------------
    before cash: 33168704, price: 99.3, sell_vol: 33400
    after cash:36481178
    code
    600529    74100.0
    603019    81600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200721 ticker: 600529 to sell begin------------
    before cash: 36481178, price: 60.38, sell_vol: 74100
    after cash:40949744
    code
    603019    81600.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20200721 ticker: 603019 to sell begin------------
    before cash: 40949744, price: 46.0, sell_vol: 81600
    after cash:44698652
    Series([], Name: amount, dtype: float64)
    at 20200721 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20200722 ticker: 000661 to buy begin--------------
    to_buy:  
    ['300529', '300699', '002821', '300558', '300628', '300122', '603883', '603233', '000661', '603259', '600276', '002399', '002541', '300760', '002624', '601888']
    before cash: 44698652, price: 487.75, to_buy: 16, buy_vol: 5700
    after cash:41917782
    code
    000661    5700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200722 ticker: 002399 to buy begin--------------
    to_buy:  
    ['300529', '300699', '002821', '300558', '300628', '300122', '603883', '603233', '603259', '600276', '002399', '002541', '300760', '002624', '601888']
    before cash: 41917782, price: 25.7, to_buy: 15, buy_vol: 108700
    after cash:39123493
    code
    000661      5700.0
    002399    108700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200722 ticker: 002541 to buy begin--------------
    to_buy:  
    ['300529', '300699', '002821', '300558', '300628', '300122', '603883', '603233', '603259', '600276', '002541', '300760', '002624', '601888']
    before cash: 39123493, price: 36.24, to_buy: 14, buy_vol: 77100
    after cash:36328691
    code
    000661      5700.0
    002399    108700.0
    002541     77100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200722 ticker: 002624 to buy begin--------------
    to_buy:  
    ['300529', '300699', '002821', '300558', '300628', '300122', '603883', '603233', '603259', '600276', '300760', '002624', '601888']
    before cash: 36328691, price: 42.9, to_buy: 13, buy_vol: 65100
    after cash:33535203
    code
    000661      5700.0
    002399    108700.0
    002541     77100.0
    002624     65100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200722 ticker: 002821 to buy begin--------------
    to_buy:  
    ['300529', '300699', '002821', '603259', '300558', '600276', '300628', '300122', '300760', '603883', '601888', '603233']
    before cash: 33535203, price: 232.2, to_buy: 12, buy_vol: 12000
    after cash:30748106
    code
    000661      5700.0
    002399    108700.0
    002541     77100.0
    002624     65100.0
    002821     12000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200722 ticker: 300122 to buy begin--------------
    to_buy:  
    ['300529', '300699', '603259', '300558', '600276', '300628', '300122', '300760', '603883', '601888', '603233']
    before cash: 30748106, price: 147.0, to_buy: 11, buy_vol: 19000
    after cash:27954408
    code
    000661      5700.0
    002399    108700.0
    002541     77100.0
    002624     65100.0
    002821     12000.0
    300122     19000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200722 ticker: 300529 to buy begin--------------
    to_buy:  
    ['300529', '300699', '603259', '300558', '600276', '300628', '300760', '603883', '601888', '603233']
    before cash: 27954408, price: 73.63, to_buy: 10, buy_vol: 37900
    after cash:25163133
    code
    000661      5700.0
    002399    108700.0
    002541     77100.0
    002624     65100.0
    002821     12000.0
    300122     19000.0
    300529     37900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200722 ticker: 300558 to buy begin--------------
    to_buy:  
    ['300699', '603259', '300558', '600276', '300628', '300760', '603883', '601888', '603233']
    before cash: 25163133, price: 148.5, to_buy: 9, buy_vol: 18800
    after cash:22370635
    code
    000661      5700.0
    002399    108700.0
    002541     77100.0
    002624     65100.0
    002821     12000.0
    300122     19000.0
    300529     37900.0
    300558     18800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200722 ticker: 300628 to buy begin--------------
    to_buy:  
    ['300699', '603259', '600276', '300628', '300760', '603883', '601888', '603233']
    before cash: 22370635, price: 67.37, to_buy: 8, buy_vol: 41500
    after cash:19574081
    code
    000661      5700.0
    002399    108700.0
    002541     77100.0
    002624     65100.0
    002821     12000.0
    300122     19000.0
    300529     37900.0
    300558     18800.0
    300628     41500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200722 ticker: 300699 to buy begin--------------
    to_buy:  
    ['300699', '603259', '600276', '300760', '603883', '601888', '603233']
    before cash: 19574081, price: 73.8, to_buy: 7, buy_vol: 37800
    after cash:16783744
    code
    000661      5700.0
    002399    108700.0
    002541     77100.0
    002624     65100.0
    002821     12000.0
    300122     19000.0
    300529     37900.0
    300558     18800.0
    300628     41500.0
    300699     37800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200722 ticker: 300760 to buy begin--------------
    to_buy:  
    ['603259', '600276', '300760', '603883', '601888', '603233']
    before cash: 16783744, price: 348.3, to_buy: 6, buy_vol: 8000
    after cash:13996647
    code
    000661      5700.0
    002399    108700.0
    002541     77100.0
    002624     65100.0
    002821     12000.0
    300122     19000.0
    300529     37900.0
    300558     18800.0
    300628     41500.0
    300699     37800.0
    300760      8000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200722 ticker: 600276 to buy begin--------------
    to_buy:  
    ['603259', '600276', '603883', '601888', '603233']
    before cash: 13996647, price: 99.37, to_buy: 5, buy_vol: 28100
    after cash:11203652
    code
    000661      5700.0
    002399    108700.0
    002541     77100.0
    002624     65100.0
    002821     12000.0
    300122     19000.0
    300529     37900.0
    300558     18800.0
    300628     41500.0
    300699     37800.0
    300760      8000.0
    600276     28100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200722 ticker: 601888 to buy begin--------------
    to_buy:  
    ['603883', '603259', '601888', '603233']
    before cash: 11203652, price: 206.61, to_buy: 4, buy_vol: 13500
    after cash:8413720
    code
    000661      5700.0
    002399    108700.0
    002541     77100.0
    002624     65100.0
    002821     12000.0
    300122     19000.0
    300529     37900.0
    300558     18800.0
    300628     41500.0
    300699     37800.0
    300760      8000.0
    600276     28100.0
    601888     13500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200722 ticker: 603233 to buy begin--------------
    to_buy:  
    ['603883', '603259', '603233']
    before cash: 8413720, price: 76.9, to_buy: 3, buy_vol: 36400
    after cash:5613860
    code
    000661      5700.0
    002399    108700.0
    002541     77100.0
    002624     65100.0
    002821     12000.0
    300122     19000.0
    300529     37900.0
    300558     18800.0
    300628     41500.0
    300699     37800.0
    300760      8000.0
    600276     28100.0
    601888     13500.0
    603233     36400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200722 ticker: 603259 to buy begin--------------
    to_buy:  
    ['603883', '603259']
    before cash: 5613860, price: 109.52, to_buy: 2, buy_vol: 25600
    after cash:2809447
    code
    000661      5700.0
    002399    108700.0
    002541     77100.0
    002624     65100.0
    002821     12000.0
    300122     19000.0
    300529     37900.0
    300558     18800.0
    300628     41500.0
    300699     37800.0
    300760      8000.0
    600276     28100.0
    601888     13500.0
    603233     36400.0
    603259     25600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20200722 ticker: 603883 to buy begin--------------
    to_buy:  
    ['603883']
    before cash: 2809447, price: 111.5, to_buy: 1, buy_vol: 25100
    after cash:10097
    code
    000661      5700.0
    002399    108700.0
    002541     77100.0
    002624     65100.0
    002821     12000.0
    300122     19000.0
    300529     37900.0
    300558     18800.0
    300628     41500.0
    300699     37800.0
    300760      8000.0
    600276     28100.0
    601888     13500.0
    603233     36400.0
    603259     25600.0
    603883     25100.0
    Name: amount, dtype: float64
    at 20200722 clear the to_buy list successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2020-08-12  300122      5.0          0.0    0.0       0.0
    分红，增加现金9500.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2020-08-21  603883      4.2          4.0    0.0       0.0
    分红，增加现金10542.0
    转增股，增加股票10000.0股603883
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20201028 ticker: 000661 to sell begin------------
    before cash: 30134, price: 377.52, sell_vol: 5700
    after cash:2179309
    code
    002399    108700.0
    002541     77100.0
    002624     65100.0
    002821     12000.0
    300122     19000.0
    300529     37900.0
    300558     18800.0
    300628     41500.0
    300699     37800.0
    300760      8000.0
    600276     28100.0
    601888     13500.0
    603233     36400.0
    603259     25600.0
    603883     35100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20201028 ticker: 002399 to sell begin------------
    before cash: 2179309, price: 20.58, sell_vol: 108700
    after cash:4413558
    code
    002541    77100.0
    002624    65100.0
    002821    12000.0
    300122    19000.0
    300529    37900.0
    300558    18800.0
    300628    41500.0
    300699    37800.0
    300760     8000.0
    600276    28100.0
    601888    13500.0
    603233    36400.0
    603259    25600.0
    603883    35100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20201028 ticker: 002541 to sell begin------------
    before cash: 4413558, price: 39.27, sell_vol: 77100
    after cash:7437491
    code
    002624    65100.0
    002821    12000.0
    300122    19000.0
    300529    37900.0
    300558    18800.0
    300628    41500.0
    300699    37800.0
    300760     8000.0
    600276    28100.0
    601888    13500.0
    603233    36400.0
    603259    25600.0
    603883    35100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20201028 ticker: 002624 to sell begin------------
    before cash: 7437491, price: 29.1, sell_vol: 65100
    after cash:9329533
    code
    002821    12000.0
    300122    19000.0
    300529    37900.0
    300558    18800.0
    300628    41500.0
    300699    37800.0
    300760     8000.0
    600276    28100.0
    601888    13500.0
    603233    36400.0
    603259    25600.0
    603883    35100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20201028 ticker: 002821 to sell begin------------
    before cash: 9329533, price: 282.84, sell_vol: 12000
    after cash:12719370
    code
    300122    19000.0
    300529    37900.0
    300558    18800.0
    300628    41500.0
    300699    37800.0
    300760     8000.0
    600276    28100.0
    601888    13500.0
    603233    36400.0
    603259    25600.0
    603883    35100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20201028 ticker: 300122 to sell begin------------
    before cash: 12719370, price: 146.1, sell_vol: 19000
    after cash:15491800
    code
    300529    37900.0
    300558    18800.0
    300628    41500.0
    300699    37800.0
    300760     8000.0
    600276    28100.0
    601888    13500.0
    603233    36400.0
    603259    25600.0
    603883    35100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20201028 ticker: 300529 to sell begin------------
    before cash: 15491800, price: 78.75, sell_vol: 37900
    after cash:18472694
    code
    300558    18800.0
    300628    41500.0
    300699    37800.0
    300760     8000.0
    600276    28100.0
    601888    13500.0
    603233    36400.0
    603259    25600.0
    603883    35100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20201028 ticker: 300558 to sell begin------------
    before cash: 18472694, price: 108.42, sell_vol: 18800
    after cash:20508442
    code
    300628    41500.0
    300699    37800.0
    300760     8000.0
    600276    28100.0
    601888    13500.0
    603233    36400.0
    603259    25600.0
    603883    35100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20201028 ticker: 300628 to sell begin------------
    before cash: 20508442, price: 63.58, sell_vol: 41500
    after cash:23143714
    code
    300699    37800.0
    300760     8000.0
    600276    28100.0
    601888    13500.0
    603233    36400.0
    603259    25600.0
    603883    35100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20201028 ticker: 300699 to sell begin------------
    before cash: 23143714, price: 70.91, sell_vol: 37800
    after cash:25820762
    code
    300760     8000.0
    600276    28100.0
    601888    13500.0
    603233    36400.0
    603259    25600.0
    603883    35100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20201028 ticker: 300760 to sell begin------------
    before cash: 25820762, price: 374.0, sell_vol: 8000
    after cash:28809022
    code
    600276    28100.0
    601888    13500.0
    603233    36400.0
    603259    25600.0
    603883    35100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20201028 ticker: 600276 to sell begin------------
    before cash: 28809022, price: 91.36, sell_vol: 28100
    after cash:31373029
    code
    601888    13500.0
    603233    36400.0
    603259    25600.0
    603883    35100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20201028 ticker: 601888 to sell begin------------
    before cash: 31373029, price: 198.41, sell_vol: 13500
    after cash:34048216
    code
    603233    36400.0
    603259    25600.0
    603883    35100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20201028 ticker: 603233 to sell begin------------
    before cash: 34048216, price: 86.12, sell_vol: 36400
    after cash:37179065
    code
    603259    25600.0
    603883    35100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20201028 ticker: 603259 to sell begin------------
    before cash: 37179065, price: 109.6, sell_vol: 25600
    after cash:39981318
    code
    603883    35100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20201028 ticker: 603883 to sell begin------------
    before cash: 39981318, price: 72.49, sell_vol: 35100
    after cash:42522536
    Series([], Name: amount, dtype: float64)
    at 20201028 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20201029 ticker: 000661 to buy begin--------------
    to_buy:  
    ['000733', '601012', '300529', '300699', '002705', '300601', '600763', '603308', '300763', '300628', '300750', '600438', '000661', '603589', '600276', '600845', '601888', '002541', '603708', '000876', '002078']
    before cash: 42522536, price: 378.79, to_buy: 21, buy_vol: 5300
    after cash:40514447
    code
    000661    5300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20201029 ticker: 000733 to buy begin--------------
    to_buy:  
    ['000733', '601012', '300529', '300699', '002705', '300601', '600763', '603308', '300763', '300628', '300750', '600438', '603589', '600276', '600845', '601888', '002541', '603708', '000876', '002078']
    before cash: 40514447, price: 43.25, to_buy: 20, buy_vol: 46800
    after cash:38489841
    code
    000661     5300.0
    000733    46800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20201029 ticker: 000876 to buy begin--------------
    to_buy:  
    ['601012', '300529', '300699', '002705', '300601', '600763', '603308', '300763', '300628', '300750', '600438', '603589', '600276', '600845', '601888', '002541', '603708', '000876', '002078']
    before cash: 38489841, price: 27.86, to_buy: 19, buy_vol: 72700
    after cash:36463913
    code
    000661     5300.0
    000733    46800.0
    000876    72700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20201029 ticker: 002078 to buy begin--------------
    to_buy:  
    ['601012', '300529', '300699', '002705', '300601', '600763', '603308', '300763', '300628', '300750', '600438', '603589', '600276', '600845', '601888', '002541', '603708', '002078']
    before cash: 36463913, price: 13.9, to_buy: 18, buy_vol: 145700
    after cash:34438177
    code
    000661      5300.0
    000733     46800.0
    000876     72700.0
    002078    145700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20201029 ticker: 002541 to buy begin--------------
    to_buy:  
    ['601012', '300529', '300699', '002705', '300601', '600763', '603308', '300763', '300628', '300750', '600438', '603589', '600276', '600845', '601888', '002541', '603708']
    before cash: 34438177, price: 39.23, to_buy: 17, buy_vol: 51600
    after cash:32413403
    code
    000661      5300.0
    000733     46800.0
    000876     72700.0
    002078    145700.0
    002541     51600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20201029 ticker: 002705 to buy begin--------------
    to_buy:  
    ['300529', '601012', '603589', '300699', '002705', '300601', '600763', '603308', '600276', '300763', '600845', '300628', '601888', '603708', '300750', '600438']
    before cash: 32413403, price: 46.18, to_buy: 16, buy_vol: 43800
    after cash:30390213
    code
    000661      5300.0
    000733     46800.0
    000876     72700.0
    002078    145700.0
    002541     51600.0
    002705     43800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20201029 ticker: 300529 to buy begin--------------
    to_buy:  
    ['300529', '601012', '603589', '300699', '300601', '600763', '603308', '600276', '300763', '600845', '300628', '601888', '603708', '300750', '600438']
    before cash: 30390213, price: 81.33, to_buy: 15, buy_vol: 24900
    after cash:28364590
    code
    000661      5300.0
    000733     46800.0
    000876     72700.0
    002078    145700.0
    002541     51600.0
    002705     43800.0
    300529     24900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20201029 ticker: 300601 to buy begin--------------
    to_buy:  
    ['603589', '601012', '300699', '300601', '600763', '603308', '600276', '300763', '600845', '300628', '601888', '603708', '300750', '600438']
    before cash: 28364590, price: 179.78, to_buy: 14, buy_vol: 11200
    after cash:26350550
    code
    000661      5300.0
    000733     46800.0
    000876     72700.0
    002078    145700.0
    002541     51600.0
    002705     43800.0
    300529     24900.0
    300601     11200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20201029 ticker: 300628 to buy begin--------------
    to_buy:  
    ['603589', '601012', '300699', '600763', '603308', '600276', '300763', '600845', '300628', '601888', '603708', '300750', '600438']
    before cash: 26350550, price: 62.73, to_buy: 13, buy_vol: 32300
    after cash:24323865
    code
    000661      5300.0
    000733     46800.0
    000876     72700.0
    002078    145700.0
    002541     51600.0
    002705     43800.0
    300529     24900.0
    300601     11200.0
    300628     32300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20201029 ticker: 300699 to buy begin--------------
    to_buy:  
    ['603589', '601012', '300699', '600763', '603308', '600276', '300763', '600845', '601888', '603708', '300750', '600438']
    before cash: 24323865, price: 69.95, to_buy: 12, buy_vol: 28900
    after cash:22301804
    code
    000661      5300.0
    000733     46800.0
    000876     72700.0
    002078    145700.0
    002541     51600.0
    002705     43800.0
    300529     24900.0
    300601     11200.0
    300628     32300.0
    300699     28900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20201029 ticker: 300750 to buy begin--------------
    to_buy:  
    ['603589', '601012', '600763', '603308', '600276', '300763', '600845', '601888', '603708', '300750', '600438']
    before cash: 22301804, price: 240.0, to_buy: 11, buy_vol: 8400
    after cash:20285300
    code
    000661      5300.0
    000733     46800.0
    000876     72700.0
    002078    145700.0
    002541     51600.0
    002705     43800.0
    300529     24900.0
    300601     11200.0
    300628     32300.0
    300699     28900.0
    300750      8400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20201029 ticker: 300763 to buy begin--------------
    to_buy:  
    ['603589', '601012', '600763', '603308', '600276', '300763', '600845', '603708', '601888', '600438']
    before cash: 20285300, price: 123.4, to_buy: 10, buy_vol: 16400
    after cash:18261035
    code
    000661      5300.0
    000733     46800.0
    000876     72700.0
    002078    145700.0
    002541     51600.0
    002705     43800.0
    300529     24900.0
    300601     11200.0
    300628     32300.0
    300699     28900.0
    300750      8400.0
    300763     16400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20201029 ticker: 600276 to buy begin--------------
    to_buy:  
    ['603589', '601012', '600763', '603308', '600276', '600845', '603708', '601888', '600438']
    before cash: 18261035, price: 91.04, to_buy: 9, buy_vol: 22200
    after cash:16239441
    code
    000661      5300.0
    000733     46800.0
    000876     72700.0
    002078    145700.0
    002541     51600.0
    002705     43800.0
    300529     24900.0
    300601     11200.0
    300628     32300.0
    300699     28900.0
    300750      8400.0
    300763     16400.0
    600276     22200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20201029 ticker: 600438 to buy begin--------------
    to_buy:  
    ['603589', '601012', '600763', '603308', '600845', '603708', '601888', '600438']
    before cash: 16239441, price: 30.58, to_buy: 8, buy_vol: 66300
    after cash:14211480
    code
    000661      5300.0
    000733     46800.0
    000876     72700.0
    002078    145700.0
    002541     51600.0
    002705     43800.0
    300529     24900.0
    300601     11200.0
    300628     32300.0
    300699     28900.0
    300750      8400.0
    300763     16400.0
    600276     22200.0
    600438     66300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20201029 ticker: 600763 to buy begin--------------
    to_buy:  
    ['603589', '601012', '600763', '603308', '600845', '603708', '601888']
    before cash: 14211480, price: 224.72, to_buy: 7, buy_vol: 9000
    after cash:12188495
    code
    000661      5300.0
    000733     46800.0
    000876     72700.0
    002078    145700.0
    002541     51600.0
    002705     43800.0
    300529     24900.0
    300601     11200.0
    300628     32300.0
    300699     28900.0
    300750      8400.0
    300763     16400.0
    600276     22200.0
    600438     66300.0
    600763      9000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20201029 ticker: 600845 to buy begin--------------
    to_buy:  
    ['603589', '601012', '603308', '600845', '603708', '601888']
    before cash: 12188495, price: 64.46, to_buy: 6, buy_vol: 31500
    after cash:10157497
    code
    000661      5300.0
    000733     46800.0
    000876     72700.0
    002078    145700.0
    002541     51600.0
    002705     43800.0
    300529     24900.0
    300601     11200.0
    300628     32300.0
    300699     28900.0
    300750      8400.0
    300763     16400.0
    600276     22200.0
    600438     66300.0
    600763      9000.0
    600845     31500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20201029 ticker: 601012 to buy begin--------------
    to_buy:  
    ['603589', '601012', '603308', '603708', '601888']
    before cash: 10157497, price: 74.2, to_buy: 5, buy_vol: 27300
    after cash:8131331
    code
    000661      5300.0
    000733     46800.0
    000876     72700.0
    002078    145700.0
    002541     51600.0
    002705     43800.0
    300529     24900.0
    300601     11200.0
    300628     32300.0
    300699     28900.0
    300750      8400.0
    300763     16400.0
    600276     22200.0
    600438     66300.0
    600763      9000.0
    600845     31500.0
    601012     27300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20201029 ticker: 601888 to buy begin--------------
    to_buy:  
    ['603589', '603308', '601888', '603708']
    before cash: 8131331, price: 200.43, to_buy: 4, buy_vol: 10100
    after cash:6106482
    code
    000661      5300.0
    000733     46800.0
    000876     72700.0
    002078    145700.0
    002541     51600.0
    002705     43800.0
    300529     24900.0
    300601     11200.0
    300628     32300.0
    300699     28900.0
    300750      8400.0
    300763     16400.0
    600276     22200.0
    600438     66300.0
    600763      9000.0
    600845     31500.0
    601012     27300.0
    601888     10100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20201029 ticker: 603308 to buy begin--------------
    to_buy:  
    ['603589', '603308', '603708']
    before cash: 6106482, price: 26.56, to_buy: 3, buy_vol: 76600
    after cash:4071477
    code
    000661      5300.0
    000733     46800.0
    000876     72700.0
    002078    145700.0
    002541     51600.0
    002705     43800.0
    300529     24900.0
    300601     11200.0
    300628     32300.0
    300699     28900.0
    300750      8400.0
    300763     16400.0
    600276     22200.0
    600438     66300.0
    600763      9000.0
    600845     31500.0
    601012     27300.0
    601888     10100.0
    603308     76600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20201029 ticker: 603589 to buy begin--------------
    to_buy:  
    ['603589', '603708']
    before cash: 4071477, price: 57.6, to_buy: 2, buy_vol: 35300
    after cash:2037689
    code
    000661      5300.0
    000733     46800.0
    000876     72700.0
    002078    145700.0
    002541     51600.0
    002705     43800.0
    300529     24900.0
    300601     11200.0
    300628     32300.0
    300699     28900.0
    300750      8400.0
    300763     16400.0
    600276     22200.0
    600438     66300.0
    600763      9000.0
    600845     31500.0
    601012     27300.0
    601888     10100.0
    603308     76600.0
    603589     35300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20201029 ticker: 603708 to buy begin--------------
    to_buy:  
    ['603708']
    before cash: 2037689, price: 29.52, to_buy: 1, buy_vol: 69000
    after cash:299
    code
    000661      5300.0
    000733     46800.0
    000876     72700.0
    002078    145700.0
    002541     51600.0
    002705     43800.0
    300529     24900.0
    300601     11200.0
    300628     32300.0
    300699     28900.0
    300750      8400.0
    300763     16400.0
    600276     22200.0
    600438     66300.0
    600763      9000.0
    600845     31500.0
    601012     27300.0
    601888     10100.0
    603308     76600.0
    603589     35300.0
    603708     69000.0
    Name: amount, dtype: float64
    at 20201029 clear the to_buy list successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20210122 ticker: 000661 to sell begin------------
    before cash: 299, price: 467.0, sell_vol: 5300
    after cash:2472306
    code
    000733     46800.0
    000876     72700.0
    002078    145700.0
    002541     51600.0
    002705     43800.0
    300529     24900.0
    300601     11200.0
    300628     32300.0
    300699     28900.0
    300750      8400.0
    300763     16400.0
    600276     22200.0
    600438     66300.0
    600763      9000.0
    600845     31500.0
    601012     27300.0
    601888     10100.0
    603308     76600.0
    603589     35300.0
    603708     69000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210122 ticker: 000733 to sell begin------------
    before cash: 2472306, price: 60.54, sell_vol: 46800
    after cash:5302036
    code
    000876     72700.0
    002078    145700.0
    002541     51600.0
    002705     43800.0
    300529     24900.0
    300601     11200.0
    300628     32300.0
    300699     28900.0
    300750      8400.0
    300763     16400.0
    600276     22200.0
    600438     66300.0
    600763      9000.0
    600845     31500.0
    601012     27300.0
    601888     10100.0
    603308     76600.0
    603589     35300.0
    603708     69000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210122 ticker: 000876 to sell begin------------
    before cash: 5302036, price: 21.79, sell_vol: 72700
    after cash:6884189
    code
    002078    145700.0
    002541     51600.0
    002705     43800.0
    300529     24900.0
    300601     11200.0
    300628     32300.0
    300699     28900.0
    300750      8400.0
    300763     16400.0
    600276     22200.0
    600438     66300.0
    600763      9000.0
    600845     31500.0
    601012     27300.0
    601888     10100.0
    603308     76600.0
    603589     35300.0
    603708     69000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210122 ticker: 002078 to sell begin------------
    before cash: 6884189, price: 16.35, sell_vol: 145700
    after cash:9263406
    code
    002541    51600.0
    002705    43800.0
    300529    24900.0
    300601    11200.0
    300628    32300.0
    300699    28900.0
    300750     8400.0
    300763    16400.0
    600276    22200.0
    600438    66300.0
    600763     9000.0
    600845    31500.0
    601012    27300.0
    601888    10100.0
    603308    76600.0
    603589    35300.0
    603708    69000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210122 ticker: 002541 to sell begin------------
    before cash: 9263406, price: 45.47, sell_vol: 51600
    after cash:11606725
    code
    002705    43800.0
    300529    24900.0
    300601    11200.0
    300628    32300.0
    300699    28900.0
    300750     8400.0
    300763    16400.0
    600276    22200.0
    600438    66300.0
    600763     9000.0
    600845    31500.0
    601012    27300.0
    601888    10100.0
    603308    76600.0
    603589    35300.0
    603708    69000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210122 ticker: 002705 to sell begin------------
    before cash: 11606725, price: 57.58, sell_vol: 43800
    after cash:14125577
    code
    300529    24900.0
    300601    11200.0
    300628    32300.0
    300699    28900.0
    300750     8400.0
    300763    16400.0
    600276    22200.0
    600438    66300.0
    600763     9000.0
    600845    31500.0
    601012    27300.0
    601888    10100.0
    603308    76600.0
    603589    35300.0
    603708    69000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210122 ticker: 300529 to sell begin------------
    before cash: 14125577, price: 84.63, sell_vol: 24900
    after cash:16230230
    code
    300601    11200.0
    300628    32300.0
    300699    28900.0
    300750     8400.0
    300763    16400.0
    600276    22200.0
    600438    66300.0
    600763     9000.0
    600845    31500.0
    601012    27300.0
    601888    10100.0
    603308    76600.0
    603589    35300.0
    603708    69000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210122 ticker: 300601 to sell begin------------
    before cash: 16230230, price: 169.8, sell_vol: 11200
    after cash:18129612
    code
    300628    32300.0
    300699    28900.0
    300750     8400.0
    300763    16400.0
    600276    22200.0
    600438    66300.0
    600763     9000.0
    600845    31500.0
    601012    27300.0
    601888    10100.0
    603308    76600.0
    603589    35300.0
    603708    69000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210122 ticker: 300628 to sell begin------------
    before cash: 18129612, price: 83.84, sell_vol: 32300
    after cash:20834259
    code
    300699    28900.0
    300750     8400.0
    300763    16400.0
    600276    22200.0
    600438    66300.0
    600763     9000.0
    600845    31500.0
    601012    27300.0
    601888    10100.0
    603308    76600.0
    603589    35300.0
    603708    69000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210122 ticker: 300699 to sell begin------------
    before cash: 20834259, price: 96.07, sell_vol: 28900
    after cash:23607212
    code
    300750     8400.0
    300763    16400.0
    600276    22200.0
    600438    66300.0
    600763     9000.0
    600845    31500.0
    601012    27300.0
    601888    10100.0
    603308    76600.0
    603589    35300.0
    603708    69000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210122 ticker: 300750 to sell begin------------
    before cash: 23607212, price: 408.0, sell_vol: 8400
    after cash:27030128
    code
    300763    16400.0
    600276    22200.0
    600438    66300.0
    600763     9000.0
    600845    31500.0
    601012    27300.0
    601888    10100.0
    603308    76600.0
    603589    35300.0
    603708    69000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210122 ticker: 300763 to sell begin------------
    before cash: 27030128, price: 184.7, sell_vol: 16400
    after cash:30055422
    code
    600276    22200.0
    600438    66300.0
    600763     9000.0
    600845    31500.0
    601012    27300.0
    601888    10100.0
    603308    76600.0
    603589    35300.0
    603708    69000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210122 ticker: 600276 to sell begin------------
    before cash: 30055422, price: 112.6, sell_vol: 22200
    after cash:32552017
    code
    600438    66300.0
    600763     9000.0
    600845    31500.0
    601012    27300.0
    601888    10100.0
    603308    76600.0
    603589    35300.0
    603708    69000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210122 ticker: 600438 to sell begin------------
    before cash: 32552017, price: 44.85, sell_vol: 66300
    after cash:35521855
    code
    600763     9000.0
    600845    31500.0
    601012    27300.0
    601888    10100.0
    603308    76600.0
    603589    35300.0
    603708    69000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210122 ticker: 600763 to sell begin------------
    before cash: 35521855, price: 318.0, sell_vol: 9000
    after cash:38380277
    code
    600845    31500.0
    601012    27300.0
    601888    10100.0
    603308    76600.0
    603589    35300.0
    603708    69000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210122 ticker: 600845 to sell begin------------
    before cash: 38380277, price: 62.37, sell_vol: 31500
    after cash:40342477
    code
    601012    27300.0
    601888    10100.0
    603308    76600.0
    603589    35300.0
    603708    69000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210122 ticker: 601012 to sell begin------------
    before cash: 40342477, price: 119.7, sell_vol: 27300
    after cash:43606202
    code
    601888    10100.0
    603308    76600.0
    603589    35300.0
    603708    69000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210122 ticker: 601888 to sell begin------------
    before cash: 43606202, price: 283.0, sell_vol: 10100
    after cash:46460929
    code
    603308    76600.0
    603589    35300.0
    603708    69000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210122 ticker: 603308 to sell begin------------
    before cash: 46460929, price: 36.21, sell_vol: 76600
    after cash:49231148
    code
    603589    35300.0
    603708    69000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210122 ticker: 603589 to sell begin------------
    before cash: 49231148, price: 64.7, sell_vol: 35300
    after cash:51512203
    code
    603708    69000.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210122 ticker: 603708 to sell begin------------
    before cash: 51512203, price: 22.13, sell_vol: 69000
    after cash:53037264
    Series([], Name: amount, dtype: float64)
    at 20210122 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20210125 ticker: 000568 to buy begin--------------
    to_buy:  
    ['601012', '603317', '000568', '002304', '300015', '300750', '000661', '600809', '603259', '600276', '600309', '000858', '300677', '300760', '601888', '600519']
    before cash: 53037264, price: 263.0, to_buy: 16, buy_vol: 12600
    after cash:49722636
    code
    000568    12600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210125 ticker: 000661 to buy begin--------------
    to_buy:  
    ['601012', '603317', '002304', '300015', '300750', '000661', '600809', '603259', '600276', '600309', '000858', '300677', '300760', '601888', '600519']
    before cash: 49722636, price: 492.38, to_buy: 15, buy_vol: 6700
    after cash:46422865
    code
    000568    12600.0
    000661     6700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210125 ticker: 000858 to buy begin--------------
    to_buy:  
    ['601012', '603317', '002304', '300015', '300750', '600809', '603259', '600276', '600309', '000858', '300677', '300760', '601888', '600519']
    before cash: 46422865, price: 315.69, to_buy: 14, buy_vol: 10500
    after cash:43107291
    code
    000568    12600.0
    000661     6700.0
    000858    10500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210125 ticker: 002304 to buy begin--------------
    to_buy:  
    ['601012', '603317', '002304', '300015', '300750', '600809', '603259', '600276', '600309', '300677', '300760', '601888', '600519']
    before cash: 43107291, price: 212.11, to_buy: 13, buy_vol: 15600
    after cash:39797548
    code
    000568    12600.0
    000661     6700.0
    000858    10500.0
    002304    15600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210125 ticker: 300015 to buy begin--------------
    to_buy:  
    ['601012', '603317', '600809', '603259', '600276', '600309', '300015', '300677', '300760', '300750', '601888', '600519']
    before cash: 39797548, price: 81.76, to_buy: 12, buy_vol: 40500
    after cash:36485440
    code
    000568    12600.0
    000661     6700.0
    000858    10500.0
    002304    15600.0
    300015    40500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210125 ticker: 300677 to buy begin--------------
    to_buy:  
    ['601012', '603317', '600809', '603259', '600276', '600309', '300677', '300760', '300750', '601888', '600519']
    before cash: 36485440, price: 289.8, to_buy: 11, buy_vol: 11400
    after cash:33180894
    code
    000568    12600.0
    000661     6700.0
    000858    10500.0
    002304    15600.0
    300015    40500.0
    300677    11400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210125 ticker: 300750 to buy begin--------------
    to_buy:  
    ['601012', '603317', '600809', '603259', '600276', '600309', '300760', '300750', '601888', '600519']
    before cash: 33180894, price: 396.95, to_buy: 10, buy_vol: 8300
    after cash:29885386
    code
    000568    12600.0
    000661     6700.0
    000858    10500.0
    002304    15600.0
    300015    40500.0
    300677    11400.0
    300750     8300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210125 ticker: 300760 to buy begin--------------
    to_buy:  
    ['601012', '603317', '600809', '603259', '600276', '600309', '300760', '601888', '600519']
    before cash: 29885386, price: 488.0, to_buy: 9, buy_vol: 6800
    after cash:26566156
    code
    000568    12600.0
    000661     6700.0
    000858    10500.0
    002304    15600.0
    300015    40500.0
    300677    11400.0
    300750     8300.0
    300760     6800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210125 ticker: 600276 to buy begin--------------
    to_buy:  
    ['601012', '603317', '600809', '603259', '600276', '600309', '601888', '600519']
    before cash: 26566156, price: 111.45, to_buy: 8, buy_vol: 29700
    after cash:23255264
    code
    000568    12600.0
    000661     6700.0
    000858    10500.0
    002304    15600.0
    300015    40500.0
    300677    11400.0
    300750     8300.0
    300760     6800.0
    600276    29700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210125 ticker: 600309 to buy begin--------------
    to_buy:  
    ['601012', '603317', '600809', '603259', '600309', '601888', '600519']
    before cash: 23255264, price: 116.51, to_buy: 7, buy_vol: 28500
    after cash:19933899
    code
    000568    12600.0
    000661     6700.0
    000858    10500.0
    002304    15600.0
    300015    40500.0
    300677    11400.0
    300750     8300.0
    300760     6800.0
    600276    29700.0
    600309    28500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210125 ticker: 600519 to buy begin--------------
    to_buy:  
    ['601012', '603317', '600809', '603259', '601888', '600519']
    before cash: 19933899, price: 2175.0, to_buy: 6, buy_vol: 1500
    after cash:16670583
    code
    000568    12600.0
    000661     6700.0
    000858    10500.0
    002304    15600.0
    300015    40500.0
    300677    11400.0
    300750     8300.0
    300760     6800.0
    600276    29700.0
    600309    28500.0
    600519     1500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210125 ticker: 600809 to buy begin--------------
    to_buy:  
    ['601012', '603317', '600809', '603259', '601888']
    before cash: 16670583, price: 391.09, to_buy: 5, buy_vol: 8500
    after cash:13345487
    code
    000568    12600.0
    000661     6700.0
    000858    10500.0
    002304    15600.0
    300015    40500.0
    300677    11400.0
    300750     8300.0
    300760     6800.0
    600276    29700.0
    600309    28500.0
    600519     1500.0
    600809     8500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210125 ticker: 601012 to buy begin--------------
    to_buy:  
    ['603259', '601888', '601012', '603317']
    before cash: 13345487, price: 116.77, to_buy: 4, buy_vol: 28500
    after cash:10016710
    code
    000568    12600.0
    000661     6700.0
    000858    10500.0
    002304    15600.0
    300015    40500.0
    300677    11400.0
    300750     8300.0
    300760     6800.0
    600276    29700.0
    600309    28500.0
    600519     1500.0
    600809     8500.0
    601012    28500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210125 ticker: 601888 to buy begin--------------
    to_buy:  
    ['601888', '603259', '603317']
    before cash: 10016710, price: 308.0, to_buy: 3, buy_vol: 10800
    after cash:6689478
    code
    000568    12600.0
    000661     6700.0
    000858    10500.0
    002304    15600.0
    300015    40500.0
    300677    11400.0
    300750     8300.0
    300760     6800.0
    600276    29700.0
    600309    28500.0
    600519     1500.0
    600809     8500.0
    601012    28500.0
    601888    10800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210125 ticker: 603259 to buy begin--------------
    to_buy:  
    ['603259', '603317']
    before cash: 6689478, price: 184.1, to_buy: 2, buy_vol: 18100
    after cash:3356435
    code
    000568    12600.0
    000661     6700.0
    000858    10500.0
    002304    15600.0
    300015    40500.0
    300677    11400.0
    300750     8300.0
    300760     6800.0
    600276    29700.0
    600309    28500.0
    600519     1500.0
    600809     8500.0
    601012    28500.0
    601888    10800.0
    603259    18100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210125 ticker: 603317 to buy begin--------------
    to_buy:  
    ['603317']
    before cash: 3356435, price: 62.5, to_buy: 1, buy_vol: 53700
    ALERT MONEY NOT ENOUGH!!!
    3356435.207999995
    after cash:3356435
    code
    000568    12600.0
    000661     6700.0
    000858    10500.0
    002304    15600.0
    300015    40500.0
    300677    11400.0
    300750     8300.0
    300760     6800.0
    600276    29700.0
    600309    28500.0
    600519     1500.0
    600809     8500.0
    601012    28500.0
    601888    10800.0
    603259    18100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2021-04-20  300677     30.0          0.0    0.0       0.0
    分红，增加现金34200.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    -------today:20210422 ticker: 000568 to sell begin------------
    before cash: 3390635, price: 240.38, sell_vol: 12600
    after cash:6415637
    code
    000661     6700.0
    000858    10500.0
    002304    15600.0
    300015    40500.0
    300677    11400.0
    300750     8300.0
    300760     6800.0
    600276    29700.0
    600309    28500.0
    600519     1500.0
    600809     8500.0
    601012    28500.0
    601888    10800.0
    603259    18100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210422 ticker: 000661 to sell begin------------
    before cash: 6415637, price: 472.4, sell_vol: 6700
    after cash:9576761
    code
    000858    10500.0
    002304    15600.0
    300015    40500.0
    300677    11400.0
    300750     8300.0
    300760     6800.0
    600276    29700.0
    600309    28500.0
    600519     1500.0
    600809     8500.0
    601012    28500.0
    601888    10800.0
    603259    18100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210422 ticker: 000858 to sell begin------------
    before cash: 9576761, price: 271.19, sell_vol: 10500
    after cash:12420697
    code
    002304    15600.0
    300015    40500.0
    300677    11400.0
    300750     8300.0
    300760     6800.0
    600276    29700.0
    600309    28500.0
    600519     1500.0
    600809     8500.0
    601012    28500.0
    601888    10800.0
    603259    18100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210422 ticker: 002304 to sell begin------------
    before cash: 12420697, price: 168.89, sell_vol: 15600
    after cash:15052087
    code
    300015    40500.0
    300677    11400.0
    300750     8300.0
    300760     6800.0
    600276    29700.0
    600309    28500.0
    600519     1500.0
    600809     8500.0
    601012    28500.0
    601888    10800.0
    603259    18100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210422 ticker: 300015 to sell begin------------
    before cash: 15052087, price: 63.65, sell_vol: 40500
    after cash:17626690
    code
    300677    11400.0
    300750     8300.0
    300760     6800.0
    600276    29700.0
    600309    28500.0
    600519     1500.0
    600809     8500.0
    601012    28500.0
    601888    10800.0
    603259    18100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210422 ticker: 300677 to sell begin------------
    before cash: 17626690, price: 157.4, sell_vol: 11400
    after cash:19418807
    code
    300750     8300.0
    300760     6800.0
    600276    29700.0
    600309    28500.0
    600519     1500.0
    600809     8500.0
    601012    28500.0
    601888    10800.0
    603259    18100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210422 ticker: 300750 to sell begin------------
    before cash: 19418807, price: 362.36, sell_vol: 8300
    after cash:22422635
    code
    300760     6800.0
    600276    29700.0
    600309    28500.0
    600519     1500.0
    600809     8500.0
    601012    28500.0
    601888    10800.0
    603259    18100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210422 ticker: 300760 to sell begin------------
    before cash: 22422635, price: 407.2, sell_vol: 6800
    after cash:25188134
    code
    600276    29700.0
    600309    28500.0
    600519     1500.0
    600809     8500.0
    601012    28500.0
    601888    10800.0
    603259    18100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210422 ticker: 600276 to sell begin------------
    before cash: 25188134, price: 82.2, sell_vol: 29700
    after cash:27626423
    code
    600309    28500.0
    600519     1500.0
    600809     8500.0
    601012    28500.0
    601888    10800.0
    603259    18100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210422 ticker: 600309 to sell begin------------
    before cash: 27626423, price: 109.6, sell_vol: 28500
    after cash:30746118
    code
    600519     1500.0
    600809     8500.0
    601012    28500.0
    601888    10800.0
    603259    18100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210422 ticker: 600519 to sell begin------------
    before cash: 30746118, price: 2055.5, sell_vol: 1500
    after cash:33825514
    code
    600809     8500.0
    601012    28500.0
    601888    10800.0
    603259    18100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210422 ticker: 600809 to sell begin------------
    before cash: 33825514, price: 388.0, sell_vol: 8500
    after cash:37119391
    code
    601012    28500.0
    601888    10800.0
    603259    18100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210422 ticker: 601012 to sell begin------------
    before cash: 37119391, price: 90.61, sell_vol: 28500
    after cash:39698549
    code
    601888    10800.0
    603259    18100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210422 ticker: 601888 to sell begin------------
    before cash: 39698549, price: 296.0, sell_vol: 10800
    after cash:42891353
    code
    603259    18100.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210422 ticker: 603259 to sell begin------------
    before cash: 42891353, price: 140.59, sell_vol: 18100
    after cash:45432851
    Series([], Name: amount, dtype: float64)
    at 20210422 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20210423 ticker: 000568 to buy begin--------------
    to_buy:  
    ['601012', '601058', '002241', '000568', '601966', '002304', '300751', '002925', '002311', '000661', '000902', '002597', '000830', '600900', '600809', '601677', '300595', '000858', '600519']
    before cash: 45432851, price: 249.61, to_buy: 19, buy_vol: 9500
    after cash:43060963
    code
    000568    9500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210423 ticker: 000661 to buy begin--------------
    to_buy:  
    ['601012', '601058', '002241', '601966', '002304', '300751', '002925', '002311', '000661', '000902', '002597', '000830', '600900', '600809', '601677', '300595', '000858', '600519']
    before cash: 43060963, price: 480.17, to_buy: 18, buy_vol: 4900
    after cash:40707542
    code
    000568    9500.0
    000661    4900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210423 ticker: 000830 to buy begin--------------
    to_buy:  
    ['601012', '601058', '002241', '601966', '002304', '300751', '002925', '002311', '000902', '002597', '000830', '600900', '600809', '601677', '300595', '000858', '600519']
    before cash: 40707542, price: 15.33, to_buy: 17, buy_vol: 156200
    after cash:38312397
    code
    000568      9500.0
    000661      4900.0
    000830    156200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210423 ticker: 000858 to buy begin--------------
    to_buy:  
    ['601012', '601058', '002241', '601966', '002304', '300751', '002925', '002311', '000902', '002597', '600900', '600809', '601677', '300595', '000858', '600519']
    before cash: 38312397, price: 280.0, to_buy: 16, buy_vol: 8500
    after cash:35931802
    code
    000568      9500.0
    000661      4900.0
    000830    156200.0
    000858      8500.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210423 ticker: 000902 to buy begin--------------
    to_buy:  
    ['601012', '000902', '002597', '601058', '002241', '600900', '600809', '601966', '601677', '002304', '300595', '300751', '002311', '002925', '600519']
    before cash: 35931802, price: 16.4, to_buy: 15, buy_vol: 146000
    after cash:33536803
    code
    000568      9500.0
    000661      4900.0
    000830    156200.0
    000858      8500.0
    000902    146000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210423 ticker: 002241 to buy begin--------------
    to_buy:  
    ['601012', '002597', '601058', '002241', '600900', '600809', '601966', '601677', '002304', '300595', '300751', '002311', '002925', '600519']
    before cash: 33536803, price: 37.23, to_buy: 14, buy_vol: 64300
    after cash:31142316
    code
    000568      9500.0
    000661      4900.0
    000830    156200.0
    000858      8500.0
    000902    146000.0
    002241     64300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210423 ticker: 002304 to buy begin--------------
    to_buy:  
    ['601012', '002597', '601058', '600900', '600809', '601966', '601677', '002304', '300595', '300751', '002311', '002925', '600519']
    before cash: 31142316, price: 171.55, to_buy: 13, buy_vol: 13900
    after cash:28757175
    code
    000568      9500.0
    000661      4900.0
    000830    156200.0
    000858      8500.0
    000902    146000.0
    002241     64300.0
    002304     13900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210423 ticker: 002311 to buy begin--------------
    to_buy:  
    ['601012', '002597', '601058', '600900', '600809', '601966', '601677', '300595', '300751', '002311', '002925', '600519']
    before cash: 28757175, price: 81.4, to_buy: 12, buy_vol: 29400
    after cash:26363416
    code
    000568      9500.0
    000661      4900.0
    000830    156200.0
    000858      8500.0
    000902    146000.0
    002241     64300.0
    002304     13900.0
    002311     29400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210423 ticker: 002597 to buy begin--------------
    to_buy:  
    ['601012', '002597', '601058', '600900', '600809', '601966', '601677', '300595', '300751', '002925', '600519']
    before cash: 26363416, price: 33.87, to_buy: 11, buy_vol: 70700
    after cash:23968209
    code
    000568      9500.0
    000661      4900.0
    000830    156200.0
    000858      8500.0
    000902    146000.0
    002241     64300.0
    002304     13900.0
    002311     29400.0
    002597     70700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210423 ticker: 002925 to buy begin--------------
    to_buy:  
    ['601012', '601058', '600900', '600809', '601966', '601677', '300595', '300751', '002925', '600519']
    before cash: 23968209, price: 40.08, to_buy: 10, buy_vol: 59800
    after cash:21570826
    code
    000568      9500.0
    000661      4900.0
    000830    156200.0
    000858      8500.0
    000902    146000.0
    002241     64300.0
    002304     13900.0
    002311     29400.0
    002597     70700.0
    002925     59800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210423 ticker: 300595 to buy begin--------------
    to_buy:  
    ['601012', '601058', '600900', '600809', '601966', '601677', '300595', '300751', '600519']
    before cash: 21570826, price: 108.5, to_buy: 9, buy_vol: 22000
    after cash:19183229
    code
    000568      9500.0
    000661      4900.0
    000830    156200.0
    000858      8500.0
    000902    146000.0
    002241     64300.0
    002304     13900.0
    002311     29400.0
    002597     70700.0
    002925     59800.0
    300595     22000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210423 ticker: 300751 to buy begin--------------
    to_buy:  
    ['601012', '601058', '600900', '600809', '601966', '601677', '300751', '600519']
    before cash: 19183229, price: 589.05, to_buy: 8, buy_vol: 4000
    after cash:16826440
    code
    000568      9500.0
    000661      4900.0
    000830    156200.0
    000858      8500.0
    000902    146000.0
    002241     64300.0
    002304     13900.0
    002311     29400.0
    002597     70700.0
    002925     59800.0
    300595     22000.0
    300751      4000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210423 ticker: 600519 to buy begin--------------
    to_buy:  
    ['601012', '601058', '600900', '600809', '601966', '601677', '600519']
    before cash: 16826440, price: 2108.94, to_buy: 7, buy_vol: 1100
    after cash:14506026
    code
    000568      9500.0
    000661      4900.0
    000830    156200.0
    000858      8500.0
    000902    146000.0
    002241     64300.0
    002304     13900.0
    002311     29400.0
    002597     70700.0
    002925     59800.0
    300595     22000.0
    300751      4000.0
    600519      1100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210423 ticker: 600809 to buy begin--------------
    to_buy:  
    ['601012', '601058', '600900', '600809', '601966', '601677']
    before cash: 14506026, price: 390.49, to_buy: 6, buy_vol: 6100
    after cash:12123441
    code
    000568      9500.0
    000661      4900.0
    000830    156200.0
    000858      8500.0
    000902    146000.0
    002241     64300.0
    002304     13900.0
    002311     29400.0
    002597     70700.0
    002925     59800.0
    300595     22000.0
    300751      4000.0
    600519      1100.0
    600809      6100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210423 ticker: 600900 to buy begin--------------
    to_buy:  
    ['601012', '601058', '600900', '601677', '601966']
    before cash: 12123441, price: 20.38, to_buy: 5, buy_vol: 118900
    after cash:9699654
    code
    000568      9500.0
    000661      4900.0
    000830    156200.0
    000858      8500.0
    000902    146000.0
    002241     64300.0
    002304     13900.0
    002311     29400.0
    002597     70700.0
    002925     59800.0
    300595     22000.0
    300751      4000.0
    600519      1100.0
    600809      6100.0
    600900    118900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210423 ticker: 601012 to buy begin--------------
    to_buy:  
    ['601677', '601012', '601966', '601058']
    before cash: 9699654, price: 91.99, to_buy: 4, buy_vol: 26300
    after cash:7279712
    code
    000568      9500.0
    000661      4900.0
    000830    156200.0
    000858      8500.0
    000902    146000.0
    002241     64300.0
    002304     13900.0
    002311     29400.0
    002597     70700.0
    002925     59800.0
    300595     22000.0
    300751      4000.0
    600519      1100.0
    600809      6100.0
    600900    118900.0
    601012     26300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210423 ticker: 601058 to buy begin--------------
    to_buy:  
    ['601677', '601966', '601058']
    before cash: 7279712, price: 10.04, to_buy: 3, buy_vol: 241600
    after cash:4853441
    code
    000568      9500.0
    000661      4900.0
    000830    156200.0
    000858      8500.0
    000902    146000.0
    002241     64300.0
    002304     13900.0
    002311     29400.0
    002597     70700.0
    002925     59800.0
    300595     22000.0
    300751      4000.0
    600519      1100.0
    600809      6100.0
    600900    118900.0
    601012     26300.0
    601058    241600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210423 ticker: 601677 to buy begin--------------
    to_buy:  
    ['601677', '601966']
    before cash: 4853441, price: 18.86, to_buy: 2, buy_vol: 128600
    after cash:2427439
    code
    000568      9500.0
    000661      4900.0
    000830    156200.0
    000858      8500.0
    000902    146000.0
    002241     64300.0
    002304     13900.0
    002311     29400.0
    002597     70700.0
    002925     59800.0
    300595     22000.0
    300751      4000.0
    600519      1100.0
    600809      6100.0
    600900    118900.0
    601012     26300.0
    601058    241600.0
    601677    128600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210423 ticker: 601966 to buy begin--------------
    to_buy:  
    ['601966']
    before cash: 2427439, price: 56.51, to_buy: 1, buy_vol: 42900
    after cash:2554
    code
    000568      9500.0
    000661      4900.0
    000830    156200.0
    000858      8500.0
    000902    146000.0
    002241     64300.0
    002304     13900.0
    002311     29400.0
    002597     70700.0
    002925     59800.0
    300595     22000.0
    300751      4000.0
    600519      1100.0
    600809      6100.0
    600900    118900.0
    601012     26300.0
    601058    241600.0
    601677    128600.0
    601966     42900.0
    Name: amount, dtype: float64
    at 20210423 clear the to_buy list successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2021-04-30  000830      5.0          0.0    0.0       0.0
    分红，增加现金78100.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2021-05-11  000902      2.0          0.0    0.0       0.0
    分红，增加现金29200.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2021-05-14  601677      2.0          0.0    0.0       0.0
    分红，增加现金25720.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2021-05-18  300751     15.0          8.0    0.0       0.0
    分红，增加现金6000.0
    转增股，增加股票3200.0股300751
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2021-05-19  000661      8.0          0.0    0.0       0.0
    分红，增加现金3920.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2021-05-20  002241      1.5          0.0    0.0       0.0
    分红，增加现金9645.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2021-05-21  002597      4.5          0.0    0.0       0.0
    分红，增加现金31815.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2021-05-21  300595     2.05          4.0    0.0       0.0
    分红，增加现金4510.0
    转增股，增加股票8800.0股300595
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2021-06-10  601966      4.9          0.0    0.0       0.0
    分红，增加现金21021.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2021-06-18  601058      1.5          0.0    0.0       0.0
    分红，增加现金36240.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2021-06-23  601012      2.5          4.0    0.0       0.0
    分红，增加现金6575.0
    转增股，增加股票10500.0股601012
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code     fenhong  songzhuangu  peigu  peigujia
    date                                                        
    2021-06-25  600519  192.929993          0.0    0.0       0.0
    分红，增加现金21222.3
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2021-07-05  600809      2.0          4.0    0.0       0.0
    分红，增加现金1220.0
    转增股，增加股票2400.0股600809
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code    fenhong  songzhuangu  peigu  peigujia
    date                                                       
    2021-07-09  000858  25.799999          0.0    0.0       0.0
    分红，增加现金21930.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2021-07-09  002304     30.0          0.0    0.0       0.0
    分红，增加现金41700.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2021-07-09  002311      3.2          0.0    0.0       0.0
    分红，增加现金9408.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2021-07-16  600900      7.0          0.0    0.0       0.0
    分红，增加现金83230.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20210721 ticker: 000568 to sell begin------------
    before cash: 433990, price: 222.72, sell_vol: 9500
    after cash:2547185
    code
    000661      4900.0
    000830    156200.0
    000858      8500.0
    000902    146000.0
    002241     64300.0
    002304     13900.0
    002311     29400.0
    002597     70700.0
    002925     59800.0
    300595     30800.0
    300751      7200.0
    600519      1100.0
    600809      8500.0
    600900    118900.0
    601012     36800.0
    601058    241600.0
    601677    128600.0
    601966     42900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210721 ticker: 000661 to sell begin------------
    before cash: 2547185, price: 404.96, sell_vol: 4900
    after cash:4529009
    code
    000830    156200.0
    000858      8500.0
    000902    146000.0
    002241     64300.0
    002304     13900.0
    002311     29400.0
    002597     70700.0
    002925     59800.0
    300595     30800.0
    300751      7200.0
    600519      1100.0
    600809      8500.0
    600900    118900.0
    601012     36800.0
    601058    241600.0
    601677    128600.0
    601966     42900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210721 ticker: 000830 to sell begin------------
    before cash: 4529009, price: 20.69, sell_vol: 156200
    after cash:7756747
    code
    000858      8500.0
    000902    146000.0
    002241     64300.0
    002304     13900.0
    002311     29400.0
    002597     70700.0
    002925     59800.0
    300595     30800.0
    300751      7200.0
    600519      1100.0
    600809      8500.0
    600900    118900.0
    601012     36800.0
    601058    241600.0
    601677    128600.0
    601966     42900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210721 ticker: 000858 to sell begin------------
    before cash: 7756747, price: 281.22, sell_vol: 8500
    after cash:10144129
    code
    000902    146000.0
    002241     64300.0
    002304     13900.0
    002311     29400.0
    002597     70700.0
    002925     59800.0
    300595     30800.0
    300751      7200.0
    600519      1100.0
    600809      8500.0
    600900    118900.0
    601012     36800.0
    601058    241600.0
    601677    128600.0
    601966     42900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210721 ticker: 000902 to sell begin------------
    before cash: 10144129, price: 19.62, sell_vol: 146000
    after cash:13005069
    code
    002241     64300.0
    002304     13900.0
    002311     29400.0
    002597     70700.0
    002925     59800.0
    300595     30800.0
    300751      7200.0
    600519      1100.0
    600809      8500.0
    600900    118900.0
    601012     36800.0
    601058    241600.0
    601677    128600.0
    601966     42900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210721 ticker: 002241 to sell begin------------
    before cash: 13005069, price: 39.24, sell_vol: 64300
    after cash:15525047
    code
    002304     13900.0
    002311     29400.0
    002597     70700.0
    002925     59800.0
    300595     30800.0
    300751      7200.0
    600519      1100.0
    600809      8500.0
    600900    118900.0
    601012     36800.0
    601058    241600.0
    601677    128600.0
    601966     42900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210721 ticker: 002304 to sell begin------------
    before cash: 15525047, price: 205.9, sell_vol: 13900
    after cash:18383479
    code
    002311     29400.0
    002597     70700.0
    002925     59800.0
    300595     30800.0
    300751      7200.0
    600519      1100.0
    600809      8500.0
    600900    118900.0
    601012     36800.0
    601058    241600.0
    601677    128600.0
    601966     42900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210721 ticker: 002311 to sell begin------------
    before cash: 18383479, price: 73.3, sell_vol: 29400
    after cash:20535806
    code
    002597     70700.0
    002925     59800.0
    300595     30800.0
    300751      7200.0
    600519      1100.0
    600809      8500.0
    600900    118900.0
    601012     36800.0
    601058    241600.0
    601677    128600.0
    601966     42900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210721 ticker: 002597 to sell begin------------
    before cash: 20535806, price: 32.88, sell_vol: 70700
    after cash:22857516
    code
    002925     59800.0
    300595     30800.0
    300751      7200.0
    600519      1100.0
    600809      8500.0
    600900    118900.0
    601012     36800.0
    601058    241600.0
    601677    128600.0
    601966     42900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210721 ticker: 002925 to sell begin------------
    before cash: 22857516, price: 39.4, sell_vol: 59800
    after cash:25210691
    code
    300595     30800.0
    300751      7200.0
    600519      1100.0
    600809      8500.0
    600900    118900.0
    601012     36800.0
    601058    241600.0
    601677    128600.0
    601966     42900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210721 ticker: 300595 to sell begin------------
    before cash: 25210691, price: 103.0, sell_vol: 30800
    after cash:28379125
    code
    300751      7200.0
    600519      1100.0
    600809      8500.0
    600900    118900.0
    601012     36800.0
    601058    241600.0
    601677    128600.0
    601966     42900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210721 ticker: 300751 to sell begin------------
    before cash: 28379125, price: 537.62, sell_vol: 7200
    after cash:32245151
    code
    600519      1100.0
    600809      8500.0
    600900    118900.0
    601012     36800.0
    601058    241600.0
    601677    128600.0
    601966     42900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210721 ticker: 600519 to sell begin------------
    before cash: 32245151, price: 1969.0, sell_vol: 1100
    after cash:34408343
    code
    600809      8500.0
    600900    118900.0
    601012     36800.0
    601058    241600.0
    601677    128600.0
    601966     42900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210721 ticker: 600809 to sell begin------------
    before cash: 34408343, price: 367.9, sell_vol: 8500
    after cash:37531584
    code
    600900    118900.0
    601012     36800.0
    601058    241600.0
    601677    128600.0
    601966     42900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210721 ticker: 600900 to sell begin------------
    before cash: 37531584, price: 19.01, sell_vol: 118900
    after cash:39789048
    code
    601012     36800.0
    601058    241600.0
    601677    128600.0
    601966     42900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210721 ticker: 601012 to sell begin------------
    before cash: 39789048, price: 93.23, sell_vol: 36800
    after cash:43215623
    code
    601058    241600.0
    601677    128600.0
    601966     42900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210721 ticker: 601058 to sell begin------------
    before cash: 43215623, price: 9.08, sell_vol: 241600
    after cash:45406609
    code
    601677    128600.0
    601966     42900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210721 ticker: 601677 to sell begin------------
    before cash: 45406609, price: 24.8, sell_vol: 128600
    after cash:48591902
    code
    601966    42900.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210721 ticker: 601966 to sell begin------------
    before cash: 48591902, price: 39.38, sell_vol: 42900
    after cash:50279193
    Series([], Name: amount, dtype: float64)
    at 20210721 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    backtest: Settle!
    ------- today:20210722 ticker: 000568 to buy begin--------------
    to_buy:  
    ['000733', '601012', '603444', '601058', '002241', '300014', '603659', '000568', '603799', '002304', '002460', '600176', '300750', '002311', '300274', '600141', '002088', '300146', '600600', '300124', '002709', '300760', '002078', '600519']
    before cash: 50279193, price: 216.55, to_buy: 24, buy_vol: 9600
    after cash:48199793
    code
    000568    9600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210722 ticker: 000733 to buy begin--------------
    to_buy:  
    ['000733', '601012', '603444', '601058', '002241', '300014', '603659', '603799', '002304', '002460', '600176', '300750', '002311', '300274', '600141', '002088', '300146', '600600', '300124', '002709', '300760', '002078', '600519']
    before cash: 48199793, price: 79.7, to_buy: 23, buy_vol: 26200
    after cash:46111131
    code
    000568     9600.0
    000733    26200.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210722 ticker: 002078 to buy begin--------------
    to_buy:  
    ['601012', '603444', '601058', '002241', '300014', '603659', '603799', '002304', '002460', '600176', '300750', '002311', '300274', '600141', '002088', '300146', '600600', '300124', '002709', '300760', '002078', '600519']
    before cash: 46111131, price: 12.21, to_buy: 22, buy_vol: 171600
    after cash:44015371
    code
    000568      9600.0
    000733     26200.0
    002078    171600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210722 ticker: 002088 to buy begin--------------
    to_buy:  
    ['601012', '603444', '601058', '002241', '300014', '603659', '603799', '002304', '002460', '600176', '300750', '002311', '300274', '600141', '002088', '300146', '600600', '300124', '002709', '300760', '600519']
    before cash: 44015371, price: 22.53, to_buy: 21, buy_vol: 93000
    after cash:41919557
    code
    000568      9600.0
    000733     26200.0
    002078    171600.0
    002088     93000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210722 ticker: 002241 to buy begin--------------
    to_buy:  
    ['601012', '603444', '601058', '002241', '300014', '603659', '603799', '002304', '002460', '600176', '300750', '002311', '300274', '600141', '300146', '600600', '300124', '002709', '300760', '600519']
    before cash: 41919557, price: 38.18, to_buy: 20, buy_vol: 54800
    after cash:39826770
    code
    000568      9600.0
    000733     26200.0
    002078    171600.0
    002088     93000.0
    002241     54800.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210722 ticker: 002304 to buy begin--------------
    to_buy:  
    ['601012', '603444', '601058', '300014', '603659', '603799', '002304', '002460', '600176', '300750', '002311', '300274', '600141', '300146', '600600', '300124', '002709', '300760', '600519']
    before cash: 39826770, price: 200.68, to_buy: 19, buy_vol: 10400
    after cash:37739177
    code
    000568      9600.0
    000733     26200.0
    002078    171600.0
    002088     93000.0
    002241     54800.0
    002304     10400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210722 ticker: 002311 to buy begin--------------
    to_buy:  
    ['300274', '601012', '603444', '600141', '300146', '601058', '300014', '603659', '603799', '600600', '300124', '002460', '002709', '600176', '002311', '300760', '300750', '600519']
    before cash: 37739177, price: 72.04, to_buy: 18, buy_vol: 29100
    after cash:35642288
    code
    000568      9600.0
    000733     26200.0
    002078    171600.0
    002088     93000.0
    002241     54800.0
    002304     10400.0
    002311     29100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210722 ticker: 002460 to buy begin--------------
    to_buy:  
    ['300274', '601012', '603444', '600141', '300146', '601058', '300014', '603659', '603799', '600600', '300124', '002460', '002709', '600176', '300760', '300750', '600519']
    before cash: 35642288, price: 200.0, to_buy: 17, buy_vol: 10400
    after cash:33561768
    code
    000568      9600.0
    000733     26200.0
    002078    171600.0
    002088     93000.0
    002241     54800.0
    002304     10400.0
    002311     29100.0
    002460     10400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210722 ticker: 002709 to buy begin--------------
    to_buy:  
    ['300274', '601012', '603444', '600141', '300146', '601058', '300014', '603659', '603799', '600600', '300124', '002709', '600176', '300760', '300750', '600519']
    before cash: 33561768, price: 103.24, to_buy: 16, buy_vol: 20300
    after cash:31465472
    code
    000568      9600.0
    000733     26200.0
    002078    171600.0
    002088     93000.0
    002241     54800.0
    002304     10400.0
    002311     29100.0
    002460     10400.0
    002709     20300.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210722 ticker: 300014 to buy begin--------------
    to_buy:  
    ['300274', '601012', '603444', '600141', '300146', '601058', '300014', '603659', '603799', '600600', '300124', '600176', '300760', '300750', '600519']
    before cash: 31465472, price: 126.0, to_buy: 15, buy_vol: 16600
    after cash:29373350
    code
    000568      9600.0
    000733     26200.0
    002078    171600.0
    002088     93000.0
    002241     54800.0
    002304     10400.0
    002311     29100.0
    002460     10400.0
    002709     20300.0
    300014     16600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210722 ticker: 300124 to buy begin--------------
    to_buy:  
    ['300274', '601012', '603444', '600141', '300146', '601058', '603659', '603799', '600600', '300124', '600176', '300760', '300750', '600519']
    before cash: 29373350, price: 81.4, to_buy: 14, buy_vol: 25700
    after cash:27280847
    code
    000568      9600.0
    000733     26200.0
    002078    171600.0
    002088     93000.0
    002241     54800.0
    002304     10400.0
    002311     29100.0
    002460     10400.0
    002709     20300.0
    300014     16600.0
    300124     25700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210722 ticker: 300146 to buy begin--------------
    to_buy:  
    ['300274', '601012', '603444', '600141', '300146', '601058', '603659', '603799', '600600', '600176', '300760', '300750', '600519']
    before cash: 27280847, price: 30.0, to_buy: 13, buy_vol: 69900
    after cash:25183322
    code
    000568      9600.0
    000733     26200.0
    002078    171600.0
    002088     93000.0
    002241     54800.0
    002304     10400.0
    002311     29100.0
    002460     10400.0
    002709     20300.0
    300014     16600.0
    300124     25700.0
    300146     69900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210722 ticker: 300274 to buy begin--------------
    to_buy:  
    ['300274', '601012', '603444', '600141', '601058', '603659', '603799', '600600', '600176', '300760', '300750', '600519']
    before cash: 25183322, price: 143.05, to_buy: 12, buy_vol: 14600
    after cash:23094270
    code
    000568      9600.0
    000733     26200.0
    002078    171600.0
    002088     93000.0
    002241     54800.0
    002304     10400.0
    002311     29100.0
    002460     10400.0
    002709     20300.0
    300014     16600.0
    300124     25700.0
    300146     69900.0
    300274     14600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210722 ticker: 300750 to buy begin--------------
    to_buy:  
    ['601012', '603444', '600141', '601058', '603659', '603799', '600600', '600176', '300760', '300750', '600519']
    before cash: 23094270, price: 557.08, to_buy: 11, buy_vol: 3700
    after cash:21032559
    code
    000568      9600.0
    000733     26200.0
    002078    171600.0
    002088     93000.0
    002241     54800.0
    002304     10400.0
    002311     29100.0
    002460     10400.0
    002709     20300.0
    300014     16600.0
    300124     25700.0
    300146     69900.0
    300274     14600.0
    300750      3700.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210722 ticker: 300760 to buy begin--------------
    to_buy:  
    ['601012', '603444', '600141', '601058', '603659', '603799', '600600', '600176', '300760', '600519']
    before cash: 21032559, price: 452.0, to_buy: 10, buy_vol: 4600
    after cash:18952839
    code
    000568      9600.0
    000733     26200.0
    002078    171600.0
    002088     93000.0
    002241     54800.0
    002304     10400.0
    002311     29100.0
    002460     10400.0
    002709     20300.0
    300014     16600.0
    300124     25700.0
    300146     69900.0
    300274     14600.0
    300750      3700.0
    300760      4600.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210722 ticker: 600141 to buy begin--------------
    to_buy:  
    ['601012', '603444', '600141', '601058', '603659', '603799', '600600', '600176', '600519']
    before cash: 18952839, price: 28.08, to_buy: 9, buy_vol: 74900
    after cash:16849121
    code
    000568      9600.0
    000733     26200.0
    002078    171600.0
    002088     93000.0
    002241     54800.0
    002304     10400.0
    002311     29100.0
    002460     10400.0
    002709     20300.0
    300014     16600.0
    300124     25700.0
    300146     69900.0
    300274     14600.0
    300750      3700.0
    300760      4600.0
    600141     74900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210722 ticker: 600176 to buy begin--------------
    to_buy:  
    ['601012', '603444', '601058', '603659', '603799', '600600', '600176', '600519']
    before cash: 16849121, price: 16.19, to_buy: 8, buy_vol: 130000
    after cash:14743895
    code
    000568      9600.0
    000733     26200.0
    002078    171600.0
    002088     93000.0
    002241     54800.0
    002304     10400.0
    002311     29100.0
    002460     10400.0
    002709     20300.0
    300014     16600.0
    300124     25700.0
    300146     69900.0
    300274     14600.0
    300750      3700.0
    300760      4600.0
    600141     74900.0
    600176    130000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210722 ticker: 600519 to buy begin--------------
    to_buy:  
    ['601012', '603444', '601058', '603659', '603799', '600600', '600519']
    before cash: 14743895, price: 1940.01, to_buy: 7, buy_vol: 1000
    after cash:12803400
    code
    000568      9600.0
    000733     26200.0
    002078    171600.0
    002088     93000.0
    002241     54800.0
    002304     10400.0
    002311     29100.0
    002460     10400.0
    002709     20300.0
    300014     16600.0
    300124     25700.0
    300146     69900.0
    300274     14600.0
    300750      3700.0
    300760      4600.0
    600141     74900.0
    600176    130000.0
    600519      1000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210722 ticker: 600600 to buy begin--------------
    to_buy:  
    ['601012', '603444', '601058', '603659', '603799', '600600']
    before cash: 12803400, price: 99.34, to_buy: 6, buy_vol: 21400
    after cash:10676993
    code
    000568      9600.0
    000733     26200.0
    002078    171600.0
    002088     93000.0
    002241     54800.0
    002304     10400.0
    002311     29100.0
    002460     10400.0
    002709     20300.0
    300014     16600.0
    300124     25700.0
    300146     69900.0
    300274     14600.0
    300750      3700.0
    300760      4600.0
    600141     74900.0
    600176    130000.0
    600519      1000.0
    600600     21400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210722 ticker: 601012 to buy begin--------------
    to_buy:  
    ['601012', '603444', '601058', '603659', '603799']
    before cash: 10676993, price: 92.98, to_buy: 5, buy_vol: 22900
    after cash:8547218
    code
    000568      9600.0
    000733     26200.0
    002078    171600.0
    002088     93000.0
    002241     54800.0
    002304     10400.0
    002311     29100.0
    002460     10400.0
    002709     20300.0
    300014     16600.0
    300124     25700.0
    300146     69900.0
    300274     14600.0
    300750      3700.0
    300760      4600.0
    600141     74900.0
    600176    130000.0
    600519      1000.0
    600600     21400.0
    601012     22900.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210722 ticker: 601058 to buy begin--------------
    to_buy:  
    ['603659', '603799', '603444', '601058']
    before cash: 8547218, price: 9.41, to_buy: 4, buy_vol: 227000
    after cash:6410614
    code
    000568      9600.0
    000733     26200.0
    002078    171600.0
    002088     93000.0
    002241     54800.0
    002304     10400.0
    002311     29100.0
    002460     10400.0
    002709     20300.0
    300014     16600.0
    300124     25700.0
    300146     69900.0
    300274     14600.0
    300750      3700.0
    300760      4600.0
    600141     74900.0
    600176    130000.0
    600519      1000.0
    600600     21400.0
    601012     22900.0
    601058    227000.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210722 ticker: 603444 to buy begin--------------
    to_buy:  
    ['603659', '603799', '603444']
    before cash: 6410614, price: 510.98, to_buy: 3, buy_vol: 4100
    after cash:4315073
    code
    000568      9600.0
    000733     26200.0
    002078    171600.0
    002088     93000.0
    002241     54800.0
    002304     10400.0
    002311     29100.0
    002460     10400.0
    002709     20300.0
    300014     16600.0
    300124     25700.0
    300146     69900.0
    300274     14600.0
    300750      3700.0
    300760      4600.0
    600141     74900.0
    600176    130000.0
    600519      1000.0
    600600     21400.0
    601012     22900.0
    601058    227000.0
    603444      4100.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210722 ticker: 603659 to buy begin--------------
    to_buy:  
    ['603659', '603799']
    before cash: 4315073, price: 149.69, to_buy: 2, buy_vol: 14400
    after cash:2158998
    code
    000568      9600.0
    000733     26200.0
    002078    171600.0
    002088     93000.0
    002241     54800.0
    002304     10400.0
    002311     29100.0
    002460     10400.0
    002709     20300.0
    300014     16600.0
    300124     25700.0
    300146     69900.0
    300274     14600.0
    300750      3700.0
    300760      4600.0
    600141     74900.0
    600176    130000.0
    600519      1000.0
    600600     21400.0
    601012     22900.0
    601058    227000.0
    603444      4100.0
    603659     14400.0
    Name: amount, dtype: float64
    --------------------- to buy end -------------------------------------------------
    
    ------- today:20210722 ticker: 603799 to buy begin--------------
    to_buy:  
    ['603799']
    before cash: 2158998, price: 140.99, to_buy: 1, buy_vol: 15300
    after cash:1311
    code
    000568      9600.0
    000733     26200.0
    002078    171600.0
    002088     93000.0
    002241     54800.0
    002304     10400.0
    002311     29100.0
    002460     10400.0
    002709     20300.0
    300014     16600.0
    300124     25700.0
    300146     69900.0
    300274     14600.0
    300750      3700.0
    300760      4600.0
    600141     74900.0
    600176    130000.0
    600519      1000.0
    600600     21400.0
    601012     22900.0
    601058    227000.0
    603444      4100.0
    603659     14400.0
    603799     15300.0
    Name: amount, dtype: float64
    at 20210722 clear the to_buy list successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to buy end -------------------------------------------------
    
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    backtest: Settle!
    -------today:20210810 ticker: 000568 to sell begin------------
    before cash: 1311, price: 194.69, sell_vol: 9600
    after cash:1867999
    code
    000733     26200.0
    002078    171600.0
    002088     93000.0
    002241     54800.0
    002304     10400.0
    002311     29100.0
    002460     10400.0
    002709     20300.0
    300014     16600.0
    300124     25700.0
    300146     69900.0
    300274     14600.0
    300750      3700.0
    300760      4600.0
    600141     74900.0
    600176    130000.0
    600519      1000.0
    600600     21400.0
    601012     22900.0
    601058    227000.0
    603444      4100.0
    603659     14400.0
    603799     15300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210810 ticker: 000733 to sell begin------------
    before cash: 1867999, price: 92.0, sell_vol: 26200
    after cash:4275386
    code
    002078    171600.0
    002088     93000.0
    002241     54800.0
    002304     10400.0
    002311     29100.0
    002460     10400.0
    002709     20300.0
    300014     16600.0
    300124     25700.0
    300146     69900.0
    300274     14600.0
    300750      3700.0
    300760      4600.0
    600141     74900.0
    600176    130000.0
    600519      1000.0
    600600     21400.0
    601012     22900.0
    601058    227000.0
    603444      4100.0
    603659     14400.0
    603799     15300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210810 ticker: 002078 to sell begin------------
    before cash: 4275386, price: 12.27, sell_vol: 171600
    after cash:6378286
    code
    002088     93000.0
    002241     54800.0
    002304     10400.0
    002311     29100.0
    002460     10400.0
    002709     20300.0
    300014     16600.0
    300124     25700.0
    300146     69900.0
    300274     14600.0
    300750      3700.0
    300760      4600.0
    600141     74900.0
    600176    130000.0
    600519      1000.0
    600600     21400.0
    601012     22900.0
    601058    227000.0
    603444      4100.0
    603659     14400.0
    603799     15300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210810 ticker: 002088 to sell begin------------
    before cash: 6378286, price: 25.09, sell_vol: 93000
    after cash:8708740
    code
    002241     54800.0
    002304     10400.0
    002311     29100.0
    002460     10400.0
    002709     20300.0
    300014     16600.0
    300124     25700.0
    300146     69900.0
    300274     14600.0
    300750      3700.0
    300760      4600.0
    600141     74900.0
    600176    130000.0
    600519      1000.0
    600600     21400.0
    601012     22900.0
    601058    227000.0
    603444      4100.0
    603659     14400.0
    603799     15300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210810 ticker: 002241 to sell begin------------
    before cash: 8708740, price: 40.88, sell_vol: 54800
    after cash:10946163
    code
    002304     10400.0
    002311     29100.0
    002460     10400.0
    002709     20300.0
    300014     16600.0
    300124     25700.0
    300146     69900.0
    300274     14600.0
    300750      3700.0
    300760      4600.0
    600141     74900.0
    600176    130000.0
    600519      1000.0
    600600     21400.0
    601012     22900.0
    601058    227000.0
    603444      4100.0
    603659     14400.0
    603799     15300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210810 ticker: 002304 to sell begin------------
    before cash: 10946163, price: 178.26, sell_vol: 10400
    after cash:12797750
    code
    002311     29100.0
    002460     10400.0
    002709     20300.0
    300014     16600.0
    300124     25700.0
    300146     69900.0
    300274     14600.0
    300750      3700.0
    300760      4600.0
    600141     74900.0
    600176    130000.0
    600519      1000.0
    600600     21400.0
    601012     22900.0
    601058    227000.0
    603444      4100.0
    603659     14400.0
    603799     15300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210810 ticker: 002311 to sell begin------------
    before cash: 12797750, price: 71.41, sell_vol: 29100
    after cash:14873183
    code
    002460     10400.0
    002709     20300.0
    300014     16600.0
    300124     25700.0
    300146     69900.0
    300274     14600.0
    300750      3700.0
    300760      4600.0
    600141     74900.0
    600176    130000.0
    600519      1000.0
    600600     21400.0
    601012     22900.0
    601058    227000.0
    603444      4100.0
    603659     14400.0
    603799     15300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210810 ticker: 002460 to sell begin------------
    before cash: 14873183, price: 177.0, sell_vol: 10400
    after cash:16711682
    code
    002709     20300.0
    300014     16600.0
    300124     25700.0
    300146     69900.0
    300274     14600.0
    300750      3700.0
    300760      4600.0
    600141     74900.0
    600176    130000.0
    600519      1000.0
    600600     21400.0
    601012     22900.0
    601058    227000.0
    603444      4100.0
    603659     14400.0
    603799     15300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210810 ticker: 002709 to sell begin------------
    before cash: 16711682, price: 118.0, sell_vol: 20300
    after cash:19104088
    code
    300014     16600.0
    300124     25700.0
    300146     69900.0
    300274     14600.0
    300750      3700.0
    300760      4600.0
    600141     74900.0
    600176    130000.0
    600519      1000.0
    600600     21400.0
    601012     22900.0
    601058    227000.0
    603444      4100.0
    603659     14400.0
    603799     15300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210810 ticker: 300014 to sell begin------------
    before cash: 19104088, price: 110.4, sell_vol: 16600
    after cash:20934437
    code
    300124     25700.0
    300146     69900.0
    300274     14600.0
    300750      3700.0
    300760      4600.0
    600141     74900.0
    600176    130000.0
    600519      1000.0
    600600     21400.0
    601012     22900.0
    601058    227000.0
    603444      4100.0
    603659     14400.0
    603799     15300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210810 ticker: 300124 to sell begin------------
    before cash: 20934437, price: 85.25, sell_vol: 25700
    after cash:23122624
    code
    300146     69900.0
    300274     14600.0
    300750      3700.0
    300760      4600.0
    600141     74900.0
    600176    130000.0
    600519      1000.0
    600600     21400.0
    601012     22900.0
    601058    227000.0
    603444      4100.0
    603659     14400.0
    603799     15300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210810 ticker: 300146 to sell begin------------
    before cash: 23122624, price: 31.15, sell_vol: 69900
    after cash:25297287
    code
    300274     14600.0
    300750      3700.0
    300760      4600.0
    600141     74900.0
    600176    130000.0
    600519      1000.0
    600600     21400.0
    601012     22900.0
    601058    227000.0
    603444      4100.0
    603659     14400.0
    603799     15300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210810 ticker: 300274 to sell begin------------
    before cash: 25297287, price: 154.46, sell_vol: 14600
    after cash:27549584
    code
    300750      3700.0
    300760      4600.0
    600141     74900.0
    600176    130000.0
    600519      1000.0
    600600     21400.0
    601012     22900.0
    601058    227000.0
    603444      4100.0
    603659     14400.0
    603799     15300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210810 ticker: 300750 to sell begin------------
    before cash: 27549584, price: 510.5, sell_vol: 3700
    after cash:29436073
    code
    300760      4600.0
    600141     74900.0
    600176    130000.0
    600519      1000.0
    600600     21400.0
    601012     22900.0
    601058    227000.0
    603444      4100.0
    603659     14400.0
    603799     15300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210810 ticker: 300760 to sell begin------------
    before cash: 29436073, price: 403.4, sell_vol: 4600
    after cash:31289393
    code
    600141     74900.0
    600176    130000.0
    600519      1000.0
    600600     21400.0
    601012     22900.0
    601058    227000.0
    603444      4100.0
    603659     14400.0
    603799     15300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210810 ticker: 600141 to sell begin------------
    before cash: 31289393, price: 26.28, sell_vol: 74900
    after cash:33255305
    code
    600176    130000.0
    600519      1000.0
    600600     21400.0
    601012     22900.0
    601058    227000.0
    603444      4100.0
    603659     14400.0
    603799     15300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210810 ticker: 600176 to sell begin------------
    before cash: 33255305, price: 16.72, sell_vol: 130000
    after cash:35426188
    code
    600519      1000.0
    600600     21400.0
    601012     22900.0
    601058    227000.0
    603444      4100.0
    603659     14400.0
    603799     15300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210810 ticker: 600519 to sell begin------------
    before cash: 35426188, price: 1799.0, sell_vol: 1000
    after cash:37222939
    code
    600600     21400.0
    601012     22900.0
    601058    227000.0
    603444      4100.0
    603659     14400.0
    603799     15300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                  code  fenhong  songzhuangu  peigu  peigujia
    date                                                     
    2021-08-10  600600      7.5          0.0    0.0       0.0
    分红，增加现金16050.0
    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    -------today:20210810 ticker: 600600 to sell begin------------
    before cash: 37238989, price: 89.69, sell_vol: 21400
    after cash:39155956
    code
    601012     22900.0
    601058    227000.0
    603444      4100.0
    603659     14400.0
    603799     15300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210810 ticker: 601012 to sell begin------------
    before cash: 39155956, price: 87.28, sell_vol: 22900
    after cash:41152170
    code
    601058    227000.0
    603444      4100.0
    603659     14400.0
    603799     15300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210810 ticker: 601058 to sell begin------------
    before cash: 41152170, price: 8.77, sell_vol: 227000
    after cash:43140471
    code
    603444     4100.0
    603659    14400.0
    603799    15300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210810 ticker: 603444 to sell begin------------
    before cash: 43140471, price: 428.67, sell_vol: 4100
    after cash:44895821
    code
    603659    14400.0
    603799    15300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210810 ticker: 603659 to sell begin------------
    before cash: 44895821, price: 145.3, sell_vol: 14400
    after cash:46985526
    code
    603799    15300.0
    Name: amount, dtype: float64
    --------------------- to sell end ---------------------------------------------
    
    -------today:20210810 ticker: 603799 to sell begin------------
    before cash: 46985526, price: 122.3, sell_vol: 15300
    after cash:48854377
    Series([], Name: amount, dtype: float64)
    at 20210810 clear the position successfully!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    --------------------- to sell end ---------------------------------------------
    
    贝塔计算错误。。
    贝塔计算错误。。



```python
user = QA_User(username='admin', password='admin')
print(user)
# print(user.table)
port = user.get_portfolio(portfolio)
print(port.accounts)
acc = port.get_account_by_cookie(strategy_id)
print(acc)
```

    < QA_USER USER_lNKqZ3mc with 7 portfolio: ['QA_Day', 'Stock_xgb', 'QA_Day1', 'QA_DEMO', 'default', 'QA_Day_2', 'Stock_LSTM'] >
    {'Fund_score_202106292104': < QA_Account Fund_score_202106292104 market: stock_cn>, 'Fund_score_202108090844': < QA_Account Fund_score_202108090844 market: stock_cn>, 'Fund_score_202108092148': < QA_Account Fund_score_202108092148 market: stock_cn>, 'Fund_score_202108100948': < QA_Account Fund_score_202108100948 market: stock_cn>, 'Fund_score_202108101008': < QA_Account Fund_score_202108101008 market: stock_cn>, 'Fund_score_202108101356': < QA_Account Fund_score_202108101356 market: stock_cn>, 'Fund_score_202108101402': < QA_Account Fund_score_202108101402 market: stock_cn>, 'Fund_score_202108101414': < QA_Account Fund_score_202108101414 market: stock_cn>, 'Fund_score_202108102100': < QA_Account Fund_score_202108102100 market: stock_cn>, 'Fund_score_202108111642': < QA_Account Fund_score_202108111642 market: stock_cn>}
    < QA_Account Fund_score_202108111642 market: stock_cn>



```python
h = acc.history_table
h.to_csv(backtest_dir+strategy_id+'_history.csv', encoding='gbk')
t = acc.daily_hold
t.to_csv(backtest_dir+strategy_id+'_daily_hold.csv', encoding='gbk')
```


```python
risk = QA_Risk(acc,
               benchmark_code="000300",
               benchmark_type=MARKET_TYPE.INDEX_CN,
               if_fq=False)
print(risk().T)
```

    贝塔计算错误。。
    贝塔计算错误。。
                                                                        0
    account_cookie                                Fund_score_202108111642
    portfolio_cookie                                              QA_Day1
    user_cookie                                             USER_lNKqZ3mc
    annualize_return                                                 0.47
    profit                                                           3.88
    max_dropback                                                     0.52
    time_gap                                                         2081
    volatility                                                       0.44
    benchmark_code                                                 000300
    bm_annualizereturn                                               0.11
    bm_profit                                                        0.93
    beta                                                                0
    alpha                                                            0.47
    sharpe                                                           0.95
    sortino                                                         -4.01
    init_cash                                                 10001814.30
    last_assets                                               48854376.75
    total_tax                                                     -772964
    total_commission                                              -377105
    profit_money                                              3.88526e+07
    assets              [10001814.30175, 9948717.30175, 9986857.30175,...
    benchmark_assets    [10001814.30175, 9907030.553812835, 9864529.38...
    timeindex           [2013-01-23, 2013-04-16, 2013-04-22, 2013-04-2...
    totaltimeindex      [2013-01-23, 2013-01-24, 2013-01-25, 2013-01-2...
    ir                                                               1.07
    month_profit        {'2013-01-31 00:00:00': 22876.0, '2013-02-28 0...



```python
fig = risk.plot_assets_curve()
fig.show()
fig = risk.plot_dailyhold()
fig.show()
fig = risk.plot_signal()
fig.show()
```

    QUANTAXIS>> findfont: Font family ['sans-serif'] not found. Falling back to DejaVu Sans.
    QUANTAXIS>> findfont: Font family ['sans-serif'] not found. Falling back to DejaVu Sans.
    QUANTAXIS>> findfont: Font family ['sans-serif'] not found. Falling back to DejaVu Sans.



    
![png](output_48_1.png)
    



    
![png](output_48_2.png)
    



    
![png](output_48_3.png)
    



```python

```


```python

```


```python

```

# 构造优选基金的超配组合

## 超配股与指数成分股


```python
# ---------------------------  展示优选基金组合超配股在沪深300 和中证500 指数中的分布
def analysis_index_cons(df):
    # 分析超配股是否为HS300、ZZ500成分股
    quarter_list = sorted(df['reportDate'].unique().tolist())
    cons_df = pd.DataFrame(index=quarter_list, columns=[u'沪深300成分股占比', u'中证500成分股占比', u'其他'])
    hs300_cons = pd.read_csv(raw_data_dir + 'hs300_con.csv', index_col=0, dtype=str)
    zz500_cons = pd.read_csv(raw_data_dir + 'zz500_con.csv', index_col=0, dtype=str)
    for quarter in quarter_list:
        hold_ticker_list = df.query("reportDate==@quarter")['holdingTicker'].tolist()
        hs300_cons_list = hs300_cons.query('reportDate==@quarter')['consTickerSymbol'].tolist()
        zz500_cons_list = zz500_cons.query('reportDate==@quarter')['consTickerSymbol'].tolist() 
#         print(hold_ticker_list)
#         print(hs300_cons_list)
        
        hs300_pert = len(set(hold_ticker_list) & set(hs300_cons_list)) * 1.0 / len(hold_ticker_list)
        zz500_pert = len(set(hold_ticker_list) & set(zz500_cons_list)) * 1.0 / len(hold_ticker_list)
        cons_df.loc[quarter] = [hs300_pert, zz500_pert, 1-hs300_pert-zz500_pert]

    return cons_df
```


```python
cons_df = analysis_index_cons(top10mean_10_hold_info)

fig = plt.figure(figsize=(12, 6))
ax1 = fig.add_subplot(111)

cons_df.plot(kind='bar', ax=ax1, legend=False, stacked=True)
ax1.legend(cons_df.columns, prop=font, loc='upper right', bbox_to_anchor=(1.2, 0.5), handlelength=2, handletextpad=1, borderpad=0.5)

ax1.set_yticklabels([str(round(x, 2) * 100) + '%' for x in ax1.get_yticks()], fontproperties=font, fontsize=14)
ax1.set_title(u'优选基金组合超配股在沪深300 和中证500 指数中的分布', fontproperties=font, fontsize=16)
ax1.grid()
plt.show()
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-35-2cda167adfdb> in <module>
    ----> 1 cons_df = analysis_index_cons(top10mean_10_hold_info)
          2 
          3 fig = plt.figure(figsize=(12, 6))
          4 ax1 = fig.add_subplot(111)
          5 


    NameError: name 'top10mean_10_hold_info' is not defined

